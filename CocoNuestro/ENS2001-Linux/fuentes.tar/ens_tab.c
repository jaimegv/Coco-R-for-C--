/* A Bison parser, made from ens.y
   by GNU bison 1.35.  */

#define YYBISON 1  /* Identify Bison output.  */

# define	MNEMONICO0	257
# define	MNEMONICO1	258
# define	MNEMONICO2	259
# define	ORG	260
# define	END	261
# define	EQU	262
# define	RES	263
# define	DATA	264
# define	EOL	265
# define	SEPARADOR	266
# define	FIN_ETIQ	267
# define	COMILLAS	268
# define	SUMA	269
# define	RESTA	270
# define	PRODUCTO	271
# define	DIVISION	272
# define	MODULO	273
# define	PARENT_ABRE	274
# define	PARENT_CIERRA	275
# define	INMEDIATO_V	276
# define	INMEDIATO_E	277
# define	REGISTRO	278
# define	MEMORIA_V	279
# define	MEMORIA_E	280
# define	INDIRECTO	281
# define	RELAT_PC_V	282
# define	RELAT_PC_E	283
# define	RELAT_IX_V	284
# define	RELAT_IX_E	285
# define	RELAT_IY_V	286
# define	RELAT_IY_E	287
# define	CADENA	288
# define	ENTERO	289
# define	ETIQUETA	290

#line 45 "ens.y"

                /*Includes*/
#include "compilacion.h"
#include _CADENAS_H_

#include "definiciones.h"
#include "defsc.h"

#include "ens_tab.h"

#include "funcionesauxiliares.h"
#include "gestionetiquetas.h"
#include "gestionerrores.h"
#include "gestionmemoria.h"

int nlin;             /*Contador de numero de lineas*/
int operando;         /*Operando que se esta analizando*/
int errores=0;        /*Errores de sintaxis y semantica*/
int generarcodigo=1;  /*Indica si se debe generar codigo o hay errores*/
struct Instruccion instruccion; /*Almacen temporal de instrucciones*/
int posmem=0;         /*Posicion de memoria sobre la que estamos ensamblando 
                        actualmente*/

char *etiqueta;       /*Etiqueta al comienzo de la linea*/
char *cadena;         /*Literal cadena entre comillas*/

int numetiq;          /*0 si no se ha leido etiqueta, 1 si se ha leido 
                        etiqueta*/
int dirmem;
int desplazamiento;
int *listadatos;      /*Lista de Data (temporal)*/
unsigned int plistadatos; /*Puntero de la lista de datos*/
int dato;             /*Datos introducidos en memoria por una 
		        pseudoinstruccion data*/

unsigned int i;       /*Indice para bucles*/
int retorno;          /*Valor de retorno de funciones*/

        /*Control de errores sintacticos*/
int numregla;
int numtoken;
#ifndef YYSTYPE
# define YYSTYPE int
# define YYSTYPE_IS_TRIVIAL 1
#endif
#ifndef YYDEBUG
# define YYDEBUG 0
#endif



#define	YYFINAL		117
#define	YYFLAG		-32768
#define	YYNTBASE	37

/* YYTRANSLATE(YYLEX) -- Bison token number corresponding to YYLEX. */
#define YYTRANSLATE(x) ((unsigned)(x) <= 290 ? yytranslate[x] : 83)

/* YYTRANSLATE[YYLEX] -- Bison token number corresponding to YYLEX. */
static const char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36
};

#if YYDEBUG
static const short yyprhs[] =
{
       0,     0,     1,     2,     6,     7,     8,     9,    10,    17,
      18,    19,    26,    28,    29,    32,    34,    36,    39,    40,
      41,    46,    47,    48,    49,    56,    57,    58,    59,    60,
      61,    72,    74,    76,    78,    80,    82,    84,    86,    88,
      90,    92,    94,    96,    97,    98,    99,   106,   107,   108,
     109,   116,   117,   118,   119,   120,   128,   129,   130,   131,
     138,   139,   140,   145,   148,   152,   156,   158,   160,   164,
     168,   172,   174,   178,   180,   181,   185,   186,   192,   194,
     196,   197
};
static const short yyrhs[] =
{
      -1,     0,    11,    38,    37,     0,     0,     0,     0,     0,
      39,    40,    41,    43,    42,    37,     0,     0,     0,    36,
      13,    44,    45,    46,    47,     0,    47,     0,     0,    11,
      46,     0,    48,     0,    60,     0,     1,    11,     0,     0,
       0,    49,     3,    50,    11,     0,     0,     0,     0,    51,
       4,    52,    59,    53,    11,     0,     0,     0,     0,     0,
       0,    54,     5,    55,    59,    56,    12,    57,    59,    58,
      11,     0,    22,     0,    23,     0,    24,     0,    25,     0,
      26,     0,    27,     0,    28,     0,    29,     0,    30,     0,
      31,     0,    32,     0,    33,     0,     0,     0,     0,    61,
       6,    62,    76,    63,    11,     0,     0,     0,     0,    64,
       9,    65,    76,    66,    11,     0,     0,     0,     0,     0,
      67,    10,    68,    69,    79,    70,    11,     0,     0,     0,
       0,    71,     8,    72,    76,    73,    11,     0,     0,     0,
      74,     7,    75,    11,     0,    16,    77,     0,    76,    15,
      77,     0,    76,    16,    77,     0,    77,     0,     1,     0,
      77,    17,    78,     0,    77,    18,    78,     0,    77,    19,
      78,     0,    78,     0,    20,    76,    21,     0,    35,     0,
       0,    35,    80,    82,     0,     0,    14,    34,    14,    81,
      82,     0,    11,     0,     1,     0,     0,    12,    79,     0
};

#endif

#if YYDEBUG
/* YYRLINE[YYN] -- source line where rule number YYN was defined. */
static const short yyrline[] =
{
       0,    89,    91,    91,    96,    96,    96,    96,    96,   108,
     108,   108,   139,   142,   144,   148,   151,   154,   317,   317,
     317,   351,   351,   351,   351,   392,   392,   392,   392,   392,
     392,   454,   474,   494,   514,   534,   554,   574,   594,   614,
     633,   653,   673,   693,   693,   693,   693,   721,   721,   721,
     721,   754,   754,   754,   754,   754,   793,   793,   793,   793,
     824,   824,   824,   837,   845,   854,   863,   870,   886,   895,
     912,   929,   936,   945,   952,   952,   962,   962,  1006,  1014,
    1017,  1018
};
#endif


#if (YYDEBUG) || defined YYERROR_VERBOSE

/* YYTNAME[TOKEN_NUM] -- String name of the token TOKEN_NUM. */
static const char *const yytname[] =
{
  "$", "error", "$undefined.", "MNEMONICO0", "MNEMONICO1", "MNEMONICO2", 
  "ORG", "END", "EQU", "RES", "DATA", "EOL", "SEPARADOR", "FIN_ETIQ", 
  "COMILLAS", "SUMA", "RESTA", "PRODUCTO", "DIVISION", "MODULO", 
  "PARENT_ABRE", "PARENT_CIERRA", "INMEDIATO_V", "INMEDIATO_E", 
  "REGISTRO", "MEMORIA_V", "MEMORIA_E", "INDIRECTO", "RELAT_PC_V", 
  "RELAT_PC_E", "RELAT_IX_V", "RELAT_IX_E", "RELAT_IY_V", "RELAT_IY_E", 
  "CADENA", "ENTERO", "ETIQUETA", "programa", "@1", "@2", "@3", "@4", 
  "@5", "linea", "@6", "@7", "linea_vacia", "resto", "instruccion", "@8", 
  "@9", "@10", "@11", "@12", "@13", "@14", "@15", "@16", "@17", 
  "operando", "pseudoinstruccion", "@18", "@19", "@20", "@21", "@22", 
  "@23", "@24", "@25", "@26", "@27", "@28", "@29", "@30", "@31", "@32", 
  "expresion", "expresion_2", "expresion_3", "lista_datos", "@33", "@34", 
  "resto_lista_datos", 0
};
#endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives. */
static const short yyr1[] =
{
       0,    37,    38,    37,    39,    40,    41,    42,    37,    44,
      45,    43,    43,    46,    46,    47,    47,    47,    49,    50,
      48,    51,    52,    53,    48,    54,    55,    56,    57,    58,
      48,    59,    59,    59,    59,    59,    59,    59,    59,    59,
      59,    59,    59,    61,    62,    63,    60,    64,    65,    66,
      60,    67,    68,    69,    70,    60,    71,    72,    73,    60,
      74,    75,    60,    76,    76,    76,    76,    76,    77,    77,
      77,    77,    78,    78,    80,    79,    81,    79,    79,    79,
      82,    82
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN. */
static const short yyr2[] =
{
       0,     0,     0,     3,     0,     0,     0,     0,     6,     0,
       0,     6,     1,     0,     2,     1,     1,     2,     0,     0,
       4,     0,     0,     0,     6,     0,     0,     0,     0,     0,
      10,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     0,     0,     0,     6,     0,     0,     0,
       6,     0,     0,     0,     0,     7,     0,     0,     0,     6,
       0,     0,     4,     2,     3,     3,     1,     1,     3,     3,
       3,     1,     3,     1,     0,     3,     0,     5,     1,     1,
       0,     2
};

/* YYDEFACT[S] -- default rule to reduce with in state S when YYTABLE
   doesn't specify something else to do.  Zero means the default is an
   error. */
static const short yydefact[] =
{
       4,     2,     5,     4,     6,     3,     0,     0,     0,     7,
      12,    15,     0,     0,     0,    16,     0,     0,     0,     0,
       0,    17,     9,     4,    19,    22,    26,    44,    48,    52,
      57,    61,    10,     8,     0,     0,     0,     0,     0,    53,
       0,     0,    13,    20,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    23,    27,    67,     0,
       0,    73,    45,    66,    71,    49,     0,    58,    62,    13,
       0,     0,     0,    63,     0,     0,     0,     0,     0,     0,
       0,     0,    79,    78,     0,    74,    54,     0,    14,    11,
      24,    28,    72,    64,    65,    46,    68,    69,    70,    50,
       0,    80,     0,    59,     0,    76,     0,    75,    55,    29,
      80,    81,     0,    77,    30,     0,     0,     0
};

static const short yydefgoto[] =
{
       5,     3,     2,     4,     6,    23,     9,    32,    42,    70,
      10,    11,    12,    34,    13,    35,    71,    14,    36,    72,
     104,   112,    56,    15,    16,    37,    77,    17,    38,    81,
      18,    39,    66,   102,    19,    40,    87,    20,    41,    62,
      63,    64,    86,   101,   110,   107
};

static const short yypact[] =
{
      17,-32768,-32768,    17,-32768,-32768,     0,    16,    28,-32768,
  -32768,-32768,    39,    40,    38,-32768,    53,    51,    52,    55,
      54,-32768,-32768,    17,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,    67,    25,    25,    10,    10,-32768,
      10,    68,    69,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,    -4,
      10,-32768,     5,    15,-32768,     5,    11,     5,-32768,    69,
      66,    70,    65,    15,     8,    -4,    -4,    71,    -4,    -4,
      -4,    72,-32768,-32768,    30,-32768,-32768,    73,-32768,-32768,
  -32768,-32768,-32768,    15,    15,-32768,-32768,-32768,-32768,-32768,
      74,    75,    78,-32768,    25,-32768,    11,-32768,-32768,-32768,
      75,-32768,    79,-32768,-32768,    85,    86,-32768
};

static const short yypgoto[] =
{
      14,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,    -3,
      -5,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,   -36,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  -32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   -25,
     -57,   -40,   -15,-32768,-32768,   -18
};


#define	YYLAST		92


static const short yytable[] =
{
      57,     7,    73,   -18,   -21,   -25,   -43,   -60,   -56,   -47,
     -51,    58,    82,    65,   115,    67,    60,    -1,    93,    94,
      75,    76,    83,    75,    76,    84,    59,    21,     1,    92,
      60,    61,    78,    79,    80,    74,     8,    33,    96,    97,
      98,    22,    24,    26,    25,    61,    85,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    27,
      28,    31,    29,    30,   100,    89,    88,     7,   109,   -18,
     -21,   -25,   -43,   -60,   -56,   -47,   -51,    91,    43,    68,
      69,    90,    95,    99,   103,   116,   117,   106,   105,   108,
     114,   111,   113
};

static const short yycheck[] =
{
      36,     1,    59,     3,     4,     5,     6,     7,     8,     9,
      10,     1,     1,    38,     0,    40,    20,     0,    75,    76,
      15,    16,    11,    15,    16,    14,    16,    11,    11,    21,
      20,    35,    17,    18,    19,    60,    36,    23,    78,    79,
      80,    13,     3,     5,     4,    35,    35,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,     6,
       9,     7,    10,     8,    34,    70,    69,     1,   104,     3,
       4,     5,     6,     7,     8,     9,    10,    12,    11,    11,
      11,    11,    11,    11,    11,     0,     0,    12,    14,    11,
      11,   106,   110
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/share/bison/bison.simple"

/* Skeleton output parser for bison,

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software
   Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* This is the parser code that is written into each bison parser when
   the %semantic_parser declaration is not specified in the grammar.
   It was written by Richard Stallman by simplifying the hairy parser
   used when %semantic_parser is specified.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

#if ! defined (yyoverflow) || defined (YYERROR_VERBOSE)

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || defined (YYERROR_VERBOSE) */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYLTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
# if YYLSP_NEEDED
  YYLTYPE yyls;
# endif
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAX (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# if YYLSP_NEEDED
#  define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE) + sizeof (YYLTYPE))	\
      + 2 * YYSTACK_GAP_MAX)
# else
#  define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAX)
# endif

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAX;	\
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif


#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	goto yyacceptlab
#define YYABORT 	goto yyabortlab
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");			\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).

   When YYLLOC_DEFAULT is run, CURRENT is set the location of the
   first token.  By default, to implement support for ranges, extend
   its range to the last symbol.  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)       	\
   Current.last_line   = Rhs[N].last_line;	\
   Current.last_column = Rhs[N].last_column;
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#if YYPURE
# if YYLSP_NEEDED
#  ifdef YYLEX_PARAM
#   define YYLEX		yylex (&yylval, &yylloc, YYLEX_PARAM)
#  else
#   define YYLEX		yylex (&yylval, &yylloc)
#  endif
# else /* !YYLSP_NEEDED */
#  ifdef YYLEX_PARAM
#   define YYLEX		yylex (&yylval, YYLEX_PARAM)
#  else
#   define YYLEX		yylex (&yylval)
#  endif
# endif /* !YYLSP_NEEDED */
#else /* !YYPURE */
# define YYLEX			yylex ()
#endif /* !YYPURE */


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)
/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
#endif /* !YYDEBUG */

/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

#ifdef YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif
#endif

#line 315 "/usr/share/bison/bison.simple"


/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
#  define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL
# else
#  define YYPARSE_PARAM_ARG YYPARSE_PARAM
#  define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
# endif
#else /* !YYPARSE_PARAM */
# define YYPARSE_PARAM_ARG
# define YYPARSE_PARAM_DECL
#endif /* !YYPARSE_PARAM */

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
# ifdef YYPARSE_PARAM
int yyparse (void *);
# else
int yyparse (void);
# endif
#endif

/* YY_DECL_VARIABLES -- depending whether we use a pure parser,
   variables are global, or local to YYPARSE.  */

#define YY_DECL_NON_LSP_VARIABLES			\
/* The lookahead symbol.  */				\
int yychar;						\
							\
/* The semantic value of the lookahead symbol. */	\
YYSTYPE yylval;						\
							\
/* Number of parse errors so far.  */			\
int yynerrs;

#if YYLSP_NEEDED
# define YY_DECL_VARIABLES			\
YY_DECL_NON_LSP_VARIABLES			\
						\
/* Location data for the lookahead symbol.  */	\
YYLTYPE yylloc;
#else
# define YY_DECL_VARIABLES			\
YY_DECL_NON_LSP_VARIABLES
#endif


/* If nonreentrant, generate the variables here. */

#if !YYPURE
YY_DECL_VARIABLES
#endif  /* !YYPURE */

int
yyparse (YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  /* If reentrant, generate the variables here. */
#if YYPURE
  YY_DECL_VARIABLES
#endif  /* !YYPURE */

  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yychar1 = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack. */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;

#if YYLSP_NEEDED
  /* The location stack.  */
  YYLTYPE yylsa[YYINITDEPTH];
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
#endif

#if YYLSP_NEEDED
# define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
# define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  YYSIZE_T yystacksize = YYINITDEPTH;


  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
#if YYLSP_NEEDED
  YYLTYPE yyloc;
#endif

  /* When reducing, the number of symbols on the RHS of the reduced
     rule. */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;
#if YYLSP_NEEDED
  yylsp = yyls;
#endif
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  */
# if YYLSP_NEEDED
	YYLTYPE *yyls1 = yyls;
	/* This used to be a conditional around just the two extra args,
	   but that might be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);
	yyls = yyls1;
# else
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);
# endif
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);
# if YYLSP_NEEDED
	YYSTACK_RELOCATE (yyls);
# endif
# undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
#if YYLSP_NEEDED
      yylsp = yyls + yysize - 1;
#endif

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yychar1 = YYTRANSLATE (yychar);

#if YYDEBUG
     /* We have to keep this `#if YYDEBUG', since we use variables
	which are defined only if `YYDEBUG' is set.  */
      if (yydebug)
	{
	  YYFPRINTF (stderr, "Next token is %d (%s",
		     yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise
	     meaning of a token, for further debugging info.  */
# ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
# endif
	  YYFPRINTF (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %d (%s), ",
	      yychar, yytname[yychar1]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#if YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to the semantic value of
     the lookahead token.  This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

#if YYLSP_NEEDED
  /* Similarly for the default location.  Let the user run additional
     commands if for instance locations are ranges.  */
  yyloc = yylsp[1-yylen];
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
#endif

#if YYDEBUG
  /* We have to keep this `#if YYDEBUG', since we use variables which
     are defined only if `YYDEBUG' is set.  */
  if (yydebug)
    {
      int yyi;

      YYFPRINTF (stderr, "Reducing via rule %d (line %d), ",
		 yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (yyi = yyprhs[yyn]; yyrhs[yyi] > 0; yyi++)
	YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
      YYFPRINTF (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif

  switch (yyn) {

case 2:
#line 93 "ens.y"
{LiberarListaTokens();;
    break;}
case 4:
#line 97 "ens.y"
{operando=0;;
    break;}
case 5:
#line 98 "ens.y"
{numregla=0;;
    break;}
case 6:
#line 99 "ens.y"
{numetiq=0;;
    break;}
case 7:
#line 103 "ens.y"
{/*ListarTokens();*/
            LiberarListaTokens();;
    break;}
case 9:
#line 111 "ens.y"
{numetiq=1;;
    break;}
case 10:
#line 113 "ens.y"
{
         retorno=GuardarEtiqueta(etiqueta,posmem);
         if(retorno==-1)
         {
             /*Error asignando memoria*/
             InformarError(ERR_ASIGNACION_MEMORIA,nlin+1,etiqueta);
             generarcodigo=0;
             return -1;
         }
         else if(retorno==-2){
             /*Etiqueta duplicada*/
             InformarError(ERR_ETIQUETA_DUPLICADA,nlin+1,etiqueta);
             /*nlin+1, porque no hemos leido la linea completa todavia*/
             generarcodigo=0;
         }
         else if(retorno==-3){
             /*Etiqueta reservada*/
             InformarError(ERR_NOMBRE_ETIQUETA_RESERVADO,nlin+1,etiqueta);
             /*nlin+1, porque no hemos leido la linea completa todavia*/
             generarcodigo=0;
         }
        ;
    break;}
case 17:
#line 158 "ens.y"
{
         switch(numregla)
         {
             case 11 :
             
                 if(numtoken==2)
                 {
                     InformarError(ERR_SE_ESPERABA_EOL,nlin,
                                   ConsultarToken(2));
                 }
                 break;
                 
             case 12 :
             
                 if(numtoken==2)
                 {
                     if(strcmp(ConsultarToken(2),"<EOL>")==0)
                     {
                         InformarError(ERR_SE_ESPERABA_OP1,nlin,"<EOL>");
                     }
                     else
                     {
                         InformarError(ERR_OP1_INCORRECTO,nlin,
                                       ConsultarToken(2));
                     }
                 }
                 else if(numtoken==3)
                 {
                     InformarError(ERR_SE_ESPERABA_EOL,nlin,
                                   ConsultarToken(3));
                 }
                 break;
                 
             case 13 :
             
                 if(numtoken==2)
                 {
                     if(strcmp(ConsultarToken(2),"<EOL>")==0)
                     {
                         InformarError(ERR_SE_ESPERABA_OP1,nlin,"<EOL>");
                     }
                     else
                     {
                         InformarError(ERR_OP1_INCORRECTO,nlin,
                                       ConsultarToken(2));
                     }
                 }
                 else if(numtoken==3)
                 {
                     InformarError(ERR_SE_ESPERABA_SEPARADOR,nlin,
                                   ConsultarToken(3));
                 }
                 else if(numtoken==4)
                 {
                     if(strcmp(ConsultarToken(4),"<EOL>")==0)
                     {
                         InformarError(ERR_SE_ESPERABA_OP2,nlin,"<EOL>");
                     }
                     else
                     {
                         InformarError(ERR_OP2_INCORRECTO,nlin,
                                       ConsultarToken(4));
                     }
                 }
                 else if(numtoken==5)
                 {
                     InformarError(ERR_SE_ESPERABA_EOL,nlin,
                                   ConsultarToken(5));
                 }
                 break;
                 
             case 26 :
             
                 if(numtoken==2)
                 {
                     if(strcmp(ConsultarToken(0),"<EOL>")==0)
                     {
                         InformarError(ERR_EXPRESION_ERRONEA,nlin-1,"<EOL>");
                     }
                     else
                     {
                     	 InformarError(ERR_EXPRESION_ERRONEA,nlin,"");
                     }
                 }
                 else if(numtoken==3)
                 {
                     InformarError(ERR_SE_ESPERABA_EOL,nlin,ConsultarToken(0));
                 }
             
             case 27 : 
             
                 if(numtoken==2)
                 {
                     if(strcmp(ConsultarToken(0),"<EOL>")==0)
                     {
                         InformarError(ERR_EXPRESION_ERRONEA,nlin-1,"<EOL>");
                     }
                     else
                     {
                     	 InformarError(ERR_EXPRESION_ERRONEA,nlin,"");
                     }
                 }
                 else if(numtoken==3)
                 {
                     InformarError(ERR_SE_ESPERABA_EOL,nlin,ConsultarToken(0));
                 }
                 
             case 28 :
             
                 if(numtoken==2)
                 {
                     if(strcmp(ConsultarToken(0),"<EOL>")==0)
                     {
                         InformarError(ERR_EXPRESION_ERRONEA,nlin-1,"<EOL>");
                     }
                     else
                     {
                     	 InformarError(ERR_EXPRESION_ERRONEA,nlin,"");
                     }
                 }
                 else if(numtoken==3)
                 {
                     InformarError(ERR_SE_ESPERABA_EOL,nlin,ConsultarToken(0));
                 } 
                 
             case 29 :
             
                 if(numtoken==2)
                 {
                     if(strcmp(ConsultarToken(0),"<EOL>")==0)
                     {
                         InformarError(ERR_EXPRESION_ERRONEA,nlin-1,"<EOL>");
                     }
                     else
                     {
                     	 InformarError(ERR_EXPRESION_ERRONEA,nlin,"");
                     }
                 }
                 else if(numtoken==3)
                 {
                     InformarError(ERR_SE_ESPERABA_EOL,nlin,ConsultarToken(0));
                 } 
                 
             case 30 :
             
                 if(numtoken==2)
                 {
                     InformarError(ERR_SE_ESPERABA_EOL,nlin,ConsultarToken(0));
                 }
                 
             default :
             
                 InformarError(ERR_INSTRUCCION_NO_RECONOCIDA,nlin,
                           ConsultarToken(1));
         }
         generarcodigo=0;
         yyerrok;
        ;
    break;}
case 18:
#line 318 "ens.y"
{numregla=11;
               operando=0; 
               numtoken=1;;
    break;}
case 19:
#line 322 "ens.y"
{numtoken=2;
               operando=3;;
    break;}
case 20:
#line 326 "ens.y"
{
               instruccion.codop=yyvsp[-2];
               instruccion.mdir1=0;
               instruccion.op1=0;
               instruccion.etiqueta1=NULL;
               instruccion.longitud1=0;
               instruccion.mdir2=0;
               instruccion.op2=0;
               instruccion.etiqueta2=NULL;
               instruccion.longitud2=0;
               errores=ComprobarInstruccion(instruccion.codop,
                       instruccion.mdir1,instruccion.op1,
                       instruccion.mdir2,instruccion.op2);
               if(errores==0)
               {
                   AlmacenaInstruccion(0);
               }
               else
               {
                   InformarError(errores,nlin,"");
                   generarcodigo=0;
                   yyerrok;
               }
              ;
    break;}
case 21:
#line 352 "ens.y"
{numregla=12;
               operando=0;
               numtoken=1;;
    break;}
case 22:
#line 356 "ens.y"
{numtoken=2;
               operando=1;;
    break;}
case 23:
#line 359 "ens.y"
{numtoken=3;
               operando=3;;
    break;}
case 24:
#line 363 "ens.y"
{
               instruccion.codop=yyvsp[-4];
               instruccion.mdir2=0;
               instruccion.op2=0;
               instruccion.etiqueta2=NULL;
               instruccion.longitud2=0;
               errores=ComprobarInstruccion(instruccion.codop,
                       instruccion.mdir1,instruccion.op1,
                       instruccion.mdir2,instruccion.op2);
               dirmem=posmem+1;
               desplazamiento=0;
               if(instruccion.etiqueta1!=NULL)
               {
                   EscribirTablaConfiguracion(instruccion.etiqueta1,
                                              dirmem,desplazamiento,
                                              instruccion.mdir1,nlin);
               }
               if(errores==0)
               {
                   AlmacenaInstruccion(1);
               }
               else
               {
                   InformarError(errores,nlin,"");
                   generarcodigo=0;
                   yyerrok;
               }
              ;
    break;}
case 25:
#line 393 "ens.y"
{numregla=13;
               numtoken=1;
               operando=0;;
    break;}
case 26:
#line 397 "ens.y"
{numtoken=2;
               operando=1;;
    break;}
case 27:
#line 400 "ens.y"
{numtoken=3;;
    break;}
case 28:
#line 402 "ens.y"
{numtoken=4;
               operando=2;;
    break;}
case 29:
#line 405 "ens.y"
{numtoken=5;
               operando=3;;
    break;}
case 30:
#line 409 "ens.y"
{
               instruccion.codop=yyvsp[-8];
               errores=ComprobarInstruccion(instruccion.codop,
                       instruccion.mdir1,instruccion.op1,
                       instruccion.mdir2,instruccion.op2);
               /*Operando1*/
               dirmem=posmem+1;
               desplazamiento=0;
               if(instruccion.etiqueta1!=NULL)
               {
                   EscribirTablaConfiguracion(instruccion.etiqueta1,
                                              dirmem,desplazamiento,
                                              instruccion.mdir1,nlin);
               }
               /*Operando2*/
               if((instruccion.mdir1==MD_INMEDIATO) || 
                  (instruccion.mdir1==MD_MEMORIA) ||
                  (instruccion.mdir2==MD_INMEDIATO) || 
                  (instruccion.mdir2==MD_MEMORIA))
               {
                   dirmem=posmem+2;
                   desplazamiento=0;
               }
               else
               {
                   desplazamiento=8;
               }
               if(instruccion.etiqueta2!=NULL)
               {
                   EscribirTablaConfiguracion(instruccion.etiqueta2,
                                              dirmem,desplazamiento,
                                              instruccion.mdir2,nlin);
               }
               if (errores==0)
               {
                   AlmacenaInstruccion(2);
               }
               else
               {
                   InformarError(errores,nlin,"");
                   generarcodigo=0;
                   yyerrok;
               }
              ;
    break;}
case 31:
#line 457 "ens.y"
{
            if(operando==1)
            {
                instruccion.mdir1=MD_INMEDIATO;
                instruccion.op1=yyvsp[0];
                instruccion.etiqueta1=NULL;
                instruccion.longitud1=0;
            }
            else
            {
                instruccion.mdir2=MD_INMEDIATO;
                instruccion.op2=yyvsp[0];
                instruccion.etiqueta2=NULL;
                instruccion.longitud2=0;
            }
           ;
    break;}
case 32:
#line 477 "ens.y"
{
            if(operando==1)
            {
                instruccion.mdir1=MD_INMEDIATO;
                instruccion.op1=yyvsp[0];
                instruccion.etiqueta1=etiqueta;
                instruccion.longitud1=16;
            }
            else
            {
                instruccion.mdir2=MD_INMEDIATO;
                instruccion.op2=yyvsp[0];
                instruccion.etiqueta2=etiqueta;
                instruccion.longitud2=16;
            }
           ;
    break;}
case 33:
#line 497 "ens.y"
{
            if(operando==1)
            {
                instruccion.mdir1=MD_REGISTRO;
                instruccion.op1=yyvsp[0];
                instruccion.etiqueta1=NULL;
                instruccion.longitud1=0;
            }
            else
            {
                instruccion.mdir2=MD_REGISTRO;
                instruccion.op2=yyvsp[0];
                instruccion.etiqueta2=NULL;
                instruccion.longitud2=0;
            }
           ;
    break;}
case 34:
#line 517 "ens.y"
{
            if(operando==1)
            {
                instruccion.mdir1=MD_MEMORIA;
                instruccion.op1=yyvsp[0];
                instruccion.etiqueta1=NULL;
                instruccion.longitud1=0;
            }
            else
            {
                instruccion.mdir2=MD_MEMORIA;
                instruccion.op2=yyvsp[0];
                instruccion.etiqueta2=NULL;
                instruccion.longitud2=0;
            }
	   ;
    break;}
case 35:
#line 537 "ens.y"
{
            if(operando==1)
            {
                instruccion.mdir1=MD_MEMORIA;
                instruccion.op1=yyvsp[0];
                instruccion.etiqueta1=etiqueta;
                instruccion.longitud1=16;
            }
            else
            {
                instruccion.mdir2=MD_MEMORIA;
                instruccion.op2=yyvsp[0];
                instruccion.etiqueta2=etiqueta;
                instruccion.longitud2=16;
            }
           ;
    break;}
case 36:
#line 557 "ens.y"
{
            if (operando==1)
            {
                instruccion.mdir1=MD_INDIRECTO;
                instruccion.op1=yyvsp[0];
                instruccion.etiqueta1=NULL;
                instruccion.longitud1=0;
            }
            else
            {
                instruccion.mdir2=MD_INDIRECTO;
                instruccion.op2=yyvsp[0];
                instruccion.etiqueta2=NULL;
                instruccion.longitud2=0;
            }
           ;
    break;}
case 37:
#line 577 "ens.y"
{
            if(operando==1)
            {
                instruccion.mdir1=MD_RELATIVO_PC;
                instruccion.op1=yyvsp[0];
                instruccion.etiqueta1=NULL;
                instruccion.longitud1=0;
            }
            else
            {
                instruccion.mdir2=MD_RELATIVO_PC;
                instruccion.op2=yyvsp[0];
                instruccion.etiqueta2=NULL;
                instruccion.longitud2=0;
            }
           ;
    break;}
case 38:
#line 597 "ens.y"
{
            if(operando==1)
            {
                instruccion.mdir1=MD_RELATIVO_PC;
                instruccion.op1=yyvsp[0];
                instruccion.etiqueta1=etiqueta;
                instruccion.longitud1=8;
            }
            else
            {
                instruccion.mdir2=MD_RELATIVO_PC;
                instruccion.op2=yyvsp[0];
                instruccion.etiqueta2=etiqueta;
                instruccion.longitud1=8;
            }
           ;
    break;}
case 39:
#line 617 "ens.y"
{
            if(operando==1)
            {
                instruccion.mdir1=MD_RELATIVO_IX;
                instruccion.op1=yyvsp[0];
                instruccion.etiqueta1=NULL;
                instruccion.longitud1=0;
            }
            else
            {
                instruccion.mdir2=MD_RELATIVO_IX;
                instruccion.op2=yyvsp[0];
                instruccion.etiqueta2=NULL;
                instruccion.longitud2=0;
            }
           ;
    break;}
case 40:
#line 636 "ens.y"
{
            if(operando==1)
            {
                instruccion.mdir1=MD_RELATIVO_IX;
                instruccion.op1=yyvsp[0];
                instruccion.etiqueta1=etiqueta;
                instruccion.longitud1=8;
            }
            else
            {
                instruccion.mdir2=MD_RELATIVO_IX;
                instruccion.op2=yyvsp[0];
                instruccion.etiqueta2=etiqueta;
                instruccion.longitud1=8;
            }
           ;
    break;}
case 41:
#line 656 "ens.y"
{
            if(operando==1)
            {
                instruccion.mdir1=MD_RELATIVO_IY;
                instruccion.op1=yyvsp[0];
                instruccion.etiqueta1=NULL;
                instruccion.longitud1=0;
            }
            else
            {
                instruccion.mdir2=MD_RELATIVO_IY;
                instruccion.op2=yyvsp[0];
                instruccion.etiqueta2=NULL;
                instruccion.longitud2=0;
            }
           ;
    break;}
case 42:
#line 676 "ens.y"
{
            if(operando==1)
            {
                instruccion.mdir1=MD_RELATIVO_IY;
                instruccion.op1=yyvsp[0];
                instruccion.etiqueta1=etiqueta;
                instruccion.longitud1=8;
            }
            else
            {
                instruccion.mdir2=MD_RELATIVO_IY;
                instruccion.op2=yyvsp[0];
                instruccion.etiqueta2=etiqueta;
                instruccion.longitud1=8;
            }
           ;
    break;}
case 43:
#line 694 "ens.y"
{numregla=26;
		     numtoken=1;;
    break;}
case 44:
#line 697 "ens.y"
{numtoken=2;
		     operando=1;;
    break;}
case 45:
#line 700 "ens.y"
{numtoken=3;
		     operando=3;;
    break;}
case 46:
#line 704 "ens.y"
{
                     if((yyvsp[-2]<0) && (yyvsp[-2]>=-32768))
                     {
                         /*Pasamos a complemento a 2*/
                         yyvsp[-2]=yyvsp[-2]+MAXINT+1;
                     }
                     if((yyvsp[-2]<MININT) || (yyvsp[-2]>MAXINT))
                     {
                         InformarError(ERR_ORG_FUERA_LIMITE_MEMORIA,nlin,"");
                         generarcodigo=0;
                     }
                     else
                     {
                         posmem=yyvsp[-2];
                     }
                    ;
    break;}
case 47:
#line 722 "ens.y"
{numregla=27;
           	     numtoken=1;;
    break;}
case 48:
#line 725 "ens.y"
{numtoken=2;;
    break;}
case 49:
#line 727 "ens.y"
{numtoken=3;
                     operando=3;;
    break;}
case 50:
#line 731 "ens.y"
{
                     if((yyvsp[-2]<0) && (yyvsp[-2]>=-32768))
                     {
                         /*Pasamos a complemento a 2*/
                         yyvsp[-2]=yyvsp[-2]+MAXINT+1;
                     }
                     else if(yyvsp[-2]<-32768)
                     {
                         InformarError(ERR_RES_FUERA_LIMITE_MEMORIA,nlin,"");
                     }
                     if(posmem+yyvsp[-2]>MAXINT)
                     {
                         InformarError(ERR_RES_FUERA_LIMITE_MEMORIA,nlin,"");
                         generarcodigo=0;
                     }
                     else
                     {
                         posmem=posmem+yyvsp[-2];
                         /*Para que se actualicen los limites de memoria*/
                         EscribirMemoria(posmem-1,0); 
                     }                     
                    ;
    break;}
case 51:
#line 755 "ens.y"
{numregla=28;
           	     numtoken=1;;
    break;}
case 52:
#line 758 "ens.y"
{numtoken=2;
                     operando=1;;
    break;}
case 53:
#line 761 "ens.y"
{
                     listadatos=(int *)malloc(sizeof(int)*1000); 
                     plistadatos=0;
                    ;
    break;}
case 54:
#line 767 "ens.y"
{numtoken=3;
                     operando=3;;
    break;}
case 55:
#line 771 "ens.y"
{
                     if((posmem+plistadatos)>(MAXINT+1))
                     {
                         InformarError(ERR_DATA_FUERA_LIMITE_MEMORIA,nlin,"");
                         generarcodigo=0;
                     }
                     else
                     {
                         for(i=0;i<plistadatos;i++)
                         {
                             dato=listadatos[i];
                             if(dato<0)
                             {
                                 dato=256+dato;
                             }
                             EscribirMemoria(posmem+i,dato);
                         }
                         posmem=posmem+plistadatos;
                         free(listadatos);
                     }
                    ;
    break;}
case 56:
#line 794 "ens.y"
{numregla=29;
           	     numtoken=1;;
    break;}
case 57:
#line 797 "ens.y"
{numtoken=2;
                     operando=1;;
    break;}
case 58:
#line 800 "ens.y"
{numtoken=3;
                     operando=3;;
    break;}
case 59:
#line 804 "ens.y"
{
                     if((yyvsp[-2]<-((MAXINT+1)/2)) || (yyvsp[-2]>MAXINT))
                     {
                         InformarError(ERR_EXPRESION_FUERA_DE_RANGO,nlin,"");
                         generarcodigo=0;
                     }
                     else
                     {
                         if(etiqueta!=NULL)
                         {
                             DarValorEtiqueta(etiqueta,yyvsp[-2]);
                         }
                         else
                         {
                             InformarError(ERR_ETIQUETA_NO_DEFINIDA,nlin,etiqueta);
                             generarcodigo=0;
                         }
                     }
                    ;
    break;}
case 60:
#line 825 "ens.y"
{numregla=30;
           	     numtoken=1;;
    break;}
case 61:
#line 828 "ens.y"
{numtoken=2;
                     operando=3;;
    break;}
case 62:
#line 832 "ens.y"
{
                     nlin++;
					 return(0);
                    ;
    break;}
case 63:
#line 841 "ens.y"
{
             yyval=-yyvsp[0];
            ;
    break;}
case 64:
#line 850 "ens.y"
{
             yyval=yyvsp[-2]+yyvsp[0];
            ;
    break;}
case 65:
#line 859 "ens.y"
{
             yyval=yyvsp[-2]-yyvsp[0];
            ;
    break;}
case 66:
#line 866 "ens.y"
{
             yyval=yyvsp[0];
            ;
    break;}
case 67:
#line 873 "ens.y"
{
             if(strcmp(ConsultarToken(0),"<EOL>")==0)
             {
                 InformarError(ERR_EXPRESION_ERRONEA,nlin,"<EOL>");
             }
             else
             {
                 InformarError(ERR_EXPRESION_ERRONEA,nlin+1,"");
             }
             generarcodigo=0;
             yyval=0;
            ;
    break;}
case 68:
#line 891 "ens.y"
{
               yyval=yyvsp[-2]*yyvsp[0];
              ;
    break;}
case 69:
#line 900 "ens.y"
{
               if(yyvsp[0]!=0)
               {
                   yyval=yyvsp[-2]/yyvsp[0];
               }
               else
               {
                   InformarError(ERR_EXPRESION_ERRONEA,nlin+1,S_CADENA_096);
                   generarcodigo=0;
               }
              ;
    break;}
case 70:
#line 917 "ens.y"
{
               if(yyvsp[0]!=0)
               {
                   yyval=yyvsp[-2]%yyvsp[0];
               }
               else
               {
                   InformarError(ERR_EXPRESION_ERRONEA,nlin+1,S_CADENA_096);
                   generarcodigo=0;
               }
              ;
    break;}
case 71:
#line 932 "ens.y"
{
               yyval=yyvsp[0];
              ;
    break;}
case 72:
#line 941 "ens.y"
{
               yyval=yyvsp[-1];
              ;
    break;}
case 73:
#line 948 "ens.y"
{
               yyval=yyvsp[0];
              ;
    break;}
case 74:
#line 955 "ens.y"
{
               listadatos[plistadatos]=yyvsp[0];
               plistadatos=plistadatos+1;
              ;
    break;}
case 76:
#line 967 "ens.y"
{
               for(i=0;i<(strlen(cadena));i++)
               {
                   /*Buscamos caracteres especiales*/
                   if(cadena[i]=='\\')
                   {
                       switch(cadena[i+1])
                       {
                           case '0' : listadatos[plistadatos]=(int)'\0';
                                      i++;
                                      break;
                           case 'n' : listadatos[plistadatos]=(int)'\n';
                                      i++;
                                      break;
                           case 't' : listadatos[plistadatos]=(int)'\t';
                                      i++;
                                      break;
                           default :  listadatos[plistadatos]=(int)cadena[i+1];
                       }
                   }
                   else
                   {
                       listadatos[plistadatos]=(int)cadena[i];
                       /*
                           if(listadatos[plistadatos]<0)
                           {
                               listadatos[plistadatos]=
                                   MAXDESP+1+listadatos[plistadatos];
                           }
                       */
                   }
                   plistadatos=plistadatos+1;
               }
               listadatos[plistadatos]=0;
               plistadatos=plistadatos+1;
              ;
    break;}
case 78:
#line 1009 "ens.y"
{
               InformarError(ERR_LISTA_DATOS_ERRONEA,nlin,"<EOL>");
               generarcodigo=0;
              ;
    break;}
}

#line 705 "/usr/share/bison/bison.simple"


  yyvsp -= yylen;
  yyssp -= yylen;
#if YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;
#if YYLSP_NEEDED
  *++yylsp = yyloc;
#endif

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("parse error, unexpected ") + 1;
	  yysize += yystrlen (yytname[YYTRANSLATE (yychar)]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "parse error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[YYTRANSLATE (yychar)]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exhausted");
	}
      else
#endif /* defined (YYERROR_VERBOSE) */
	yyerror ("parse error");
    }
  goto yyerrlab1;


/*--------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action |
`--------------------------------------------------*/
yyerrlab1:
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;
      YYDPRINTF ((stderr, "Discarding token %d (%s).\n",
		  yychar, yytname[yychar1]));
      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;


/*-------------------------------------------------------------------.
| yyerrdefault -- current state does not do anything special for the |
| error token.                                                       |
`-------------------------------------------------------------------*/
yyerrdefault:
#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */

  /* If its default is to accept any token, ok.  Otherwise pop it.  */
  yyn = yydefact[yystate];
  if (yyn)
    goto yydefault;
#endif


/*---------------------------------------------------------------.
| yyerrpop -- pop the current state because it cannot handle the |
| error token                                                    |
`---------------------------------------------------------------*/
yyerrpop:
  if (yyssp == yyss)
    YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#if YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG
  if (yydebug)
    {
      short *yyssp1 = yyss - 1;
      YYFPRINTF (stderr, "Error: state stack now");
      while (yyssp1 != yyssp)
	YYFPRINTF (stderr, " %d", *++yyssp1);
      YYFPRINTF (stderr, "\n");
    }
#endif

/*--------------.
| yyerrhandle.  |
`--------------*/
yyerrhandle:
  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;
#if YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

/*---------------------------------------------.
| yyoverflowab -- parser overflow comes here.  |
`---------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}
#line 1022 "ens.y"


int yyerror (char *s)
{
    return -1;
}

int yywrap()
{
    return 1;
}

int CalculaPosmem(void)
{
        if((instruccion.mdir1 == MD_INMEDIATO || 
             instruccion.mdir1 == MD_MEMORIA) &&
           (instruccion.mdir2 == MD_INMEDIATO || 
             instruccion.mdir2 == MD_MEMORIA))
        {
            posmem=posmem+3;
        }
        else if(instruccion.mdir1==MD_NO_OPERANDO && 
                instruccion.mdir2==MD_NO_OPERANDO)
        {
            posmem=posmem+1;
        }
        else
        {
            posmem=posmem+2;
        }
        return(0);
}

int AlmacenaInstruccion(int operandos)
{
    EscribirMemoria(posmem,
        instruccion.codop*64 + instruccion.mdir1*8 + instruccion.mdir2);
    posmem++;
    if(operandos >= 1)
    {
        if(instruccion.mdir1==MD_INMEDIATO || instruccion.mdir1==MD_MEMORIA)
        {
            EscribirMemoria(posmem,instruccion.op1);
        }
        else
        {
            EscribirMemoria(posmem,(instruccion.op1*(MAXDESP+1))%(MAXINT+1));
        }
        posmem++;
    }
    if(operandos==2)
    {
        if(instruccion.mdir1 == MD_INMEDIATO ||
           instruccion.mdir1 == MD_MEMORIA ||
           instruccion.mdir2 == MD_INMEDIATO ||
           instruccion.mdir2 == MD_MEMORIA)
        {
            EscribirMemoria(posmem,instruccion.op2);
            posmem++;
        }
        else
        {
            EscribirMemoria(posmem-1,
                    LeerMemoria(posmem-1) | (instruccion.op2%(MAXDESP+1)));
        }
    }
    return 0;
}

int Ens(const char *fichero,int *lineas,int *codigoinicio,int *codigofin)
{
        /*Devuelve:
          lineas = Lineas de Fichero de entrada procesadas
          Ens = 0 si se genero codigo
                -1 si no se genero codigo
                -2 si hubo algun error al leer el fichero
                -3 si hubo algun error al escribir el fichero memoria.tmp
                -4 si hubo algun error al volcar el fichero errores.tmp
        */

    extern FILE *yyin;

    /*Inicializamos variables*/
    nlin=0;
    generarcodigo=1;
    InicializarMemoria();
    InicializarTablaEtiquetas();
    InicializarTablaConfiguracion();
    LiberarListaTokens();
    posmem=0;
    /*Abrimos el fichero para analizar*/
    yyin=fopen(fichero,"r");
    if(yyin!=NULL)
    {
        *codigoinicio=0;
        *codigofin=0;
        rewind(yyin);
        if(yyparse()!=0)
        {
            InformarError(ERR_DESBORDAMIENTO_PILA_ANALIZADOR,0,"");
        }
        /*ListaEtiquetas();*/
        /*ListaTablaConfiguracion();*/
        if(RevisarTablaConfiguracion()!=0)
        {
            /*Hubo algun error al actualizar el codigo con los
              valores de las etiquetas*/
            generarcodigo=0;
        }
        if(generarcodigo==1)
        {
            /*Si no se ha producido ningun error anteriormente*/
            if(VolcarMemoria(FICHERO_TEMPORAL_MEMORIA,codigoinicio,
                             codigofin)!=0)
            {
                generarcodigo=-2;
            }
        }
        else
        {
            if(VolcarFicheroErrores(FICHERO_TEMPORAL_ERRORES)!=0)
            {
                generarcodigo=-3;
            }
        }
        /*Liberamos recursos*/
        yyrestart(yyin);
        fclose(yyin);
        *lineas=nlin;
        LiberarListaErrores();
        LiberarTablaConfiguracion();
        LiberarTablaEtiquetas();
        return generarcodigo-1;
    }
    else
    {
        *lineas=0;
        return -2;
    }
}
