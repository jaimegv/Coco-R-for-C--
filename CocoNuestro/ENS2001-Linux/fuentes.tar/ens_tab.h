#ifndef BISON_ENS_TAB_H
# define BISON_ENS_TAB_H

# ifndef YYSTYPE
#  define YYSTYPE int
#  define YYSTYPE_IS_TRIVIAL 1
# endif
# define	MNEMONICO0	257
# define	MNEMONICO1	258
# define	MNEMONICO2	259
# define	ORG	260
# define	END	261
# define	EQU	262
# define	RES	263
# define	DATA	264
# define	EOL	265
# define	SEPARADOR	266
# define	FIN_ETIQ	267
# define	COMILLAS	268
# define	SUMA	269
# define	RESTA	270
# define	PRODUCTO	271
# define	DIVISION	272
# define	MODULO	273
# define	PARENT_ABRE	274
# define	PARENT_CIERRA	275
# define	INMEDIATO_V	276
# define	INMEDIATO_E	277
# define	REGISTRO	278
# define	MEMORIA_V	279
# define	MEMORIA_E	280
# define	INDIRECTO	281
# define	RELAT_PC_V	282
# define	RELAT_PC_E	283
# define	RELAT_IX_V	284
# define	RELAT_IX_E	285
# define	RELAT_IY_V	286
# define	RELAT_IY_E	287
# define	CADENA	288
# define	ENTERO	289
# define	ETIQUETA	290


extern YYSTYPE yylval;

#endif /* not BISON_ENS_TAB_H */
