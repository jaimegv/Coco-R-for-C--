import java.util.ArrayList;
import org.antlr.runtime.*;
import java.io.*;


public class prueba {

	public static String leer_linea (String [] args) {
		File archivo = null;
	    FileReader fr = null;
	    BufferedReader br = null;
        // Lectura del fichero, recuerda que esta linea
	    // se devuelve siempre, con fallo o aciertos
	    // podemos poner linea como variable
        String fichero = "";

        try {
			 // Apertura del fichero y creacion de BufferedReader para poder
			 // hacer una lectura comoda (disponer del metodo readLine()).
			 archivo = new File (args[0]);
			 fr = new FileReader (archivo);
			 br = new BufferedReader(fr);
			 String linea = null;
			 System.out.println("hola?");

			 // No modificar! lee el fichero entero linea por linea
			 if ((fichero.equals("")) & ((linea=br.readLine())!=null))
					 fichero=linea;

			 while((linea=br.readLine())!=null) {
					System.out.println("leyendo"+linea);
					//System.out.println(fichero);
					fichero+="\n"+linea;	// lo separo con \n = saltos de linea
			 }
	      }
	      catch(Exception e){
	         e.printStackTrace();
	      }finally{
	         // En el finally cerramos el fichero, para asegurarnos
	         // que se cierra tanto si todo va bien como si salta 
	         // una excepcion.
	         try{                    
	            if( null != fr ){   
	               fr.close();     
	            }                  
	         }catch (Exception e2){ 
	            e2.printStackTrace();
	         }
	      }
          System.out.println("esto es lo que he leido del fichero:"+fichero);
	      return fichero;
		
	}
	
	
    public static void main(String[] args) throws Exception {
    	// Leemos el fichero codigo fuente
    	String linea = leer_linea(args);	// recibimos una linea
        System.out.println("Empieza a dar tokens:");
        ANTLRStringStream in = new ANTLRStringStream(linea);
        ExpLexer lexer = new ExpLexer(in);
        CommonTokenStream tokens = new CommonTokenStream(lexer);

        ArrayList<CommonToken> lista = (ArrayList<CommonToken>) tokens.getTokens();

        for (CommonToken t : lista)
        	System.out.println(t.getText());

        //ExpParser parser = new ExpParser(tokens);
        //parser.eval();
    }
}