/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.clparse;

import java.lang.*;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Vector;
import java.util.StringTokenizer;
import java.util.NoSuchElementException;
import java.lang.reflect.*;

/**
 * This is the main class of the package {@link antlraux.clparse}.
 * Basically it parses a command line (or a string) searching for some structs
 * previously specified and invoques methods passing them the parsed parameters.
 * <p>
 * The first thing to do is create a parser. The simplest constructor admits only
 * the application name (this is usually the name of the class that holds the 
 * public static void main() method). Let's suppose that it's called "Main". Then the
 * code for creating the CommandLineParser will be:
 * <pre>
 *   CommandLineParser clp = new CommandLineParserException("Main");
 * </pre>
 * Next thing to do is specifying the commands that Main can have.
 * <p>
 * Let's imagine that it admits the following commands:
 * <ul><li><tt>-d + String</tt> for specifying an output path.</li>
 *     <li><tt>-log + integer</tt> used for log purposes. </li>
 * </ul>
 * The way CommandLineParser acts is this one: it "links" each command spec to a
 * certain method in a certain instance of a class. This instance is called the
 * "executer".
 * <p>
 * A CommandLineParser can have many executers (even one for each command spec).
 * However, most of the time the executer will be the same for every command
 * (and it will usually be the pointer "this").
 * <p>
 * The executor for the two commands that we're coding will be very simple:
 * <pre>
 *   public class Main{
 *     private String outputPath = ".";
 *     private int logLevel = 5;
 *     public Main() {}
 *     public void setLogLevel(Integer ll)
 *     { this.logLevel = ll.intValue(); }
 *     public void setOutputPath(String outputPath)
 *     { this.outputPath = outputPath; }
 *   }
 * </pre>
 * There are some important facts to take in account when using executers:
 * <ul> <li> executers must be declared as public classes
 *           (with <tt>public class...</tt>) </li>
 *      <li> executer methods that will be linked to command line commands must
 *           have parameters of type Integer, Float, Character and Boolean
 *           instead of int, float, char and boolean. </li>
 *      <li> executer methods must be public </li>
 *      <li> command names (<tt>-d</tt>, <tt>-log</tt>must include ANY 
 *           important symbols, including the minus sign (<tt>-</tt>) or the
 *           anti - slash (<tt>\</tt>). Commands with no initial symbol are also
 *           allowed.
 * </ul>
 * The method that registers command specifications in the parser is
 * {@link antlraux.clparse.CommandLineParser#addCommand(Object, String, String, String, String)}
 * <p>
 * In the following peace of code an instance of Main is created, and used as executor
 * for a CommandLineParser's commands specifications:
 * <pre>
 *    Main executer = new Main();
 *    CommandLineParser clp = new CommandLineParser("Main");
 *    clp.addCommand(executer, "-d", "setOutputPath", "s", "Sets the output path");
 *    clp.addCommand(executer, "-log", "setLogLevel", "i", "Sets the log level");
 * </pre>
 * The params of <tt>addCommand</tt> are:
 * <ul>
 * <li> The executer. <li>
 * <li> The command "name". In other words, the string that idenfies the command 
 *      in the command line </li>
 * <li> The name of the executer's method associated with the command </li>
 * <li> The parameter specification (see the comments on the {@link TypeDealer} class</li>
 * <li> A description of what the command does. </li>
 * </ul>
 * You can allways read {@link #addCommand(Object,String,String,String,String)} for
 * further information about them.
 * <p>
 * The next step is launching the recognition process. This can be done in several ways,
 * being the easiest one using the method {@link antlraux.clparse.CommandLineParser#parseWhilePossible()}:
 * <pre>
 *    clp.parseWhilePossible();
 * </pre>
 * After parsing the command line, not a single action is taken (no methods are called
 * on the executer). In order to perform the actions coded in the command line, it is
 * necesary to invoke the method {@link antlraux.clparse.CommandLineParser#executeWhilePossible()}:
 * <pre>
 *    clp.parseWhilePossible();
 * </pre>
 * Both {@link antlraux.clparse.CommandLineParser#parseWhilePossible()} and
 * {@link antlraux.clparse.CommandLineParser#parseWhilePossible()} can throw
 * {@link antlraux.clparse.CommandLineParserException}, so it must be caught.
 * <p>
 * Finally, a bonus: CommandLineParser is capable of generating an authomatic 
 * usage message with the command's specs. In order to obtain it, use
 * {@link antlraux.clparse.CommandLineParser#getUsageMessage(boolean)}:
 * <pre>
 *    String usageMsg = clp.getUsageMessage(true);
 * </pre>
 *
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 */

public class CommandLineParser
{   
    private Hashtable specs;
    private Vector tasks;
    private int taskCounter;
        
    private Task currentTask;
    
    private int parseCounter;
    private String []args;
    
    private String appName;
    
    /** 
     *  Builds a CommandLineParser with a specified parser name. 
     *  @param appName The parser name
     */
    public CommandLineParser(String appName)
    {
        specs      = new Hashtable();
        tasks   = new Vector();
        this.appName = appName;
        
    }
    
    /** 
     *  Builds a CommandLineParser with a specified parser name, and a string to parse.
     *  @param appName The parser name
     *  @param arg     The String to parse. Before parsing, the parser whill split it 
     *                 in tokens, respecting spaces and quotation marks <i>a la command line</i>
     *  @exception CommandLineParserException If arg could not be split.
     */
    public CommandLineParser(String appName, String arg) throws CommandLineParserException
    {
        specs    = new Hashtable();
        tasks = new Vector();
        this.appName = appName;
        
        this.setParsingParams(arg);
    }
    
    /** 
     *  Builds a CommandLineParser with a specified parser name, and a string to parse.
     *  @param appName The parser name
     *  @param args    The command line to parse.
     */
    public CommandLineParser(String appName, String[] args)
    {
        specs    = new Hashtable();
        tasks = new Vector();
        this.appName = appName;
        
        this.setParsingParams(args);
    }
    
    /** 
     *  Builds a CommandLineParser by copy.
     *  @param parser The parser whom its name, args, and specs will be copied 
     */
    public CommandLineParser (CommandLineParser parser)
    {
        specs = parser.specs;
        tasks = new Vector();
        appName = parser.appName;
        setParsingParams(parser.args);
    }
   
    /** 
     *  Adds a new command specification to the parser.
     *  @param executer    The object that will execute the method called methodName
     *  @param commandName The command name
     *  @param paramTypes  An string specificating the types of the method called methodName
     *                     The way types are specified is very simple: each char of the String
     *                     represents a type. The correspondences between chars
     *                     and Types can be found in {@link TypeDealer}.
     *                     An empty string (not null!) maps a method with no
     *                     parameters.
     *  @param description A string that will appear in the usage, as an additional help
     * 
     *  @exception CommandLineParserException If another command with the same name
     *             already exists, or paramTypes contains a non valid char for specificating types.
     */
    public void addCommand(Object executer, String commandName, String methodName, String paramTypes, String description)
        throws CommandLineParserException
    {
        
        if(specs.containsKey(commandName))
            throw new CommandLineParserException("The command " + commandName + " has already been defined.");
        
        specs.put(commandName, new CommandSpec(executer, commandName, paramTypes, methodName, description));
    }

    
    /** 
     *  Changes the command line that the parser must parse. This function also resets the parsing and 
     *  erases any task that remained unexecuted.
     *  @param arg     The String to parse. Before parsing, the parser whill split it 
     *                 in tokens, respecting spaces and quotation marks <i>a la command line</i>
     *
     *  @exception CommandLineParserException if arg could not be slit.
     */
    public void setParsingParams(String arg) throws CommandLineParserException
    {
        Vector v = new Vector();
        String token, auxToken;        
        StringTokenizer st = new StringTokenizer(arg," ");
                
        while (st.hasMoreElements())
        {
            token = st.nextToken(" ");
            if(token.startsWith("\""))
            {
                try
                {
                    auxToken = st.nextToken("\"");
                    if (!auxToken.endsWith("\""))
                        throw new CommandLineParserException("Unbalanced quote marks in argument");
                    token = token + " " + auxToken;
                }
                catch (NoSuchElementException nsee)
                { throw new CommandLineParserException("Unbalanced quote marks in argument"); }
            }
            v.add(token);
        }
        
        String []result = new String[v.size()];
        for (int i=0; i<v.size(); i++)
            result[i]=(String)(v.get(i));
        
        setParsingParams(result);
    }
    
    /** 
     *  Changes the command line that the parser must parse. This function also resets the parsing and 
     *  erases any task that remained unexecuted.
     *  @param args    The new commandLine to parse.
     */
    public void setParsingParams(String[] args)
    {
        this.args = args;
        tasks.clear();
        taskCounter =0;
        parseCounter =0;
        currentTask = null;
    }
    
    /** 
     *  Tries to parse a new command and its params. If succesfull, a new task is added.
     *  @exception CommandLineParserException If a parsing error ocurred.
     */
    public void parseNext() throws CommandLineParserException
    {
        // Increment the parsing counter
        parseCounter++;
        
        // parse the command
        CommandSpec co = (CommandSpec)(specs.get(args[parseCounter-1]));
        if(co==null)
            throw new CommandLineParserException("The command " + args[parseCounter-1] + " is not valid");
        
        // and then parse the command's arguments
        Object [] params = new Object[co.paramTypes.length()];
        try
        {
            for(int paramCounter=0; paramCounter<co.paramTypes.length(); paramCounter++)
            {
                parseCounter++;
                params[paramCounter] = TypeDealer.objectFromString(
                                              args[parseCounter-1],
                                              co.paramTypes.charAt(paramCounter)); 
            }
        }
        catch (IndexOutOfBoundsException ioobe)
        {
            throw new CommandLineParserException("Parameters needed for command " + co.commandName);
        }
        
        // add the command to the command list
        tasks.add(new Task(co, params));        
    }
    
    /** 
     *  Tests if the parser has finished parsing the command Line or not.
     *  @return false if the end of command line has been reached, false otherwise
     */
    public boolean hasMoreToParse()
    {
        if(parseCounter<args.length) return true;
        return false;
    }
    
    /** 
     *  Parses the commandLine that has not been parsed until its end is reached. Stores
     *  the tasks to execute in a vector of tasks, whith their params.
     *  @exception CommandLineParserException If a parsing error ocurred.
     */
    public void parseWhilePossible() throws CommandLineParserException
    {
        while(this.hasMoreToParse()) this.parseNext();
    }
    
    /** 
     *  Executed the next task to be executed, and erases it from the task vector.
     *
     *  @return    The object that the function executed by the task returns.
     *  @exception CommandLineParserException If there are not mor tasks to execute or if the task 
     *             throwed an exception.
     */
    public Object executeNext() throws CommandLineParserException
    {
        try
        {
            currentTask = (Task)(tasks.get(taskCounter++));
            return currentTask.execute();
        }
        catch ( ArrayIndexOutOfBoundsException e)
        {
            throw new CommandLineParserException("There aren't more things to execute.");
        }
    }
    
    /**
     *  Tests if there are more tasks to be executed.
     *  @return true if there are more tasks to execute, false otherwise.
     */
    public boolean hasMoreToExecute()
    {
        if(taskCounter < tasks.size()) return true;
        return false;
    }
    
    /** 
     *  Executes any pending task in order.
     *  @return    All the objects that the differents tasks have returned.
     *  @exception CommandLineParserException if any task has thrown an exception.
     */
    public Object[] executeWhilePossible() throws CommandLineParserException
    {
        Vector v = new Vector();
        while(this.hasMoreToExecute())
        {
            v.add(this.executeNext());
        }
        
        return v.toArray();
    }
    
    /**
     *  Gets the name of the command that generated the task that is being currently executed (the
     *  current task is the last task executed, or currently executing).
     *  @return The name of the command of the current task. null if there is no current task.
     */
    public String getCurrentCommandName ()
    {
        if(currentTask == null) return null;
        else return currentTask.spec.commandName;
    }
    
    /**
     *  Returns an string that can be used as ussage message.
     *  @param includeFirstLine Setting this to true, whe asure that a title line (containing
     *                          the application name followed with the parser properties names)
     *                          will appear.
     *  @return The usage message.
     */
    public String getUsageMessage(boolean includeFirstLine)
    {
        StringBuffer sb = new StringBuffer();
        
        try
        {
           if(includeFirstLine)
           {
               sb.append("java ");
               sb.append(appName);
               sb.append("[commands]\n\n");
           }
           
           Enumeration es = specs.elements();
           CommandSpec spec;
           
           while(es.hasMoreElements())
           {
               spec = (CommandSpec)(es.nextElement());
               sb.append("   ");
               sb.append(spec.commandName); sb.append(' ');
               sb.append(TypeDealer.getStringOfTypes(spec.paramTypes, false));
               sb.append("\n      ");
               sb.append(spec.description);
               sb.append('\n');
           }
        }
        catch(CommandLineParserException clpe) // This exception should never happen
        {
        }
        
        return sb.toString();
    }
}
