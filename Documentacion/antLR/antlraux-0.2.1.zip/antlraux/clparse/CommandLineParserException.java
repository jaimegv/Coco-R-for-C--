/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */
package antlraux.clparse;

import java.lang.Exception;
/**
 *  An instance of this exception will be launched any time that an error
 *  is encountered during the command line parsing or execution.
 *
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 * @see antlraux.clparse.ExecutedMethodException
 */
public class CommandLineParserException extends Exception
{
    public CommandLineParserException()
    {}
    public CommandLineParserException(String msg)
    {
        super(msg);
    }
}