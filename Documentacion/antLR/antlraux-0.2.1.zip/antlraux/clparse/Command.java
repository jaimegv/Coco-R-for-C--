/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.clparse;

import java.lang.Object;
import java.lang.reflect.Method;
import java.lang.NoSuchMethodException;
import java.lang.SecurityException;
import java.lang.reflect.InvocationTargetException;

/**
 *  A Command is the union of a
 *  {@link antlraux.clparse.CommandSpec} and a list of
 *  parameters. It encapsulates one command in the command line.
 *  Instances of Command are created by a
 *  {@link CommandLineParser} during the parsing of the command line
 *  @author Enrique Jos&eacute; Garc&iacute;a Cota
 **/
public class Command
{
    private Object [] params;
    protected CommandSpec spec;
    
    /** Only constructor of the class **/
    public Command(CommandSpec spec, Object[] params ) throws CommandLineParserException
    {
        this.spec = spec;
        this.params = params;
    }

	/**
	 * This method "launches" a command. In order to do this,
	 * it obtains the {@link java.lang.reflect.Method}
	 * and executer of the {@link antlraux.clparse.CommandSpec}.
	 * Then it calls {@link java.lang.reflect.Method#invoke(Object, Object[])}
	 * using its parameters list.
	 * @return the Object returned by {@link java.lang.reflect.Method#invoke(Object, Object[])}
	 * @throws ExecutedMethodException
	 *   if {@link java.lang.reflect.Method#invoke(Object, Object[])}
	 *   throws {@link java.lang.reflect.InvocationTargetException}
	 * @throws CommandLineException if any other error happens.
	 **/
    public Object execute() throws CommandLineParserException
    {
        try
        {
            return spec.method.invoke(spec.executer, params);
        }
        catch (InvocationTargetException ite)
        {
            Exception e = (Exception)(ite.getTargetException());
            
            throw new ExecutedMethodException("The method " + spec.getCompleteMethodName() +
                                            " has thrown the exception " + e.getClass().getName() +
                                            "; You should catch ExecutedMethodException BEFORE catching "+
                                            "CommandLineParserException and then obtain the righ Exception "+
                                            "whith getException()", e);
        }
        catch (Exception e)
        {
            throw new CommandLineParserException("Couldn't execute the method " + 
                                                  spec.getCompleteMethodName() +
                                                 ". The exception was: " + 
                                                 e.getMessage());
        }
    }
}