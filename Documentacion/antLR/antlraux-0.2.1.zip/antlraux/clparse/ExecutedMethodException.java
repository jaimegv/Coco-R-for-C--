/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.clparse;

import java.lang.Exception;

/**
 *  This exception is thrown when the method associated to a task launch itself
 *  an exception.
 *  <p>
 *  For example, consider you have a method like this:
 *  <pre>
 *  public class Foo
 *  {
 *    public Foo() {}
 *    public Integer divide(Integer a, Integer b)
 *    {
 *       return new Integer(a.intValue()/b.intValue();
 *    }
 *  }
 *  </pre>
 *  Method <tt>divide</tt> will launch a {@link java.lang.ArithmeticException}
 *  if <tt>b.intValue()==0</tt>.
 *  <p>
 *  Now consider that you associate a command of the 
 *  command line to this particular method:
 *  <pre>
 *  import antlraux.clparse.*;
 *  
 *  public static void main(String [] args)
 *  {
 *    Foo executer = new Foo();
 *    CommandLineParser clp = new CommandLineParser("Main");
 *    clp.addCommand(executer, "-div", "divide", "ii", "Divide two integers");
 *    try
 *    {
 *       clp.parseWhilePossible();
 *       clp.executeWhilePossible();
 *    }catch (CommandLineParserException clpe){
 *       clpe.printStackTrace(System.err);
 *    }
 *  </pre>
 *  
 *  This program will work very well: if an exception
 *  is thrown in Foo.divide(Integuer, Integuer), it will
 *  be encapsulated in an {@link antlraux.clparse.ExecutedMethodException},
 *  which is a subclass of {@link antlraux.clparse.CommandLineParserException}.
 *  This way the fact of being able to intercept exceptions
 *  launched by the executer are transparent for the majority of
 *  users, who don't need this capacity.
 *  <p>
 *  In order to work specifically with exceptions launched by 
 *  the executer, you'll have to capture {@link antlraux.clparse.ExecutedMethodException}
 *  before capturing {@link antlraux.clparse.CommandLineParserException}.
 *  This way you can call {@link antlraux.clparse.ExecutedMethodException#getException()}
 *  and get the {@link java.lang.Exception} launched.
 *  <pre>
 *  public static void main(String [] args)
 *  {
 *    Foo executer = new Foo();
 *    CommandLineParser clp = new CommandLineParser("Main");
 *    clp.addCommand(executer, "-div", "divide", "ii", "Divide two integers");
 *    try
 *    {
 *       clp.parseWhilePossible();
 *       clp.executeWhilePossible();
 *    } catch (ExecutedMethodException eme){
 *       Exception e = eme.getException();
 *       e.printStackTrace(System.err);
 *    }
 *    } catch (CommandLineParserException clpe){
 *       clpe.printStackTrace(System.err);
 *    }
 *  }
 *  </pre>
 *  <br>Don't forget that you must capture {@link antlraux.clparse.ExecutedMethodException}
 *  before capturing {@link antlraux.clparse.CommandLineParserException}.
 *  </br>  
 *
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 */
public class ExecutedMethodException extends CommandLineParserException
{
    private Exception exception;
    protected ExecutedMethodException()
    {}
    protected ExecutedMethodException(String msg)
    {
        super(msg);
    }
    protected ExecutedMethodException(String msg, Exception exception)
    {
        super(msg);
        this.exception = exception;
    }
    /**
     *  Method that returns the exception launched by the executed method.
     *  @return The exception launched by the executed mehod.
     */  
    public Exception getException()
    {
        return exception;
    }
    
}