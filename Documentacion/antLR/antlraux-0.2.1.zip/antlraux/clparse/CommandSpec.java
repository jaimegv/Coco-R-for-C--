/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.clparse;

import java.lang.Class;
import java.lang.reflect.Method;
import java.lang.Object;
import java.lang.String;
import java.lang.Boolean;
import java.lang.Integer;
import java.lang.Character;

/**
 *  This class encapsulates the specification of a command.
 *  That involves storing a command name, the types an number of params that
 *  the command has, a {@link java.lang.reflect.Method}
 *  to invoke, the object that will execute it (called executor),
 *  and a description for the usage message.
 *
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 */
public class CommandSpec
{
    protected String paramTypes;
    protected String commandName;
    protected String description;
    protected Method method;
    protected Object executer;
    protected Object[] types;
    
    private String methodName;
    
    /**
     *  Constructs a new command specification.
     *  @param executer    The object that will execute the method.
     *  @param commandName The name of the command that the objects specifies.
     *  @param paramTypes  A string that specifies the parameters that the command needs.
     *  @param methodName  The method of executer that will be launched by the tasks associated to this
     *                     CommandSpec
     *  @param description The usage message for the command.
     *  @exception CommandLineParserException If an error has ocurred creating the object.
     */
    protected CommandSpec(Object executer, String commandName, String paramTypes, String methodName, String description)
        throws CommandLineParserException
    {
        TypeDealer.checkStringTypes(paramTypes);
        
        this.executer = executer;
        this.paramTypes = paramTypes;
        this.commandName = commandName;
        this.description = description;
        this.types = TypeDealer.getTypesFromString(paramTypes);
        this.methodName = methodName;
        
        try
        {
            this.method = executer.getClass().getMethod(methodName, TypeDealer.getTypesFromString(paramTypes) );
        }
        catch (NoSuchMethodException e)
        {
            throw new CommandLineParserException("The method " + getCompleteMethodName() +
                                                 " was not found. Please ensure that it's public.");
        }
        catch (SecurityException e)
        {   throw new CommandLineParserException(e.getMessage());  } 
    }
    
    /**
     *  Returns an String containing with the format executer-class.method(list-of-types), where
     *  executer-class if the class of the executer object and list-of-types is the list of params
     *  of the method.
     *  @return the String describing the method
     */    
    protected String getCompleteMethodName()
    {
        StringBuffer sb = new StringBuffer();
        try
        {
            sb.append(executer.getClass().getName());
            sb.append('.');
            sb.append(methodName);
            sb.append('(');
            sb.append(TypeDealer.getStringOfTypes(paramTypes, true));
            sb.append(')');
        }
        catch (CommandLineParserException clpe) // This exception should never activate
        {}                                      // As long as we keep the type checking at the beginning
                                                // Of the only constructor.
        return sb.toString();
    }
}