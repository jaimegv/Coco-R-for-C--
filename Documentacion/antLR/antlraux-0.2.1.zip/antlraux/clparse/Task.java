/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.clparse;

import java.lang.Object;
import java.lang.reflect.Method;
import java.lang.NoSuchMethodException;
import java.lang.SecurityException;
import java.lang.reflect.InvocationTargetException;

/**
 * Each time that the parser succesfully parses a command and its params, it adds a Task to a list of
 * tasks. Basically a task is a group made with a CommandSpec and a table of params.
 * <p>
 * When a task is executed, it calls the method associated with its CommandSpec passing it
 * its list of params.
 *
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 */

public class Task
{
    private Object [] params;
    protected CommandSpec spec;
    
    /**
     *  The class constructor.
     *  @param     spec   The CommandSpec associated to this Task.
     *  @param     params The parsed params.
     */
    public Task(CommandSpec spec, Object[] params )
    {
        this.spec = spec;
        this.params = params;
    }
   
    /**
     *  This method calls the method associated to the task, passing it its list of params.
     *  @exception CommandLineParserException If the method executed throws an exception, or an error ocurred.
     */
    public Object execute() throws CommandLineParserException
    {
        try
        {
            return spec.method.invoke(spec.executer, params);
        }
        catch (InvocationTargetException ite)
        {
            Exception e = (Exception)(ite.getTargetException());
            
            throw new ExecutedMethodException("The method " + spec.getCompleteMethodName() +
                                            " has thrown the exception " + e.getClass().getName() +
                                            "; You should catch ExecutedMethodException BEFORE catching "+
                                            "CommandLineParserException and then obtain the righ Exception "+
                                            "whith getException()", e);
        }
        catch (IllegalAccessException iae)
        {
        	throw new CommandLineParserException(
        		"The method " +  spec.getCompleteMethodName() +
        	    " was found, but could not be executed." +
        	    " Make sure that 1) The method is public and" +
        	    " 2) THE EXECUTER'S CLASS IS ALSO DECLARED PUBLIC"+
        	    " (with 'public class ...'). The exeption found was: " +
                iae.getClass().getName() + ": " +
                iae.getMessage());
        	    
        }
        catch (Exception e)
        {            
            throw new CommandLineParserException("Couldn't execute the method " + 
                                                  spec.getCompleteMethodName() +
                                                 ". The exception was: " +
                                                 e.getClass().getName() + ": " +
                                                 e.getMessage());
        }
    }
}