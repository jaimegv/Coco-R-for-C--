/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.clparse;

/**
 *  Conversion between Strings and java basic types is necessary along all the parsing. This static class
 *  encapsulated all the functionallity needed for doing that.
 *  <p>
 *  We will say that a char is valid if it represents one of the types supported by the parser. Otherwise
 *  it will be not valid.
 *  <p>
 *  Valid type chars are:
 *  <ul>
 *    <li><tt>'S'</tt> or <tt>'s'</tt> for type <tt>String</tt> </li>
 *    <li><tt>'B'</tt> or <tt>'b'</tt> for type <tt>Boolean</tt> </li>
 *    <li><tt>'I'</tt> or <tt>'i'</tt> for type <tt>Integer</tt> </li>
 *    <li><tt>'C'</tt> or <tt>'c'</tt> for type <tt>Character</tt> </li>
 *    <li><tt>'F'</tt> or <tt>'f'</tt> for type <tt>Float</tt> </li>
 *  </ul>
 *
 *  Strings, integers, chars and floats are directly obtained from the command
 *  line. In order to specify a boolean value the user has to write
 *  'false' or 'true' in the command line.
 *
 *  @author Enrique Jos&eacute; Garc&iacute;a Cota
 */

public class TypeDealer
{
    private final static String validTypeChars = "SsBbIiCcFf";
    
    /**
     *  Checks if a string contains only valid chars.
     *  @param     paramTypes The string to check.
     *  @exception CommandLineParserException If the string contains one not valid char at least.
     */
    public static void checkStringTypes(String paramTypes) throws CommandLineParserException
    {
        if(paramTypes == null) return;

        for (int i=0; i<paramTypes.length(); i++)
           checkCharType(paramTypes.charAt(i));
    }
    
    /**
     *  Checks if a char is valid.
     *  @param     type The char to check.
     *  @exception CommandLineParserException If type is not valid.
     */
    public static void checkCharType(char type) throws CommandLineParserException
    {
        if(validTypeChars.indexOf(type)==-1)
               throw new CommandLineParserException("The type specification char '" + 
                                                    type +
                                                    "' is not valid. Only "
                                                    + validTypeChars +
                                                    " are addmitted.");
    }
    
    /**
     *  Tries to parse an object of the specified type from a specified String.
     *  @param     source The string to parse.
     *  @param     type   The type of the object that we want to parse.
     *  @exception CommandLineParserException If the parsing could not be done.
     */
    public static Object objectFromString(String source, char type) throws CommandLineParserException
    {
        switch (type)
        {
            case 'S': case 's':
                return source;
            case 'B': case 'b':
                if(source.toLowerCase().equals("true")) return Boolean.TRUE;
                if(source.toLowerCase().equals("false")) return Boolean.FALSE;
                throw new CommandLineParserException("Could not parse a boolean from " + source);
            case 'I': case 'i':
                try
                {
                    return new Integer(source);
                }
                catch (NumberFormatException nfe)
                {
                    throw new CommandLineParserException("Could not parse an integer from " + source);
                }
            case 'F': case 'f':
                try
                {
                    return new Float(source);
                }
                catch (NumberFormatException nfe)
                {
                    throw new CommandLineParserException("Could not parse an integer from " + source);
                }
            case 'C': case 'c':
                if(source.length()!=1) throw new CommandLineParserException("Could not parse a char from " + source);
                else return new Character(source.charAt(0));
            default:
                throw new CommandLineParserException("Unexpected typechar: " + type);
        }
    }
    
    
    /**
     *  Given a valid class specification, it returns its class.
     *  @param     The char specifying the class.
     *  @return    The class needed.
     *  @exception CommandLineParserException If type is not valid.
     */
    protected static Class getTypeFromChar(char type) throws CommandLineParserException
    {
        switch(type)
        {
            case 'S': case 's': return String.class;
            case 'B': case 'b': return Boolean.class;
            case 'I': case 'i': return Integer.class;
            case 'C': case 'c': return Character.class;
            case 'F': case 'f': return Float.class;
        }
        throw new CommandLineParserException("Unexpected typechar: " + type);
    }
    
    /**
     *  Given a String of specification, it returns its table of types associated.
     *  @param     types The type specification String.
     *  @exception CommandLineParserException If types contains one not valid char.
     */
    protected static Class[] getTypesFromString(String types) throws CommandLineParserException
    {
        if (types == null) return new Class[0];
        
        Class []result = new Class[types.length()];
        for (int i=0; i<types.length(); i++)
            result[i] = getTypeFromChar(types.charAt(i));
        
        return result;
    }
    
    /**
     *  Returns a string containing the names of the classes associated to a specification string.
     *  @param     types  The string to check.
     *  @param     commas If true, the names are separated by commas and spaces. Otherwise they are
     *             only separated by spaces.
     *  @exception CommandLineParserException If types contains one not valid char at least.
     */
    protected static String getStringOfTypes(String types, boolean commas) throws CommandLineParserException
    {
        StringBuffer sb = new StringBuffer();
        
        boolean first = true;
        for (int i=0; i<types.length(); i++)
        {
            if(commas && !first) sb.append(',');
            if(!first) sb.append(' ');
            sb.append(getTypeName(types.charAt(i)));
            first = false;
        }
        return sb.toString();
    }
    
    private static String getTypeName(char type) throws CommandLineParserException
    {
        switch(type)
        {
            case 'S': case 's': return "String";
            case 'B': case 'b': return "Boolean";
            case 'I': case 'i': return "Integer";
            case 'C': case 'c': return "Character";
            case 'F': case 'f': return "Float";
        }
        throw new CommandLineParserException("Unexpected typechar: " + type);
    }

}