
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.util;

import antlr.Token;
import antlr.CommonToken;
import antlr.FileLineFormatter;
import antlr.collections.AST;
/**
 * This subclass of {@link antlr.CommonToken} implements
 * {@link antlraux.util.LexInfo}, really allowing the use of
 * a filename (which is ommited in {@link antlr.CommonToken})
 *
 * To make your lexer use this class of tokens, you'll have to use
 * the method <tt>setTokenObjectClass</tt>:
 * <pre>
 * import antlraux.util.LexInfoToken;
 * ...
 * MyLexer lexer = new MyLexer(new FileInputStream(filename));
 * lexer.setFilename(filename);
 * lexer.setTokenObjectClass("antlraux.util.LexInfoToken");
 * </pre>
 * Warning! By default, the antlr v2.7.2 implementation of lexer does NOT add filename
 * information to the tokens it creates. Tokens are created in method
 * {@link antlr.CharScanner#makeToken(int)} of class <tt>antlr.CharScanner</tt>,
 * which is the superClass of every Lexer we can create.
 * So in order to set the filename in our lexer we'll have to
 * override it in the grammar definition file of the lexer:
 * <pre>
 * public class MyLexer extends Lexer;
 * options {...}
 * tokens {...}
 * // Code section
 * {
 *    public Token makeToken(int type)
 *    {
 *        // Obtain the token with no filename, and then add it
 *        Token result = super.makeToken(type);
 *        result.setFilename(getFilename());
 *        return result;
 *    }
 * }
 * </pre>
 * Once you include this on your lexer <tt>LexInfoToken</tt> 
 * will work perfectly (Keep in mind that this modification 
 * might not be necessary in future versions of antlr).
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 * @see LexInfoAST
 * @see LexInfo
 **/
public class LexInfoToken extends antlr.CommonToken
implements LexInfo
{
	private String filename = LexInfo.DEFAULT_FILENAME;
	
    /**
     * Default constructor. This constructor is necessary for
     * every subclass of {@link antlr.Token} in order to being
     * able to create them in the {@link antlr.CharScanner}
     **/
    public LexInfoToken()
    {
    	super();	
    }
    
    /**
     * Only initializes type and text. Lexical information
     * is set to default values
     **/
    public LexInfoToken(int type, String text)
    {
    	super(type, text);
    }
    
    /**
     * Copy constructor
     **/
    public LexInfoToken(Token t) 
    {
		super(t.getType(), t.getText());
		setFilename(t.getFilename());
		setLine(t.getLine());
		setColumn(t.getColumn());
    }

    /** Get the file name for this token */
    public String getFilename()
    { return filename.toString(); }
    
    /**
     * Set the file name for this token. If null is guiven, then
     * filename=defaultFilename.
     **/
    public void setFilename(String fn)
    { filename = fn; }
   
    /** Sets the Lex information **/
    public void copyLexInfo(LexInfo from)
    {
    	if(from!=null)
    	{
    		this.filename = from.getFilename();
    		this.setLine(from.getLine());
    		this.setColumn(from.getColumn());
    	}
    }
    
    /** 
     * Returns a String in the stype "filename:line:column".
     * This is done with the help of class 
     * {@link antlr.FileLineFormatter}, so problems like
     * filename==null are taken into account.
     **/
    public String getLexInfoString()
	{
		FileLineFormatter f = FileLineFormatter.getFormatter();
		return f.getFormatString(filename.toString(), getLine(), getColumn());
	}
}