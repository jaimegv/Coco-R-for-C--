
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.util;

/**
 *  This interface represents a class that stores lexical
 *  information, this is, a filename, a line and a column.
 *  This interface does not requiere nor guaranties
 *  "completeness" in lexical information; filename may
 *  be null, and line and column may be -1.
 *  @author Enrique Jos&eacute; Garc&iacute;a Cota
 **/
public interface LexInfo
{
    /** Provides a safe default line value (-1)**/
    public static final int DEFAULT_LINE   = -1;
    
    /** Provides a safe default column value (-1)**/
    public static final int DEFAULT_COLUMN = -1;
    
    /** Provides a safe default file name (null)**/
    public static final String DEFAULT_FILENAME = null;
    
    /** Get the file name for this node */
    public String getFilename();
    
    /** Get the column for this node */
    public int getColumn();
    
    /** Get the line for this node */
    public int getLine();
    
    /** Sets the file name for this node. **/
    public void setFilename(String fn);
       
    /** Set the column for this node **/
    public void setColumn(int column);
    
    /** Set the line for this node **/
    public void setLine(int line);
    
    /**
     * Copies the lexical information from other LexInfo.
     * WARNING: do not forget the case <tt>from==null</tt>!
     ***/
    public void copyLexInfo(LexInfo from);
    
    /**
     * Returns true if all the information (Filename:line:column)
     * is valid; false otherwise. It will usually be implemented
     * around a {@link antlr.FileLineFormatter}, which authomatically
     * deals with incompleteness in the information.
     */
    public String getLexInfoString();
}