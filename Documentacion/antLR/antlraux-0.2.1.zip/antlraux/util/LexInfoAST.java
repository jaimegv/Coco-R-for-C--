
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.util;

import antlr.CommonAST ;
import antlr.Token;
import antlr.FileLineFormatter;
import antlr.collections.AST;
/**
 * This subclass of {@link antlr.CommonAST} implements
 * {@link antlraux.util.LexInfo}, so it can return the
 * filename, line and column of its information. It
 * also provides additional navigation methods.
 * <p>
 * In order to use LexInfoAST in your parser or tree parser, you'll have to
 * use the method {@link antlr.Parser#setASTNodeClass(String)}:
 * <pre>
 * import antlraux.util.LexInfoAST;
 * ...
 *
 * MyLexer lexer = new MyLexer(new FileInputStream(filename));
 * lexer.setFilename(filename);
 * MyParser parser = new MyParser(lexer);
 * parser.setFilename(filename);
 * parser.setASTNodeClass("antlraux.util.LexInfoAST");
 * </pre>
 * In order to obtain the right filenames, you'll also have to
 * specify a Token type different from the default ({@link antlr.CommonToken}),
 * for example {@link LexInfoToken} (you should read that link if you're
 * using antlr ver. 2.7.2 at least; there's a little problem with filenames).
 * <p>
 * When working with ASTs that are not of the default type 
 * ({@link antlr.CommonAST }) in tree parsers, it is usually usefull
 * using the <tt>ASTLabelType</tt> option:
 * <pre>
 * header {
 * import antlraux.util.LexInfoAST;	
 * }
 *
 * class MyTreeParser extends TreeParser;
 * options{
 *    ASTLabelType = antlraux.util.LexInfoAST;
 * }
 * </pre>
 * This makes a lot of authomatic castings to <tt>LexInfoAST</tt>, saving
 * a lot of writing to the programmer. But it only works for grammars
 * that parse trees of type <tt>LexInfoAST</tt> (or subclasses of it).
 *
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 * @see LexInfoToken
 * @see LexInfo
 **/
public class LexInfoAST extends antlr.CommonAST
implements LexInfo
{
	private String filename = LexInfo.DEFAULT_FILENAME;
	private int line        = LexInfo.DEFAULT_LINE;
	private int column      = LexInfo.DEFAULT_COLUMN;
	
    /** 
     * Default constructor. Every AST implementation
     * must provide a default constructor in order to be
     * created in a parser or treeparser
     **/
    public LexInfoAST() 
    {
    	super();	
    }
    
    /** Calls {@link antlraux.util.LexInfoAST#initialize(antlr.Token)} */
    public LexInfoAST(Token tok) 
    {
		initialize(tok);
    }
    
    /** Calls {@link antlraux.util.LexInfoAST#initialize(int,String)} */
    public LexInfoAST(int type, String text)
    {
		initialize(type, text);
    }
    
	/** Calls {@link antlraux.util.LexInfoAST#initialize(antlr.collections.AST)} */
    public LexInfoAST(AST ast) 
    {
		initialize(ast);
    }

	/**
	 * Firstly this method calls <tt>super.initialize(ast)</tt>
	 * Then it checks if ast is <tt>instanceof</tt> 
	 * {@link antlraux.util.LexInfoAST}. If yes, it copies its
	 * lex info using
	 * {@link antlraux.util.LexInfoAST#copyLexInfo(antlraux.util.LexInfo)}
	 * @param ast The AST whose information is to be copied
	 **/
	public void initialize(AST ast)
	{
		super.initialize(ast);

		if(ast instanceof LexInfoAST)
		{
			this.copyLexInfo((LexInfoAST)ast);
		}
	}

	/**
	 * Firstly this method calls <tt>super.initialize(token)</tt>
	 * Then it copies filename, line and column information from
	 * the Token.
	 * @param t The token whose information is to be copied
	 **/
	public void initialize(Token t)
	{
		super.initialize(t);

		setFilename(t.getFilename());
		setLine(t.getLine());
		setColumn(t.getColumn());
	}
	
    /** Get the file name for this node */
    public String getFilename()
    { return filename; }
    
    /** Get the file name for this node **/
    public int getColumn()
    { return column; }
    
    /** Get the file name for this node **/
    public int getLine()
    { return line; }
    
    /** Set the file name for this node.**/
    public void setFilename(String fn)
    { filename = fn; }
    
    /** Set the file name for this node **/
    public void setColumn(int column)
    { this.column = column; }
    
    /** Set the file name for this node **/
    public void setLine(int line)
    { this.line = line; }
    
    /**
     *  Copies filename, line and column from "from"
     *  @param from The lex info provider
     ***/
    public void copyLexInfo(LexInfo from)
    {
    	if(from!=null)
    	{
    		this.filename = from.getFilename();
    		this.line = from.getLine();
    		this.column = from.getColumn();
    	}
    }
    
    /**
     * Returns a string representing the lexInfo of the
     * AST (filename:line:column). If any information is ommitted
     * (like when filename==null or line==-1) then it is not
     * included in the resulting String.
     */
    public String getLexInfoString()
	{
		FileLineFormatter f = FileLineFormatter.getFormatter();
		return f.getFormatString(filename, getLine(), getColumn());
	}
	
	/**
	 *  It returns the sibling
	 *  that precedes "child" in the children list.
	 *  @param child the child whose left sibling is being 
	 *         searched
	 *  @return null if child is the first child of the list or 
	 *           if it is not a child of "this".
	 **/
	public AST getPrevChild(AST child)
	{
		AST iterator = getFirstChild();
		
		while(iterator!=null)
		{
			if(iterator.getNextSibling()==child)
				return iterator;
			iterator=iterator.getNextSibling();
		}
		
		return null;
	}
	
	/**
	 *  Returns the last child of the children, or null if there
	 *  are no children
	 *  @return the last child of the children list, or null
	 *  if no children are found
	 **/
	public AST getLastChild()
	{
		AST currChild = getFirstChild();
		if(null == currChild) return null;
		while(currChild.getNextSibling()!=null)
		{
			currChild = currChild.getNextSibling();
		}
		
		return currChild;
	}
	
	/**
	 *  It returns the last sibling of the sibling list. If no
	 *  siblings, returs this.
	 *  @return the last sibling, or "this" if no siblings are found
	 **/
	public AST getLastSibling()
	{
		AST currSibling = this;
		
		while(currSibling.getNextSibling()!=null)
		{
			currSibling = currSibling.getNextSibling();
		}
		
		return currSibling;
	}
	
	/**
	 * Adds a sibling to the sibling list, without erasing
	 *  @param newLastSibling The new last sibling. If it is
	 *         null then the method does nothing
	 **/
	 public void addSibling(AST newLastSibling)
	 {
	 	if(newLastSibling!=null)
	 	{
	 		AST prevLastSibling = this.getLastSibling();
	 		prevLastSibling.setNextSibling(newLastSibling);
	 	}
	 }

	/**
	 *  Similar to <tt>AST.addChild(AST)</tt>, but this one inserts the child 
	 *  <b>at the beginning</b> of the children list, instead of
	 *  at the end. If null==newFirstChild, then the children list
	 *  will be erased.
	 *  <b>This method erases any siblings of newFirstChild</b>
	 *  and adds the current tree's children as siblings
	 *  @param newFirstChild the new first child
	 **/
	public void addChildLeft(AST newFirstChild)
	{
		AST oldFirstChild = (LexInfoAST)(getFirstChild());
		
		setFirstChild(newFirstChild);
		
		if( null!=newFirstChild )
		{
			newFirstChild.setNextSibling(oldFirstChild);
		}
	}
	
	/**
	 *  Similar to {@link LexInfoAST#addChildLeft(AST)},
	 *  but conservating newFirstChild's sibling list.
	 *  If null==newFirstChild, then the children
	 *  list will be erased.
	 *  @param newFirstChild the new first child
	 **/
	 public void addChildLeftWithSiblings(AST newFirstChild)
	 {
	 	AST oldFirstChild = getFirstChild();
		
		setFirstChild(newFirstChild);
		
		if( null!=newFirstChild)
		{
			AST currSibling = newFirstChild;
			while(currSibling.getNextSibling()!=null)
			{
				currSibling = currSibling.getNextSibling();
			}
			currSibling.setNextSibling(oldFirstChild);			
		}
	 }
	 
	/**
	 * Replaces a child node (prevAST) with another one (newAST)
	 * <b>This method erases any siblings of newAST</b>
	 *  and adds the current tree's children as siblings
	 * @return true if the replacement was successful, false
	 *          otherwise (prevAST was not a child of this).
	 * @param prevAST the AST that is going to be substituted
	 * @param newAST the new AST
	 */
	public boolean replaceChild( AST prevAST,
	                             AST newAST )
	{
		if(null==prevAST) return false;

		if(prevAST==getFirstChild())
		{
			this.setFirstChild(newAST);
			newAST.setNextSibling(prevAST.getNextSibling());
			return true;
		}
		else
		{
			AST leftAST = getPrevChild(prevAST);
			if(leftAST!=null)
			{
				leftAST.setNextSibling(newAST);
				newAST.setNextSibling(prevAST.getNextSibling());
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * Similar to {@link LexInfoAST#replaceChild(AST,AST)},
	 * but conservating newAST's sibling list (current tree's
	 * children are added after that list).
	 * @return true if the replacement was successful, false
	 *          otherwise (prevAST was not a child of this).
	 * @param prevAST the AST that is going to be substituted
	 * @param newAST the new AST
	 */
	public boolean replaceChildWithSiblings( AST prevAST,
	                                         AST newAST )
	{
		if(prevAST==null) return false;
		if(prevAST==getFirstChild())
		{
			this.setFirstChild(newAST);
			AST currSibling = newAST;
			while(currSibling.getNextSibling()!=null)
				currSibling=currSibling.getNextSibling();
			currSibling.setNextSibling(prevAST.getNextSibling());
			return true;
		}
		else
		{
			AST leftAST = getPrevChild(prevAST);
			if(leftAST!=null)
			{
				leftAST.setNextSibling(newAST);
				AST currSibling = newAST;
				while(currSibling.getNextSibling()!=null)
					currSibling=currSibling.getNextSibling();
				currSibling.setNextSibling(prevAST.getNextSibling());

				return true;
			}
		}
		
		return false;
	}
	
	protected static boolean verboseStringConversion = false;
	
	/** When set to true, adds information to {@link LexInfoAST#toString()} **/
	public static void setVerboseStringConversion (boolean b)
	{ verboseStringConversion = b; }
	
	/**
	 * Returns a String representing the information in the root 
	 * of the node. If {@link LexInfoAST#setVerboseStringConversion(boolean)}
	 * has been set to true, it adds the lex information of
	 * the AST (using {@link LexInfoAST#getLexInfoString()})
	 **/
	public String toString()
	{
		StringBuffer sb =
			new StringBuffer(super.toString());
		if(verboseStringConversion)
		{
			sb.append(" (lexInfo: ");
			sb.append(getLexInfoString());
			sb.append(")");
		}
		
		return sb.toString();		
	}
	

	private static final String nl = System.getProperty("line.separator");

	protected static void tabulate(int t, StringBuffer sb)
	{
		sb.append(nl);
		for(int i=0; i<t; i++) sb.append("  ");
	}

	public String toStringList()
    { return toStringList(0); }
	
	/** Print out a child-sibling tree in LISP notation */
    public String toStringList(int tabLevel)
    {
        AST t = this;
        StringBuffer sb = new StringBuffer();
        
        tabulate(tabLevel, sb);
        if (t.getFirstChild() != null) sb.append("( ");
        sb.append(this.toString());
        
        if (t.getFirstChild() != null) {
            sb.append(((LexInfoAST)t.getFirstChild()).toStringList(tabLevel+1));
            tabulate(tabLevel, sb);
            sb.append(")");
    	}
        if (t.getNextSibling() != null) {
            sb.append(((LexInfoAST)t.getNextSibling()).toStringList(tabLevel));
        }
        return sb.toString();
    }

    public String toStringTree()
    {
        AST t = this;
        StringBuffer sb = new StringBuffer();

        if (t.getFirstChild() != null) sb.append("( ");
        sb.append(this.toString());
        
        if (t.getFirstChild() != null) {
            sb.append(
            	((LexInfoAST)t.getFirstChild()).toStringList(1));

            sb.append(nl);
            sb.append(")");
    	}
        
        return sb.toString();
    }
}