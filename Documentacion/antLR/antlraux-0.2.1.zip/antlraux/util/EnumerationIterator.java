
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.util;

import java.util.Iterator;
import java.util.Enumeration;

/**
 * Transforms an {@link java.util.Enumeration} in an
 * {@link java.util.Iterator}. It does NOT give a real
 * implementation of {@link java.util.Iterator#remove()}
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 * @see antlraux.util.IteratorEnumeration
 **/ 
public class EnumerationIterator implements Iterator
{
	Enumeration e = null;
	public EnumerationIterator(Enumeration e)
	{ this.e = e; }
	
	public boolean hasNext()
	{ return e.hasMoreElements(); }
	
	public Object next()
	{ return e.nextElement(); }
	
	public void remove()
	{
		// do nothing
	}
}
