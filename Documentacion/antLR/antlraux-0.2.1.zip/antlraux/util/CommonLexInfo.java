
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.util;

import antlr.FileLineFormatter;

/**
 *  This is a class that completely implements interface
 *  {@link LexInfo}. Use it as a base class to implement
 *  {@link LexInfo} directly.
 *  @author Enrique Jos&eacute; Garc&iacute;a Cota
 **/
public class CommonLexInfo
{

    /** line information **/
    protected int line  = LexInfo.DEFAULT_LINE;
    
    /** column information **/
    protected int column = LexInfo.DEFAULT_COLUMN;
    
    /** filename information **/
    protected String filename = LexInfo.DEFAULT_FILENAME;
    
    public CommonLexInfo()
    { }
    
    public CommonLexInfo(String filename, int line, int column)
    {
    	setFilename(filename);
    	setLine(line);
    	setColumn(column);
    }
    
    public CommonLexInfo(LexInfo other)
    {
    	copyLexInfo(other);
    }
    
    /** Get the file name for this node */
    public String getFilename() { return filename; }
    
    /** Get the column for this node */
    public int getColumn() { return column; }
    
    /** Get the line for this node */
    public int getLine() { return line; }
    
    /** Sets the file name for this node. **/
    public void setFilename(String fn) { filename = fn; }
       
    /** Set the column for this node **/
    public void setColumn(int column) { this.column = column; }
    
    /** Set the line for this node **/
    public void setLine(int line) { this.line = line; }
    
    /** Copies the lexical information from other LexInfo **/
    public void copyLexInfo(LexInfo from)
    {
    	if(from!=null)
    	{
    		setColumn(from.getColumn());
    		setLine(from.getLine());
    		setFilename(from.getFilename());
    	}
    }
    
    /**
     * Returns true if all the information (Filename:line:column)
     * is valid; false otherwise. It will usually be implemented
     * around a {@link antlr.FileLineFormatter}, which authomatically
     * deals with incompleteness in the information.
     */
    public String getLexInfoString()
    {
    	FileLineFormatter flf = FileLineFormatter.getFormatter();
    	
    	return flf.getFormatString(filename,line,column);
    }
}