
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.util;

import antlr.FileLineFormatter;
import antlr.RecognitionException ;

/**
 * This is a version of {@link antlr.RecognitionException} that
 * implements {@link LexInfo}
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 **/
public class LexInfoException extends RecognitionException
implements LexInfo
{
	public LexInfoException() { super(); }
	
	public LexInfoException(String s) { super(s); }
	
	public LexInfoException(String s, String fileName, int line, int column)
	{
		super( s, fileName, line, column );
	}
	
	public LexInfoException(String s, LexInfo li)
	{
		super( s, li.getFilename(), li.getLine(), li.getColumn() );
	}
	
	public void copyLexInfo(LexInfo li)
	{
		this.setLine(li.getLine());
		this.setColumn(li.getColumn());
		this.setFilename(li.getFilename());
	}
	
	public String getLexInfoString()
	{
		FileLineFormatter flf = FileLineFormatter.getFormatter();
		return flf.getFormatString(this.getFilename(),
		                           this.getLine(),
		                           this.getColumn() );
	}
	
	public void setFilename(String s) { this.fileName = s; }
	
	public void setLine(int l) { line = l;}
	
	public void setColumn(int c) { column = c; }
	
}