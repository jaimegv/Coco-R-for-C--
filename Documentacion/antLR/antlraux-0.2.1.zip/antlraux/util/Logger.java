
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.util;

import java.io.OutputStream;
import java.io.Writer;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.io.IOException;

import antlr.FileLineFormatter;
import antlr.RecognitionException;

/**
 * This class can be used for maintaining logs.
 * It admits log entries relative to lexical coordinates (a filename, 
 * line and column) and non relative entries (no lex info).
 * It also offers other services like tabulation facilities,
 * log count and log deactivation (you can define the minimum
 * level that a message has to have in order to be logged).
 * <p>
 * Usually you will want to use this class in conjuction with
 * your analizers. In order to do that, you'll have to create
 * your logger and override reportError:
 * <pre>
 * header{
 *   import antlraux.util.Logger;
 * }
 *
 * public class MyParser extends Parser;
 * options {...}
 * tokens  {...}
 * // code zone
 * {
 *    Logger logger = new Logger(...); // add your params here
 *    public void reportError(RecognitionException re)
 *    {
 *       logger.log( re.getMessage(), re.getFileName(),
 *                   re.getLine(), re.getColumn() );
 *    }
 * }
 * </pre>
 * This works more or less the same way for lexers and treeparsers.
 */
public class Logger
{	
	/** Tabulation level **/
	protected int tabLevel = 0;
	/** Minimum level of the messages (default -1; shows all messages) **/
	protected int minLogLevel = -1;
	/** Counter **/
	protected int logCounter = 0;
	/** The name of the Logger **/
	protected String name = null;
	/** String used in tabulations **/
	protected String tabString = null;
	/** String used for new lines **/
	protected String newLineString = null;
	/** The file line formatter **/
	protected FileLineFormatter flf = null;
	/** The log's writer **/
	private Writer writer = null;
	/** The log's output stream **/
	protected OutputStream os = null;
	
	private void initialize()
	{
		tabLevel = 0;
		if( null == newLineString )
			setNewLineString(System.getProperty("line.separator"));
		if( null == tabString )
			setTabString ("\t");
		if( null == os )
			setOutputStream(System.out);
		if( null == flf )
			setFileLineFormatter(FileLineFormatter.getFormatter());
	}
	
	/** Creates a new logger with a certain name **/
	public Logger(String name)
	{
		this.name = name;
		initialize();
	}
	
	/** Specifies name and output stream **/
	public Logger( String name, OutputStream os )
	{
		this.name = name;
		setOutputStream(os);
		initialize();
	}
	
	/** Specifies nearly everything **/
	public Logger( String name,
	               OutputStream os,
	               String newLineString,
	               String tabString)
	{
		this.name = name;
		setOutputStream(os);
		setNewLineString (newLineString);
		setTabString(tabString);
		initialize();
	}
	
	/** Specifies everything **/
	public Logger( String name,
	               OutputStream os,
	               String newLineString,
	               String tabString,
	               FileLineFormatter flf )
	{
		this.name = name;
		setOutputStream(os);
		setNewLineString (newLineString);
		setTabString(tabString);
		setFileLineFormatter(flf);
		initialize();
	}
	
	/** Prints a message to the Logger's output stream **/
	public void print( String msg )
	{
		try
		{
			writer.write( msg );
			writer.flush();
		}
		catch (Exception e)
		{ System.err.println("print("+msg+") failed"); }
	}
	
	/**
	 *  Adds a log with a certain level. This log will only be
	 *  processed if <tt>msgLevel>minLogLevel</tt>. If the log
	 *  is processed, {@link Logger#logCounter} is incremented.
	 **/
	public void log ( String msg, int msgLevel )
	{
		if(msgLevel >= minLogLevel)
		{
			tabulate();
			print(name);
			print(": ");
			print(msg);
			newLine();
			logCounter ++;
		}
	}
	
	/** A log with lex info **/
	public void log( String msg,
	                 int msgLevel,
	                 String filename,
	                 int line,
	                 int column )
	{
		if(msgLevel>=this.minLogLevel)
		{
			StringBuffer sb =
				new StringBuffer( flf.getFormatString( filename, line, column ) );
			sb.append( msg );
	        
			log( sb.toString(), msgLevel );
		}
	}
	
	/** A log with lex info **/
	public void log( String msg, int msgLevel, LexInfo li)
	{
		if(msgLevel>this.minLogLevel)
		{
			StringBuffer sb =
				new StringBuffer( li.getLexInfoString() );
			sb.append(msg);
			
			log( sb.toString(), msgLevel);
		}
	}
	
	
	/**
	 * Prints the string "{@link #tabString}" {@link #tabLevel} times 
	 * on the Logger's outputStream.
	 **/
	public void tabulate()
	{
		for( int i=0; i<this.tabLevel; i++ )
		{
			print(tabString);
		}
	}
	
	/**
	 * Prints the string {@link #newLineString} once on the
	 * Logger's outputStream
	 **/
	public void newLine()
	{ print(newLineString); }
	
	/** Increments {@link #tabLevel} in one unit **/
	public void incTabs()
	{ tabLevel++; }
	
	/** Decrements {@link #tabLevel} by one unit **/
	public void decTabs()
	{ tabLevel--; }
	
	/** Accessor for {@link #logCounter} **/
	public int getLogCounter()
	{ return logCounter; }
	
	/** Makes {@link #logCounter}=0 **/
	public void resetLogCounter()
	{ logCounter = 0 ; }
	
	/** Accessor for {@link #name} **/
	public String getName()
	{ return name; }
	
	/** Accessor for {@link #minLogLevel} **/
	public int getMinLogLevel()
	{ return minLogLevel; }
	
	/** Accessor for {@link #minLogLevel} **/
	public void setMinLogLevel(int newMin)
	{ minLogLevel = newMin; }
	
	/** Accessor for {@link #tabLevel} **/
	public int getTabLevel() { return tabLevel; }
	
	/**
	 * Accessor for {@link #tabLevel}. You should use
	 * {@link #incTabs()} and {@link #decTabs()} instead of
	 * this method whenever possible.
	 **/
	public void setTabLevel(int t) { tabLevel=t; }
	
	/** Accessor for {@link #tabString} **/
	public String getTabString() { return tabString; }
	
	/** Accessor for {@link #tabString} **/
	public void setTabString(String ts) { tabString = ts; }
	
	/** Accessor for {@link #newLineString} **/
	public String getNewLineString() { return newLineString; }
	
	/** Accessor for {@link #newLineString} **/
	public void setNewLineString(String s) { newLineString=s; }
	
	/** Accessor for {@link #flf} **/
	public FileLineFormatter getFileLineFormatter()
	{ return flf; }
	
	/** Accessor for {@link #flf} **/
	public void setFileLineFormatter (FileLineFormatter flf)
	{ this.flf = flf; }
	
	/** Accessor for {@link #os} **/
	public void setOutputStream(OutputStream newOs)
	{
		this.os = newOs;
		this.writer = new BufferedWriter(
			new OutputStreamWriter(os));
	}
}