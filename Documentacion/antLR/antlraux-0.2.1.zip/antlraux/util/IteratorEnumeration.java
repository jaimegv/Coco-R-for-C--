
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.util;

import java.util.Iterator;
import java.util.Enumeration;

/**
 * Transforms an {@link java.util.Iterator} in an
 * {@link java.util.Enumeration}.
 * @see antlraux.util.EnumerationIterator
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 **/ 
public class IteratorEnumeration implements Enumeration
{
	Iterator i = null;
	public IteratorEnumeration(Iterator i)
	{
		this.i = i;
	}
	
	public boolean hasMoreElements()
	{ return i.hasNext(); }
	
	public Object nextElement()
	{ return i.next(); }

}
