

Hi, and welcome to antlraux v0.2.1.

This readme file will evolve with time, right now you just have to know that:

- For information about antlraux, you should see
  http://antlraux.sf.net
- If you want to recompile anlraux, then make sure antlr is in the classpath.
- In order to generate javadoc documentation, you can use javadoc-options.txt,
  like this: javadoc @javadoc-options.txt. You'll surely want to change -classpath 
  and -bootclasspath options to respectively point to antlr's directory and jsdk's main jar.
- antlraux is distributed under the BSD license. See file license.txt
  for details.
  
Enrique Jose Garcia Cota