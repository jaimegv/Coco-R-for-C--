/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.context;

import antlr.collections.AST;
import java.util.LinkedList;

/**
 * The main class for managing contextual information.
 * <p>
 * This class is implemented around the {@link Scope} class. One
 * could say it's just a thin wrapper around it.
 * <p>
 * <tt>Context</tt> is thought to be subclassed. In most cases
 * they'll add a bunch of methods adapted to each language's
 * particuarities. This way, they may add:
 * <ul> <li> <b>Scope opening methods</b>,
 *           like <tt>openClassScope(String className)</tt>,
 *           <tt>openMethodScope(String methodName)</tt>, etc.
 *      </li>
 *      <li> <b>Scope closing methods</b>
 *           like <tt>coseClassScope()</tt>,
 *           <tt>closeMethodScope()</tt>, etc.
 *      </li>
 *      <li> <b>Declaration insertion methods</b>,
 *           like <tt>insertVariableDec(String varName, Tag varTag)</tt>,
 *           <tt>insertClassDec(ClassTag t)</tt>, etc.
 *      </li>
 *      
 * </ul>
 * You may bypass the use of Context and use {@link Scope} directly.
 * See its comments for further information.
 * @see Scope
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 **/
public abstract class Context
{	
	private Scope currentScope = null;
	private Scope rootScope    = null;
	
	/**
	 *  It creates a default scope if no other is specified
	 **/
	public Context(int rootScopeTag, String rootScopeName)
	{
		currentScope = new Scope(rootScopeTag, rootScopeName);
		rootScope = currentScope;
	}
	
	/**
	 * Uses a given scope as root scope
	 **/	
	public Context(Scope rootScope)
	{
		this.currentScope = rootScope;
		this.rootScope = rootScope;
	}

	/**
	 *  Inserts a declaration in the current scope.
	 *  @throws ContextException if a subclass overrides the insertion and throws it
	 **/
	public void insert( Declaration d )
	throws ContextException
	{	
		// If everything is ok, insert the object
		currentScope.insert(d);
	}
	
	/**
	 *  Opens a new scope
	 *  @return the new Scope
	 *  @throws ContextException if a subclass throws it
	 **/
	public Scope openScope( Scope newScope )
	throws ContextException
	{
		newScope.setFather(currentScope);
		setCurrentScope(newScope);
		return newScope;
	}
	
	/**
	 *  Opens a new scope
	 *  @return the new scope
	 *  @throws ContextException depending on {@link Context#openScope(Scope)}
	 **/
	public Scope openScope( int scopeTag, String scopeName )
	throws ContextException
	{
		return openScope( new Scope(scopeTag, scopeName, currentScope) );
	}
	
	/** Returns the scope **/
	public Scope getCurrentScope()
	{ return currentScope; }
	
	/** Sets current scope **/
	public void setCurrentScope(Scope s)
	{ currentScope = s; }
	
	/** Gets the root scope **/
	public Scope getRootScope()
	{ return rootScope; }
	
	/** Sets the current scope to the root scope **/
	public void toRoot()
	{ currentScope = rootScope; }
	
	/**
	 *  Sets the current scope to point to the father
	 *  @return the previous scope
	 **/
	public Scope toFather()
	{
		Scope prev = currentScope;
		currentScope = currentScope.getFather();
		return prev;
	}
		
	/**
	 *  Closes the current scope
	 *  @return the *recently closed* scope (the OLD one)
	 *  @throws ContextException if "name" does not match the
	 *  current scope's name or if the stack is empty
	 **/
	public Scope closeScope( int tag )
	throws ContextException
	{	
		if( currentScope.getTag() != tag )
		{
			throw new ContextException (
				"Scope tag mistmatch; tried to close '"+tag+
				"' but the current scope ("+
				currentScope.getName()+") has the tag '"+
				currentScope.getTag() +"'" );
		}
		
		if( null == currentScope.getFather() )
		{
			throw new ContextException (
				"Could not close current scope '" +
				currentScope.getName() +
				"' because it is the root scope");
		}
		
		Scope oldScope = currentScope;
		
		setCurrentScope(currentScope.getFather());
		
		return oldScope;
	}	
}