
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.context.types;

/**
 * This is a very simple interface that modelizes the "isA" relationship
 **/
public interface HeritableType extends Type
{	
	public boolean isA(HeritableType type);
}