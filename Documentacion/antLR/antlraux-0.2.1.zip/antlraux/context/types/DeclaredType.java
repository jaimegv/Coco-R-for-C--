
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.context.types;

import antlraux.util.IteratorEnumeration;

import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Enumeration;

/**
 *  This class is an extension of {@link CommonType} that 
 *  implements {@link ModifiedType}, so it implements a very basic
 *  {@link Type} with modifiers.
 *  <p>
 *  The real interest of this class is subclassing. See {@link ClassType}.
 *  @author Enrique Jos&eacute; Garc&iacute;a Cota
 **/
public class DeclaredType extends CommonType
implements ModifiedType
{
	protected  HashSet modifiers = new HashSet();
	
	public DeclaredType()
	{ }
	
	public DeclaredType( int tag, String typeName )
	{
		super(tag, typeName);
	}
	
	public boolean hasModifier(String modifierName)
	{ return modifiers.contains(modifierName); }
	
	public void addModifier(String modifier)
	{ modifiers.add(modifier); }
	
	public void clearModifiers()
	{ modifiers.clear(); }
	
	public Enumeration modifiers()
	{ return new IteratorEnumeration(modifiers.iterator()); }
	
	public Set modifiersSet()
	{ return modifiers; }
	
	public boolean equals(Object other)
	{
		if( !(other instanceof DeclaredType) )
			return false;
		else
		{
			DeclaredType otherDT = (DeclaredType)other;
			
			if( !this.getName().equals(otherDT.getName()) )
				return false;
			return compareModifiers(otherDT);
		}
	}
	
	public boolean compareModifiers(ModifiedType other)
	{
		return this.modifiers.equals(other.modifiersSet());
	}
	
	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		for( Enumeration e = this.modifiers(); e.hasMoreElements(); )
		{
			sb.append(e.nextElement());
			sb.append(" ");
		}
		     
		return "";
	}

}