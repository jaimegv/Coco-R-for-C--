
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.context.types;

import antlraux.util.IteratorEnumeration;

import antlraux.context.Scope;

import java.util.LinkedList;
import java.util.Iterator;
import java.util.Enumeration;

/**
 * This is a basic implementation of {@link MethodType} inferface.
 **/
public class MethodType extends DeclaredType
implements ScopedType, ClassMemberType
{
	/** The method's return type **/
	protected Type returnType=null;
	
	/** A list of parameter types **/
	protected LinkedList params=new LinkedList();
	
	/** The class that holds the method **/
	protected Type classType = null;
	
	/** Stores the method's scope **/
	protected Scope scope=null;
	
	public MethodType( int tag,
	                   String typeName,
	                   Type returnType,
	                   ClassType classType,
	                   Scope s )
	{
		super(tag, typeName);
		setReturnType(returnType);
		setClassType(classType);
		setScope(s);
	}
	

	public Type getReturnType() { return returnType; }
	
	public void setReturnType(Type t)
	{
		if(null==t)
			throw new IllegalArgumentException(
				"A return type is needed");
		this.returnType = t;
	}
	
	public Enumeration params()
	{
		return new IteratorEnumeration(params.iterator());
	}
	
	public void addParam(Type type)
	{ params.add(type); }
	
	public void clearParams()
	{ params.clear(); }
	
	public void setClassType(Type classType)
	{
		if (classType==null)
		{
			throw new IllegalArgumentException(
				"A classType is needed");
		}
		this.classType = classType;
	}
	
	public Type getClassType()
	{ return classType; }
	
	public Scope getScope() { return scope; }
	
	public void setScope(Scope s) { scope = s; }
		
	public boolean compatibleWith( MethodType other )
	{	
		return compatibleWith(other, true, false, false);
	}
	
	public boolean compatibleWith( MethodType other,
	                               boolean compareName,
	                               boolean compareReturnType,
	                               boolean compareModifiers )
	{
	
		// If they don't have the same name, return false
		if( compareName &&
			!this.getName().equals(other.getName()) )
			return false;
		
		// If they don't have the same return type, return false
		if( compareReturnType &&
		    !getReturnType().equals(other.getReturnType()) )
		    return false;
		
		// If they don't have the same modifiers, return false
		if( compareModifiers &&
		    ! this.compareModifiers(other) )
		    return false;
		
		// Check if the param lists are compatible
		if( !this.compatibleParamLists(other) )
			return false;
		
		return true;
	}
	
	/**
	 *  Returns true if the two param lists are "compatible"
	 *  (they have the same length, and every parameter type is
	 *  compatible with its equivalent in the other list). We'll say
	 *  that two param types a and b are compatible if a call to
	 *  {@link #compatibleParams(Type,Type)}
	 *  (<tt>CompatibleParams(a,b)</tt>) returns true.
	 **/
	public boolean compatibleParamLists(MethodType other)
	{
		Type t1=null, t2=null;
		
		Enumeration e1 = this.params();
		Enumeration e2 = other.params();
		
		while( e1.hasMoreElements() && e2.hasMoreElements() )
		{
			if(! compatibleParams( (Type)(e1.nextElement()),
			                       (Type)(e2.nextElement()) ) )
				return false;
		}
		
		if(e1.hasMoreElements() || e2.hasMoreElements())
			return false;
		
		return true;
	}
	/**
	 *  Returns true if
	 *  <ul>
	 *  <li>both <tt>myType</tt> and <tt>hisType</tt> implement
	 *      {@link HeritableType}, and <tt>hisType.isA(myType)</tt></li>
	 *  <li><tt>myType.equals(hisType) || hisType.equals(myType)</tt></li>
	 *  </ul>
	 **/
	public boolean compatibleParams(Type myType, Type hisType)
	{
		if( myType instanceof HeritableType &&
		   	hisType instanceof HeritableType )
		{
			if ( ((HeritableType)hisType).isA((HeritableType)myType) )
				return true;
		}
		else if( hisType.equals(myType)
		     ||  myType.equals(hisType) )
			return true;
		
		return false;
	}

	public String toString()
	{
		StringBuffer sb =
			new StringBuffer(this.getReturnType().toString());
		sb.append( " " );
		sb.append( this.getName() );
		sb.append( "( ");
		
		boolean comma = false;
		for( Iterator it = this.params.iterator();
		     it.hasNext(); )
		{
			if(comma) sb.append(", ");
			comma = true;
			sb.append(it.toString());
		}
		
		sb.append( " )");
		
		return sb.toString();
	}
}