
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.context.types;

import antlraux.util.IteratorEnumeration;
import antlraux.context.Scope;
import antlraux.context.ContextException;
import antlraux.context.Declaration;

import java.util.Enumeration;
import java.util.LinkedList;
import java.util.Iterator;

/**
 * This class represents a Type that modelizes the type of a 
 * class, this is, a set of data and a set of methods.
 * <p>
 * It implements {@link ModifiedType}, so it can deal with
 * modifiers like "public", "protected", etc.
 * <p>
 * It supports simple inheritance thanks to the implementation
 * of {@link SimpleInheritanceType}.
 * <p>
 * Since it also implements {@link ScopedType}, it contains
 * a referente to an instance of {@link antlraux.context.Scope}. It
 * is in that instance of scope that the represented class' 
 * attributes (data, not methods) are stored. It is in this
 * scope where all methods and attributes should be.
 **/
public class ClassType extends DeclaredType
implements ModifiedType, ScopedType, SimpleInheritanceType
{
	/** The Type of this Type's class super class :) **/
	protected ClassType superType = null;
	
	/** The scope where attribute definitions will be stored **/
	protected Scope scope = null;
	
	public ClassType( int tag,
	                  String typeName,
	                  ClassType superType,
	                  Scope s )
	{
		super(tag, typeName);
		// not using setSuperType here - throws TypeException
		this.superType = superType;
		setScope(s);
	}

	/** Accessor for {@link #superType} **/
	public SimpleInheritanceType getSuperType()
	{ return superType; }
	
	/**
	 * Accessor for {@link #superType}
	 * @param superType the new super class
	 * @throws TypeException if (superType!=null and is not an
	 *         instance of {@link ClassType}) or if
	 *         <tt>superType.isA(this)</tt>
	 * @see HeritableType#isA(HeritableType)
	 **/      
	public void setSuperType(SimpleInheritanceType superType)
	throws TypeException
	{
		if(superType!=null && ! (superType instanceof ClassType) )
			throw new IllegalArgumentException(
				"An instance of ClassType (or null) is needed for the super class");
		
		if(superType!=null && superType.isA(this))
			throw new TypeException(
				"Type '" + superType +
				"' can not be set as super type of type '"+
				this + "' because '"+this+
				"' is already a super type of '" +
				superType+ "'" );

		this.superType = (ClassType)superType;
	}
	
	/** Accessor for {@link #scope} **/
	public Scope getScope()
	{ return scope; }
	
	/** Accessor for {@link #scope} **/
	public void setScope(Scope s)
	{ this.scope = s; }

	public boolean isA(HeritableType superType)
	{
		SimpleInheritanceType currentType = this;
		
		while(currentType!=null)
		{
			if(currentType==superType)
				return true;
			currentType = currentType.getSuperType();
		}
		return false;
	}
	
	public String toString()
	{
		return getName();
	}
	
	public void addSuperClassAttributes(int attributesTag)
	throws ContextException
	{
		if(null == this.getSuperType()) return;
		
		Scope myScope = getScope();
		Scope hisScope = ((ScopedType)(getSuperType())).getScope();
		
		if(null == myScope || null == hisScope) return;
			
		LinkedList myAttributes = myScope.searchAll(attributesTag);
		LinkedList hisAttributes = hisScope.searchAll(attributesTag);
			
		if(null==myAttributes)
		{
			myScope.addDeclarations(hisAttributes);
		}
		else
		{
			if(null==hisAttributes) return;
			Declaration d1, d2;
			Iterator it1, it2;
			boolean bFound = false;
			for(it1 = hisAttributes.iterator(); it1.hasNext(); )
			{
				d1 = (Declaration)it1.next();
				bFound = false;
				for(it2 = myAttributes.iterator(); it2.hasNext(); )
				{
					d2 = (Declaration)it2.next();
					if(d2.getName().equals(d1.getName()))
						bFound = true;
				}
				
				if(!bFound)
					myAttributes.add(d1);
			}
		}
	}
	
	public void addSuperClassMethods(int methodTag)
	throws ContextException
	{
		if(null == this.getSuperType()) return;
		
		Scope myScope = getScope();
		Scope hisScope = ((ScopedType)(getSuperType())).getScope();
		
		if(null == myScope || null == hisScope) return;
		
		LinkedList myMethods = myScope.searchAll(methodTag);
		LinkedList hisMethods = hisScope.searchAll(methodTag);
		
		if(null==myMethods)
		{
			myScope.addDeclarations(hisMethods);
		}
		else
		{			
			Declaration d1;
			MethodType m1, m2;
			Iterator it1, it2;
			boolean bFound = false;
			for(it1 = hisMethods.iterator(); it1.hasNext(); )
			{
				d1 = (Declaration)it1.next();
				m1 = (MethodType)d1.getType();
				bFound = false;
				for(it2 = myMethods.iterator(); it2.hasNext(); )
				{
					m2 = (MethodType)((Declaration)it2.next()).getType();
					if(m2.compatibleWith(m1))
						bFound = true;
				}
				
				if(!bFound)
					myMethods.add(d1);
			}			
		}
	}
	
	public Declaration searchCompatibleMethod( int methodTag,
		                                       MethodType mt)
	{
		Scope myScope = getScope();
		if(null==myScope) return null;
		LinkedList myMethods = myScope.searchAll(methodTag);
		if(null==myMethods) return null;
		
		Declaration d;
		MethodType t;
		for(Iterator it = myMethods.iterator(); it.hasNext(); )
		{
			d = (Declaration)it.next();
			t = (MethodType)d.getType();
			if(t.compatibleWith(mt))
				return d;
		}
		
		return null;
	}
}

