
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.context.types;

import antlraux.util.IteratorEnumeration;

import antlraux.context.Scope;

import java.util.LinkedList;
import java.util.Iterator;
import java.util.Enumeration;

/**
 * Types that implement this interface are class members;
 * use it for methods, attributes and such.
 **/
public interface ClassMemberType extends Type
{
	public void setClassType(Type t);
	
	public Type getClassType();
}