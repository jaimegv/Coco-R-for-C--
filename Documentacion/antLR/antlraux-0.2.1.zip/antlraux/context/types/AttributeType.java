/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */


package antlraux.context.types;

import antlraux.util.IteratorEnumeration;

import antlraux.context.Scope;

import java.util.LinkedList;
import java.util.Iterator;
import java.util.Enumeration;

/**
 * This is a basic implementation of a class' attribute.
 **/
public class AttributeType extends DeclaredType
implements ClassMemberType
{
	/** The attribute's type **/
	protected Type type=null;
	
	/** The class that holds the attribute **/
	protected Type classType = null;
	
	public AttributeType( int tag,
	                      String name,
	                      Type type,
	                      ClassType classType )
	{
		super(tag, name);
		setClassType(classType);
		setType(type);
	}
	
	public void setType(Type t)
	{
		if(null==t)
		{
			throw new IllegalArgumentException(
					"A Type is needed for the attribute");
		}
		type = t;
	}
	
	public Type getType()
	{ return type; }
	
	public void setClassType(Type classType)
	{
		if (classType==null)
		{
			throw new IllegalArgumentException(
				"A classType is needed");
		}
		this.classType = classType;
	}
	
	public Type getClassType()
	{ return classType; }
	
	public String toString()
	{
		StringBuffer sb = new StringBuffer("attribute ");
		sb.append(type);
		sb.append(' ');
		sb.append(classType);
		sb.append('.');
		sb.append(name);
		return sb.toString();
	}
}