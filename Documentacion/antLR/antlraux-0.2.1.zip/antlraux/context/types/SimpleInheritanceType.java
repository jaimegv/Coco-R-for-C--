
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.context.types;

/**
 * This derived interface modelizes types that implement simple inheritance
 * (only one super class, no interfaces)
 **/
public interface SimpleInheritanceType
extends HeritableType
{	
	public SimpleInheritanceType getSuperType();
	
	public void setSuperType(SimpleInheritanceType superType)
	throws TypeException;
}