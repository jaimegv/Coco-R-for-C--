
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.context.types;

import antlraux.context.ContextException;

/**
 * Exception launched when an error is found in the type system.
 **/
public class TypeException extends ContextException
{
	public TypeException() { super(); }
	
	public TypeException(String s) { super(s); }
	
	public TypeException(String s, String fileName, int line, int column)
	{
		super( s, fileName, line, column );
	}
}

