
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.context.types;

import antlraux.context.Scope;

/**
 * This interface modelizes a Type that has a {@link antlraux.context.Scope},
 * like a class type or a method type.
 ***/
public interface ScopedType extends Type
{
	/** Sets the type's scope **/
	public void setScope(Scope s);
	
	/** Gets the type's scope **/
	public Scope getScope();
}