
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.context.types;

import antlr.Token;

/**
 * This interface is the main object of antlraux's type system.
 * A Type is a very basic object that only has two mandatory 
 * attributes: an integuer "tag" and a name.
 * <p>
 * Their functionality is similar to Token.type and Token.text,
 * but not exactly the same.
 * <p>
 * In most programmation languajes, there are some Tokens that
 * represent "basic types" - for example, token INT_TYPE represents
 * the Token wose text is allways "int" and wose token type
 * is INT_TYPE, whatever integer it is. The Type represented by that
 * token will have INT_TYPE as tag and "int" as name.
 * <p>
 * However other tokens don't act that way - take the class token.
 * A class definition may begin with a token with RES_CLASS type and
 * "class" text, but we're not sure of what type we're defining until
 * we see the class' name. Let's suppose that the class name's "A".
 * In this case, the Type represented will have RES_CLASS as tag,
 * but its name will be "A" instead of "class".
 * <p>
 * In conclusion, new Scope specifies the "type of Type" we're dealing with,
 * while name really makes difference between Types of the same type.
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 **/
public interface Type
{
	public String DEFAULT_NAME = null;
	public int DEFAULT_TAG     = Token.INVALID_TYPE;
	
	/** Returns the Type's name **/
	public String getName();
	
	/** Returns the Type's tag **/
	public int getTag();
	
	/**
	 * Sets the Type's name. It is recommended to check if the
	 * new name is null or empty string ("") and throw IllegalArgumentException 
	 * in that case.
	 **/
	public void setName(String s);
	
	/** Sets the Type's tag **/
	public void setTag(int tag);
	
	public boolean equals(Object other);
	
	public String toString();
}