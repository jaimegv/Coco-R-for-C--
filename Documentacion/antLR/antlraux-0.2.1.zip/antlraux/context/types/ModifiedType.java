
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */
 
package antlraux.context.types;

import java.util.Enumeration;
import java.util.Set;

/**
 * This interface represents a Type that has a set of modifiers
 * in the form of strings (like "public", "static", etc). 
 **/
public interface ModifiedType extends Type
{
	/** Adds a new modifier to the modifiers set **/
	public void addModifier(String modifierName);

	/** Returns true if the Type has the modifier "modifierName" **/
	public boolean hasModifier(String modifierName);
	
	/** Clears all modifiers **/
	public void clearModifiers();
	
	/** Returns the modifier list in form of Enumeration **/
	public Enumeration modifiers();
	
	/** Returns the modifiers set **/
	public Set modifiersSet();

	/** Returns true if other has the same modifiers than "this" **/
	public boolean compareModifiers(ModifiedType other);
}