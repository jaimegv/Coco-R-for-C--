
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.context.types;

/**
 * A very basic implementation of Type. This class can be used
 * to modelize the basic types of a languaje (like int or float).
 * For more complex types, use a subclass, for example
 * {@link DeclaredType}
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 **/
public class CommonType implements Type
{
	protected String name = Type.DEFAULT_NAME;
	protected int tag =     Type.DEFAULT_TAG;
	
	public CommonType() {}
	
	public CommonType(int tag, String name)
	{
		setName(name);
		setTag(tag);
	}
	
	public String getName() { return name; }
	public int getTag() { return tag; }
	
	public void setName(String s)
	{
		if(null==s || s.equals(""))
			throw new IllegalArgumentException("Must provide a name for the Type");
		this.name = s;
	}
	
	public void setTag(int tag)
	{ this.tag = tag; }
	
	public boolean equals(Object other)
	{
		if( ! (other instanceof Type) ) return false;
		
		Type t = (Type)other;
		
		if(this.tag != t.getTag()) return false;
		
		if(! this.name.equals(t.getName()) ) return false;
		
		return true;
	}
	
	public String toString()
	{
		return name.toString();
	}

}