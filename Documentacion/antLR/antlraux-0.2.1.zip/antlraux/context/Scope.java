/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */

package antlraux.context;

import java.util.LinkedList;
import java.util.Iterator;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Map.Entry;

/**
 * This is the class tha modelizes scopes.
 * <p>
 * Scopes admit data in the form of instances of {@link Declaration}.
 * <p>
 * Usually scopes are represented as instances of
 * {@link java.util.Hashtable} containing instances of
 * {@link Declaration}, and organized in a pile.
 * <p>
 * This implementation is slightly different.
 * <p>
 * Firstly, the scope's hashtables' elements are linked lists instead of simple
 * Declarations, so several elements with the same name are allowed on each
 * tabe's position. This is more flexible than having just one declaration
 * per position, allowing for example inserting several method declarations
 * with the same name in a class scope (thus making polymorphism easier).
 * The counterpoint is that now the search methods return a linked list 
 * instead of a single element - several helping methods ( 
 * {@link #searchFirst(String)}, {@link #searchFirstLocally(String)},
 * {@link #searchFirst(int)} and {@link #searchFirstLocally(int)}) have been
 * included to ease this issue.
 * <p>
 * Other difference between this implementation of scopes is scope organization.
 * Instead of having an explicit pile of scopes, the pile is implicit in this
 * case. This is achieved simply making every {@link Scope} know its "father scope".
 * In other words, each "method scope" will have to know the scope of the class that
 * holds the method, etc. A root ("global") scope will have <tt>null</tt> as father.
 * <p>
 * Finally, the declarations are organized in two different ways:
 * <ul>
 * <li> Declarations are sorted by name (the usual manner)</li>
 * <li> Declarations are also sorted by "tag" </li>
 * </ul>
 * A tag is an integuer which codes the "type" of a declaration. We
 * don't mean here if the declaration is "integuer" or "float"; there's
 * the {@link Declaration#type} field for that. The
 * tag says wether a declaration is a "class", a "parameter", a "method", etc.
 * <p>
 * This two types allow more powerful search techniques. For example,
 * you can ask for "all the elements named 'foo' in a class scope",
 * but you could also ask for "all the attributes of the class".
 * <p>
 * There are two ways of working with {@link Scope}. The first one is using the
 * {@link Context} class. This class has facilities for authomatically checking
 * scope closing.
 * <p>
 * The other option is not using {@link Context}, and write subclasses of
 * {@link Scope} (like <tt>GlobalScope</tt>, <tt>ClassScope</tt>,
 * <tt>MethodScope</tt>, etc). Override {@link Scope#insert(Declaration)}
 * to perform insertion checks and check the opening on every constructor
 * (see if the father scope allows "this" as a child scope)
 *
 * @see Context
 * @see Declaration
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 **/
public class Scope
{
	/** The scope's father. **/
	protected Scope father = null;
	
	/**
	 * The name of a scope is just a "caption", that will be used for most
	 * printing procedures. It is desirable guiving an appropiate name to
	 * each {@link Scope}. For example, the global scope should be called
	 * "global", or "root", while class Foo's scope name should look like 
	 * "class Foo".
	 **/
	protected String name=null;
	
	/**
	 * This integer needed on every {@link Scope} constructor represents
	 * a type of scope. This is, it codes if current scope is global scope, 
	 * class scope, method scope, etc. It is very usefull for performing
	 * scope closing checks.
	 **/
	protected int tag=-1;
	
	/** The scope's set of declarations, hashed by name. **/
	protected Hashtable namesTable=new Hashtable(); 
	
	/** The scope's set of declarations, hashed by tag. **/
	protected Hashtable tagsTable=new Hashtable(); 

	/**
	 * Constructor that sets {@link #tag} and {@link #name}
	 **/
	public Scope(int tag, String name)
	{
		this.name=name;
		this.tag=tag;
	}
	
	/**
	 * Constructor that sets {@link #tag}, {@link #name} and
	 * {@link #father}
	 **/
	public Scope(int tag, String name, Scope father)
	{
		this(tag,name);
		setFather(father);
	}
	

	/** Accessor for {@link #name} **/
	public String getName() { return name; }
	
	/** Accessor for {@link #tag}**/
	public int getTag() { return tag; }
	
	/** Accessor for {@link #father}**/
	public Scope getFather() { return father; }
	
	/** Accessor for {@link #name} **/
	public void setName(String s) { name = s; }
	
	/** Accessor for {@link #tag} **/
	public void setTag(int i) { tag = i;}
	
	/** Accessor for {@link #father} **/
	public void setFather(Scope s)
	{ father = s; }
	
	/**
	 * Inserts a new {@link Declaration}
	 * @param d the {@link Declaration} that is going to be inserted
	 *        in the scope.
	 * @throws ContextException if could not insert d. (Actually default
	 *         implementation of insert will never throw it, but subclasses
	 *         may do)
	 **/
	public void insert( Declaration d )
	throws ContextException
	{
		// Insert in the names table
		LinkedList list = this.searchAllLocally(d.getName());
		if(null==list)
		{
			list = new LinkedList();
			list.add(d);
			namesTable.put(d.getName(), list);
		}
		else
		{
			list.add(d);
		}
		
		// Insert in the tags table
		Integer theTag = new Integer(d.getTag());
		list = this.searchAllLocally(d.getTag());
		if(null==list)
		{
			list = new LinkedList();
			list.add(d);
			tagsTable.put(theTag, list);
		}
		else
		{
			list.add(d);
		}
	}

	/**
	 * Searches in current scope the first (last inserted)
	 * {@link Declaration} with a tag==tag
	 * @param tag the tag of the {@link Declaration} being searched
	 * @return declaration whose tag matches "tag"
	 * or null if none found
	 **/
	public Declaration searchFirstLocally(int tag)
	{
		LinkedList list = (LinkedList)(tagsTable.get(new Integer(tag)));
		if(null==list) return null;
		return (Declaration)(list.getFirst());
	}
	
	/**
	 * Searches in current scope the first (last inserted)
	 * {@link Declaration} named "name"
	 * @param name the name of the {@link Declaration} being searched
	 * @return a declaration whose name matches ("name")
	 * or null if none found
	 **/
	public Declaration searchFirstLocally(String name)
	{
		LinkedList list = (LinkedList)(namesTable.get(name));
		if(null==list) return null;
		return (Declaration)(list.getFirst());
	}
	
		/**
	 * Searches in current scope the first (last inserted)
	 * {@link Declaration} with a tag==tag AND name==name
	 * @param tag the tag of the {@link Declaration} being searched
	 * @param name the name of the {@link Declaration} being searched
	 * @return a declaration wose tag matches "tag" and name matches "name".
	 *         if there are several matching tags in the scope, it
	 *         is recommended to use {@link #searchAllLocally(int, String)}
	 **/
	public Declaration searchFirstLocally(int tag, String name)
	{
		LinkedList list = (LinkedList)(tagsTable.get(new Integer(tag)));
		if(null==list) return null;
		
		Declaration d = null;
		for( Iterator it = list.iterator(); it.hasNext(); )
		{
			d = (Declaration)it.next();
			if(d.getName().equals(name))
				return d;
		}
		
		return null;
	}
	
	/**
	 * It calls {@link Scope#searchFirstLocally(int)} with "tag" as param and,
	 * if nothing found, it continues with the father, the father of
	 * the father, etc.
	 * @param tag the searched {@link Declaration}'s tag
	 * @return a declaration whose tag matches "tag"
	 * or null if none found
	 **/
	public Declaration searchFirst( int tag )
	{
		Declaration result = null;
		
		for( Scope currentScope = this;
		     currentScope!=null;
		     currentScope = currentScope.getFather() )
		{
			result = currentScope.searchFirstLocally(tag);
			if(result!=null)
			{
				return result;
			}
		}
		
		return null;
	}
	
	/**
	 * It calls {@link Scope#searchFirstLocally(String)} with "name" as param and,
	 * if nothing found, it continues with the father, the father of
	 * the father, etc.
	 * @param name the searched {@link Declaration}'s name
	 * @return a declaration whose name matches "name"
	 * or null if none found
	 **/
	public Declaration searchFirst( String name )
	{
		Declaration result = null;
		
		for( Scope currentScope = this;
		     currentScope!=null;
		     currentScope = currentScope.getFather() )
		{
			result = currentScope.searchFirstLocally(name);
			if(result!=null)
			{
				return result;
			}
		}
		
		return null;
	}
	
	/**
	 * It calls {@link Scope#searchFirstLocally(int,String)} with
	 * "tag" and "name" as params and, if nothing found,
	 * it continues with the scope's father, the father of
	 * the father, etc.
	 * @param name the searched {@link Declaration}'s name
	 * @param tag the searched {@link Declaration}'s tag
	 * @return a declaration whose name matches "name", and whose
	 * tag matches "tag", or null if none found
	 **/
	public Declaration searchFirst( int tag, String name )
	{
		Declaration result = null;
		
		for( Scope currentScope = this;
		     currentScope!=null;
		     currentScope = currentScope.getFather() )
		{
			result = currentScope.searchFirstLocally(tag, name);
			if(result!=null)
			{
				return result;
			}
		}
		
		return null;
	}


	/**
	 * Searches in current scope every {@link Declaration} named "name"
	 * @param name the name of the {@link Declaration}s being searched
	 * @return a list of declarations whose name matches ("name")
	 * or null if none found
	 **/
	public LinkedList searchAllLocally(String name)
	{
		return (LinkedList)(namesTable.get(name));
	}
	
	/**
	 * Searches in current scope every {@link Declaration} tagged like "tag"
	 * @param tag the tag of the {@link Declaration}s being searched
	 * @return a list of declarations whose tag matches "tag"
	 * or null if none found
	 **/
	public LinkedList searchAllLocally(int tag)
	{
		return (LinkedList)(tagsTable.get(new Integer(tag)));
	}
	
	
	/**
	 * Searches in current scope every {@link Declaration} tagged like "tag"
	 * and named like "name"
	 * @param tag the tag of the {@link Declaration}s being searched
	 * @param name the name of the {@link Declaration}s being searched
	 * @return a list of declarations whose tag matches "tag"
	 * or null if none found
	 **/
	public LinkedList searchAllLocally(int tag, String name)
	{
		LinkedList list = (LinkedList)(tagsTable.get(new Integer(tag)));
		
		if(null==list) return null;
		
		LinkedList result = new LinkedList();
		
		Declaration d = null;
		for(Iterator it = list.iterator(); it.hasNext(); )
		{
			d = (Declaration)it.next();
			if(d.getName().equals(name))
				result.add(d);
		}
		
		if(result.isEmpty()) return null;
		
		return result;			
	}
	
	/**
	 * It calls {@link Scope#searchAllLocally(String)} with "name" as param and,
	 * if nothing found, it continues with the father, the father of
	 * the father, etc. This is the most powerfull (and slowest) search
	 * method.
	 * @param name the searched {@link Declaration}'s name
	 * @return a list of declarations whose name matches "name"
	 * or null if none found
	 **/
	public LinkedList searchAll( String name )
	{
		LinkedList result = new LinkedList();
		LinkedList aux = null;
		
		for( Scope currentScope = this;
		     currentScope!=null;
		     currentScope = currentScope.getFather() )
		{
			aux = currentScope.searchAllLocally(name);
			if(aux!=null)
			{
				result.addAll(aux);
			}
		}
		
		if(result.isEmpty()) return null;
		
		return result;
	}
	
	/**
	 * It calls {@link Scope#searchAllLocally(int)} with tag as param and,
	 * if nothing found, it continues with the father, the father of
	 * the father, etc.
	 * @param tag the searched {@link Declaration}s' tag
	 * @return a list of declarations tagged like "tag"
	 * or null if none found
	 **/
	public LinkedList searchAll( int tag )
	{
		LinkedList result = new LinkedList();
		LinkedList aux = null;
		
		for( Scope currentScope = this;
		     currentScope!=null;
		     currentScope = currentScope.getFather() )
		{
			aux = currentScope.searchAllLocally(tag);
			if(aux!=null)
			{
				result.addAll(aux);
			}
		}
		
		if(result.isEmpty()) return null;
		
		return result;
	}
	
	/**
	 * It calls {@link Scope#searchAllLocally(int, String)} with tag as param and,
	 * if nothing found, it continues with the scope's father, the father of
	 * the father, etc.
	 * @param tag the searched {@link Declaration}s' tag
	 * @param name the searched {@link Declaration}s' name
	 * @return a list of declarations tagged like "tag" and named like "name"
	 * or null if none found
	 **/
	public LinkedList searchAll( int tag, String name )
	{
		LinkedList result = new LinkedList();
		LinkedList aux = null;
		
		for( Scope currentScope = this;
		     currentScope!=null;
		     currentScope = currentScope.getFather() )
		{
			aux = currentScope.searchAllLocally(tag, name);
			if(aux!=null)
			{
				result.addAll(aux);
			}
		}
		
		if(result.isEmpty()) return null;
		
		return result;
	}
	
	public String toString()
	{
		String nl = System.getProperty("line.separator");
		
		StringBuffer sb = new StringBuffer("Scope '");
		sb.append(name);
		sb.append("' (");
		sb.append(tag);
		sb.append(") :");
		sb.append(nl);
		sb.append('{');
		sb.append(nl);
		
		LinkedList declarations = null;
		Iterator it = null;
		for( Enumeration e = namesTable.elements();
		     e.hasMoreElements(); )
		{
			declarations = (LinkedList)(e.nextElement());
			
			for( it = declarations.iterator(); it.hasNext(); )
			{
				sb.append('\t');
				sb.append(it.next());
				sb.append(nl);
			}
		}
		
		sb.append('}');
		
		return sb.toString();
	}
	
	/**
	 * It adds the declarations contained in "list" to this scope.
	 * @throws ContextException if an error ocurrs (never by default, 
	 *         but subclasses may want to)
	 **/
	public void addDeclarations(LinkedList list)
	throws ContextException
	{
		if(null==list) return;
		for( Iterator it = list.iterator(); it.hasNext(); )
		{
			this.insert((Declaration)it.next());
		}
	}
}