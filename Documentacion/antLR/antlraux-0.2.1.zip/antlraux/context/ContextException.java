
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */
 
package antlraux.context;

import antlraux.util.LexInfo;
import antlraux.util.LexInfoException;

/**
 * This is the exception launched when an error happens
 * during contextual information treatment. Since it is a subclass of
 * <tt>antlr.RecognitionException</tt>, it can be 
 * thrown by methods in a parser or treeparser
 * with little problems (they have try-catch clauses
 * for <tt>RecognitionException</tt> most of the time).
 **/
public class ContextException extends LexInfoException
implements LexInfo
{
	public ContextException() { super(); }
	
	public ContextException(String s) { super(s); }
	
	public ContextException(String s, String fileName, int line, int column)
	{
		super( s, fileName, line, column );
	}
	
	public ContextException(String s, LexInfo li)
	{
		super( s, li );
	}
}