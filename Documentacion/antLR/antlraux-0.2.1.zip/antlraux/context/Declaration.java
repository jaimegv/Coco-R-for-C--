
/*
 * Copyright (c) 2003, Enrique Jose Garcia Cota
 * All rights reserved.
 *
 * This file is part of antlraux. antlraux is distributed under 
 * the BSD license. See the license terms in file license.txt.
 *
 */
 
package antlraux.context;

import antlraux.context.types.Type;
import antlraux.util.LexInfo;
import antlr.collections.AST;
import antlr.FileLineFormatter;

/**
 * Declarations are the basic contextual information unit.
 * <p>
 * A declaration is a set of related fields, representing
 * an bit of contextual information that has to be inserted in a 
 * {@link Scope}. Some of these are mandatory and others are 
 * optional (can be null).
 * Mandatory fields are
 * <ul>
 * <li>{@link #type}</li>
 * <li>{@link #name}</li>
 * <li>{@link #tag}</li>
 * </ul>
 * Optional fields are:
 * <ul>
 * <li>{@link #ast}</li>
 * <li>{@link #initialValue}<li>
 * <li>Lexical information fields: {@link #filename}, 
 *     {@link #line}, {@link #column}</li>
 * </ul>
 * Optional fields can be null.
 * <p>
 * The aim of this class may be better understood with an example. Let's
 * imagine a language whose variables would be declared like in C:
 * <pre>
 *    int a,b,c;
 * </pre>
 * Then somewhere in the semantic analyzer some code would have to make
 * something equivalent to this:
 * <pre>
 *    Scope currentScope = getCurrentScope();
 *    currentScope.insert( new Declaration(VARIABLE, intTag, "a"));
 *    currentScope.insert( new Declaration(VARIABLE, intTag, "b"));
 *    currentScope.insert( new Declaration(VARIABLE, intTag, "c"));
 * </pre>
 * Note that in this example we are ignoring optional fields; if possible,
 * you should not!
 * <p>
 * Declarations are also valid for declaring types; this:
 * <pre>
 * class A {...}
 * struct s {...}
 * </pre>
 * Would trigger the generation of a code similar to:
 * <pre>
 *    Type AClassType = getTypeForClass("A");
 *    currentScope.insert(new Declaration(CLASS, AClassType, "A"));
 *    Type sStructType = getTypeForStruct("s");
 *    currentScope.insert(new Declaration(STRUCT, sStructType, "s"));
 * </pre>
 * Depending on how you implement the scoping system (with or without 
 * {@link Context}- see the comments on {@link Scope} for further information )
 * this codes will be on a subclass of {@link Scope} or {@link Context}.
 * @see Context
 * @see Scope
 * @see antlraux.context.types.Type
 * @author Enrique Jos&eacute; Garc&iacute;a Cota
 **/
public class Declaration implements LexInfo
{
	/**  The declaration {@link antlraux.context.types.Type}. **/
	protected Type type   = null;
	
	/** The declaration name **/
	protected String name = null;
	
	/**
	 * An integer used to store different "declaration types",
	 * such as PARAMETER, ATTRIBUTE or CLASS.
	 **/
	protected int tag = -1;
	
	/** The AST that originated the declaration. Can be <tt>null</tt> **/
	protected AST ast     = null;
	
	/**
	 * An initial value for the declaration. Use it when modelling
	 * declarations that involve a certain initialization value
	 * (like variables initialized with an expression ):
	 * <pre>
	 *       Declaration
	 *      ______/\______
	 *     /              \    
	 *     int a  = 2 + 2 ;
	 *             \__  __/
	 *                \/
	 *          Initial value
	 * </pre>
	 * In declarations with no initializations, null or a type-
	 * dependent default value could be used.
	 * <p>
	 * I've left this member's type as an AST, so you can use
	 * your own; however, I strongly recomment using an instance of
	 * {@link antlraux.context.asts.ExpressionAST} for it.
	 **/
	protected AST initialValue = null;
	
	/** Lexical information. Can be <tt>null</tt> **/
	protected String filename = LexInfo.DEFAULT_FILENAME;
	
	/** Lexical information. Can be <tt>null</tt> **/
	protected int line        = LexInfo.DEFAULT_LINE;
	
	/** Lexical information. Can be <tt>null</tt> **/
	protected int column      = LexInfo.DEFAULT_COLUMN;
	
	public Declaration( int tag, Type t, String name )
	{
		setTag(tag);
		setType(t);
		setName(name);	
	}
	
	public Declaration( int tag,
	                    Type t,
	                    String name,
	                    AST ast,
	                    AST initialValue,
	                    LexInfo lexInfo)
	{
		this(tag, t, name);
		setAST(ast);
		setInitialValue(initialValue);
		copyLexInfo(lexInfo);
	}
	
	public Declaration( int tag,
	                    Type t,
	                    String name,
	                    AST ast,
	                    AST initialValue,
	                    String fileName,
	                    int line,
	                    int column )
	{
		this(tag, t, name);
		setAST(ast);
		setInitialValue(initialValue);
		setFilename(fileName);
		setLine(line);
		setColumn(column);
	}
	
		
	/**
	 * Accessor for {@link #name}
	 * @throws IllegalArgumentException if name==null
	 **/
	public void setName(String name)
	{
		if(null==name)
			throw new IllegalArgumentException(
				"A name for the Declaration is needed, found null");
		this.name = name;
	}
	
	public String getName()
	{ return name; }
	
	
	/**
	 * Accessor for {@link #type}
	 * @throws IllegalArgumentException if null==t
	 **/
	public void setType(Type t)
	{
		if(null==t)
			throw new IllegalArgumentException(
				"A Type for the Declaration is needed, found null");
		this.type = t;
	}
	
	public void setTag(int tag)
	{ this.tag = tag; }
	
	public void setAST(AST ast)
	{ this.ast = ast; }
	
	public void setInitialValue(AST initialValue)
	{ this.initialValue = initialValue; }
	
	public AST getAST()
	{ return this.ast; }
	
	public Type getType()
	{ return type; }
	
	public int getTag()
	{ return tag; }
	
	public AST getInitialValue()
	{ return initialValue; }
	
    public String getFilename()
    { return filename; }
    
    public int getColumn()
    { return column; }
    
    public int getLine()
    { return line; }
    
    public void setFilename(String fn)
    { filename = fn; }
    
    public void setColumn(int column)
    { this.column = column; }
    
    public void setLine(int line)
    { this.line = line; }
    
    public void copyLexInfo(LexInfo from)
    {
     	if(from!=null)
     	{
     		this.filename = from.getFilename();
    		this.line = from.getLine();
    		this.column = from.getColumn();
    	}
    }

    public String getLexInfoString()
	{
		FileLineFormatter f = FileLineFormatter.getFormatter();
		return f.getFormatString(filename, getLine(), getColumn());
	}
	
	public void initialize(Declaration other)
	{
		this.ast=other.ast;
		this.name=other.name;
		this.type=other.type;
		this.initialValue=other.initialValue;
		copyLexInfo(other);
	}
	
	public String toString()
	{
		StringBuffer sb = new StringBuffer("Declaration ( name='");
		sb.append(name);
		sb.append("', tag="); sb.append(tag);
		sb.append(", type="); sb.append(type);
		sb.append(", ast="); sb.append(ast);
		sb.append(", iv="); sb.append(initialValue);
		sb.append(", lex="); sb.append(getLexInfoString());
		sb.append(" )");
		return sb.toString();
	}
}