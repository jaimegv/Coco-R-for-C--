package analizador;
import java.io.*;
//import org.antlr.runtime.CommonTokenStream;
import antlr.collections.AST;
import antlr.ANTLRException;
import antlr.Token;
import antlr.TokenStreamException;

	public class borrame {
		
		public static String leer_linea (String [] args) {
			File archivo = null;
		    FileReader fr = null;
		    BufferedReader br = null;
	        // Lectura del fichero, recuerda que esta linea
		    // se devuelve siempre, con fallo o aciertos
		    // podemos poner linea como variable
	        String fichero = "";

	        try {
				 // Apertura del fichero y creacion de BufferedReader para poder
				 // hacer una lectura comoda (disponer del metodo readLine()).
				 archivo = new File (args[0]);
				 fr = new FileReader (archivo);
				 br = new BufferedReader(fr);
				 String linea = null;
				 // System.out.println("Estas empezando a leer");

				 // No modificar! lee el fichero entero linea por linea
				 if ((fichero.equals("")) & ((linea=br.readLine())!=null)) {
					 	System.out.println("Leyendo linea:"+linea);
				 		fichero=linea;
				 }

				 while((linea=br.readLine())!=null) {
						System.out.println("Leyendo linea:"+linea);
						//System.out.println(fichero);
						fichero+="\n"+linea;	// lo separo con \n = saltos de linea
				 }
		      }
		      catch(Exception e){
		         e.printStackTrace();
		      }finally{
		         // En el finally cerramos el fichero, para asegurarnos
		         // que se cierra tanto si todo va bien como si salta 
		         // una excepcion.
		         try{                    
		            if( null != fr ){   
		               fr.close();     
		            }                  
		         }catch (Exception e2){ 
		            e2.printStackTrace();
		         }
		      }
	          System.out.println("Esto es lo que he leido del fichero:"+fichero);
		      return fichero;	
		}
		
		
		public static void main(String args[]) throws TokenStreamException {
			try {
			   	//String linea = leer_linea(args);	// recibimos una linea
		        System.out.println("Empieza a dar tokens:");
				FileInputStream fis = new FileInputStream("/home/pirois/workspace/borrame/src/analizador/cod_fuente1");
				analizador Analizador = new analizador(fis);
				System.out.println("Hola caracola");
				Token token = Analizador.nextToken();
				while(token.getType() != Token.EOF_TYPE) {
					System.out.println(token);
					token = Analizador.nextToken();
				}


			}catch(FileNotFoundException fnfe) {
				System.err.println("No se encontró el fichero");
			}
		}
}