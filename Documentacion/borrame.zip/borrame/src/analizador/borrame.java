package analizador;
import java.io.*;
import antlr.collections.AST;
//import antlr.ANTLRException;

	public class borrame {
		public static void main(String args[]) {
			try {
				FileInputStream fis = new FileInputStream("/home/pirois/workspace/borrame/src/analizador/cod_fuente1");
				analizador Analizador = new analizador(fis);
				System.out.println("Hola caracola");

			}catch(FileNotFoundException fnfe) {
				System.err.println("No se encontró el fichero");
			}
		}
}