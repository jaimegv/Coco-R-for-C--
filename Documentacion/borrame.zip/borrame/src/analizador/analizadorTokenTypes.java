package analizador;

// $ANTLR : "analizador.g" -> "analizador.java"$

public interface analizadorTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int BLANCO = 4;
	int OP_MAS = 5;
	int OP_MENOS = 6;
	int OP_PRODUCTO = 7;
	int OP_COCIENTE = 8;
	int PARENT_AB = 9;
	int PARENT_CE = 10;
	int NUMERO = 11;
}
