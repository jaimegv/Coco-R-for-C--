// $ANTLR : "CompParser.g" -> "CompParser.java"$

	package analizador;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import java.util.Hashtable;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

public class CompParser extends antlr.LLkParser       implements CompParserVocabTokenTypes
 {

protected CompParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public CompParser(TokenBuffer tokenBuf) {
  this(tokenBuf,3);
}

protected CompParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public CompParser(TokenStream lexer) {
  this(lexer,3);
}

public CompParser(ParserSharedInputState state) {
  super(state,3);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

	public final void programa() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST programa_AST = null;
		
		try {      // for error handling
			{
			_loop10321:
			do {
				boolean synPredMatched10320 = false;
				if (((_tokenSet_0.member(LA(1))) && (LA(2)==IDENT||LA(2)==OP_PRODUCTO) && (_tokenSet_1.member(LA(3))))) {
					int _m10320 = mark();
					synPredMatched10320 = true;
					inputState.guessing++;
					try {
						{
						ttipo(false);
						match(IDENT);
						{
						switch ( LA(1)) {
						case COMA:
						{
							match(COMA);
							break;
						}
						case OP_ASIG:
						{
							match(OP_ASIG);
							break;
						}
						case PUNTO_COMA:
						{
							match(PUNTO_COMA);
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						}
					}
					catch (RecognitionException pe) {
						synPredMatched10320 = false;
					}
					rewind(_m10320);
inputState.guessing--;
				}
				if ( synPredMatched10320 ) {
					instDecVar();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop10321;
				}
				
			} while (true);
			}
			{
			_loop10323:
			do {
				if ((_tokenSet_0.member(LA(1))) && (LA(2)==IDENT||LA(2)==OP_PRODUCTO) && (LA(3)==IDENT||LA(3)==DOSPUNTOS_DOS)) {
					decMetodo();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else if ((_tokenSet_0.member(LA(1))) && (LA(2)==IDENT||LA(2)==OP_PRODUCTO) && (LA(3)==IDENT||LA(3)==PARENT_AB)) {
					subprograma();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else if ((LA(1)==CLASS)) {
					decClase();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop10323;
				}
				
			} while (true);
			}
			main();
			astFactory.addASTChild(currentAST, returnAST);
			if ( inputState.guessing==0 ) {
				programa_AST = (AST)currentAST.root;
				programa_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(PROGRAMA,"PROGRAMA")).add(programa_AST));
				currentAST.root = programa_AST;
				currentAST.child = programa_AST!=null &&programa_AST.getFirstChild()!=null ?
					programa_AST.getFirstChild() : programa_AST;
				currentAST.advanceChildToEnd();
			}
			programa_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = programa_AST;
	}
	
	public final void ttipo(
		boolean variable
	) throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST ttipo_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case INT:
			{
				AST tmp1_AST = null;
				tmp1_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp1_AST);
				match(INT);
				ttipo_AST = (AST)currentAST.root;
				break;
			}
			case BOOL:
			{
				AST tmp2_AST = null;
				tmp2_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp2_AST);
				match(BOOL);
				ttipo_AST = (AST)currentAST.root;
				break;
			}
			case VOID:
			{
				AST tmp3_AST = null;
				tmp3_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp3_AST);
				match(VOID);
				ttipo_AST = (AST)currentAST.root;
				break;
			}
			case CHAR:
			{
				AST tmp4_AST = null;
				tmp4_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp4_AST);
				match(CHAR);
				AST tmp5_AST = null;
				tmp5_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp5_AST);
				match(OP_PRODUCTO);
				ttipo_AST = (AST)currentAST.root;
				break;
			}
			default:
				if (((LA(1)==IDENT))&&( variable )) {
					AST tmp6_AST = null;
					tmp6_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp6_AST);
					match(IDENT);
					ttipo_AST = (AST)currentAST.root;
				}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = ttipo_AST;
	}
	
	public final void instDecVar() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST instDecVar_AST = null;
		final AST raiz = astFactory.create(INTS_DEC_VAR,"INTS_DEC_VAR");
		
		try {      // for error handling
			listaDeclaraciones(raiz, true);
			astFactory.addASTChild(currentAST, returnAST);
			match(PUNTO_COMA);
			instDecVar_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_4);
			} else {
			  throw ex;
			}
		}
		returnAST = instDecVar_AST;
	}
	
	public final void decMetodo() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST decMetodo_AST = null;
		
		try {      // for error handling
			ttipo(true);
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp8_AST = null;
			tmp8_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp8_AST);
			match(IDENT);
			match(DOSPUNTOS_DOS);
			AST tmp10_AST = null;
			tmp10_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp10_AST);
			match(IDENT);
			match(PARENT_AB);
			listaDecParams();
			astFactory.addASTChild(currentAST, returnAST);
			match(PARENT_CE);
			match(LLAVE_AB);
			cuerpo_sp();
			astFactory.addASTChild(currentAST, returnAST);
			match(LLAVE_CE);
			if ( inputState.guessing==0 ) {
				decMetodo_AST = (AST)currentAST.root;
				decMetodo_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(DEC_METODO,"DEC_METODO")).add(decMetodo_AST));
				currentAST.root = decMetodo_AST;
				currentAST.child = decMetodo_AST!=null &&decMetodo_AST.getFirstChild()!=null ?
					decMetodo_AST.getFirstChild() : decMetodo_AST;
				currentAST.advanceChildToEnd();
			}
			decMetodo_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = decMetodo_AST;
	}
	
	public final void subprograma() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST subprograma_AST = null;
		
		try {      // for error handling
			ttipo(true);
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp15_AST = null;
			tmp15_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp15_AST);
			match(IDENT);
			match(PARENT_AB);
			listaDecParams();
			astFactory.addASTChild(currentAST, returnAST);
			match(PARENT_CE);
			match(LLAVE_AB);
			cuerpo_sp();
			astFactory.addASTChild(currentAST, returnAST);
			match(LLAVE_CE);
			if ( inputState.guessing==0 ) {
				subprograma_AST = (AST)currentAST.root;
				subprograma_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(SUBPROGRAMA,"SUBPROGRAMA")).add(subprograma_AST));
				currentAST.root = subprograma_AST;
				currentAST.child = subprograma_AST!=null &&subprograma_AST.getFirstChild()!=null ?
					subprograma_AST.getFirstChild() : subprograma_AST;
				currentAST.advanceChildToEnd();
			}
			subprograma_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = subprograma_AST;
	}
	
	public final void decClase() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST decClase_AST = null;
		
		try {      // for error handling
			match(CLASS);
			AST tmp21_AST = null;
			tmp21_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp21_AST);
			match(IDENT);
			match(LLAVE_AB);
			{
			switch ( LA(1)) {
			case CHAR:
			case INT:
			case BOOL:
			case VOID:
			case IDENT:
			{
				decCabMet();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case PUBLIC:
			case PRIVATE:
			case LLAVE_CE:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case PUBLIC:
			{
				AST tmp23_AST = null;
				tmp23_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp23_AST);
				match(PUBLIC);
				match(DOSPUNTOS);
				decCabMet();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case PRIVATE:
			case LLAVE_CE:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case PRIVATE:
			{
				AST tmp25_AST = null;
				tmp25_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp25_AST);
				match(PRIVATE);
				match(DOSPUNTOS);
				decCabMet();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case LLAVE_CE:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(LLAVE_CE);
			match(PUNTO_COMA);
			if ( inputState.guessing==0 ) {
				decClase_AST = (AST)currentAST.root;
				decClase_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(CLASE,"CLASE")).add(decClase_AST));
				currentAST.root = decClase_AST;
				currentAST.child = decClase_AST!=null &&decClase_AST.getFirstChild()!=null ?
					decClase_AST.getFirstChild() : decClase_AST;
				currentAST.advanceChildToEnd();
			}
			decClase_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_5);
			} else {
			  throw ex;
			}
		}
		returnAST = decClase_AST;
	}
	
	public final void main() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST main_AST = null;
		
		try {      // for error handling
			ttipo(true);
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp29_AST = null;
			tmp29_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp29_AST);
			match(MAIN);
			match(PARENT_AB);
			listaDecParams();
			astFactory.addASTChild(currentAST, returnAST);
			match(PARENT_CE);
			match(LLAVE_AB);
			cuerpo_sp();
			astFactory.addASTChild(currentAST, returnAST);
			match(LLAVE_CE);
			if ( inputState.guessing==0 ) {
				main_AST = (AST)currentAST.root;
				main_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(DEC_MAIN,"DEC_MAIN")).add(main_AST));
				currentAST.root = main_AST;
				currentAST.child = main_AST!=null &&main_AST.getFirstChild()!=null ?
					main_AST.getFirstChild() : main_AST;
				currentAST.advanceChildToEnd();
			}
			main_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = main_AST;
	}
	
	public final void listaDecParams() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST listaDecParams_AST = null;
		final AST raiz = astFactory.create(RES_PARAMETRO,"PARAMETRO");
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case CHAR:
			case INT:
			case BOOL:
			case VOID:
			case IDENT:
			{
				ttipo(true);
				astFactory.addASTChild(currentAST, returnAST);
				{
				switch ( LA(1)) {
				case IDENT:
				{
					AST tmp34_AST = null;
					tmp34_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp34_AST);
					match(IDENT);
					{
					_loop10344:
					do {
						if ((LA(1)==COMA)) {
							match(COMA);
							ttipo(true);
							astFactory.addASTChild(currentAST, returnAST);
							AST tmp36_AST = null;
							tmp36_AST = astFactory.create(LT(1));
							astFactory.addASTChild(currentAST, tmp36_AST);
							match(IDENT);
						}
						else {
							break _loop10344;
						}
						
					} while (true);
					}
					break;
				}
				case PARENT_CE:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				break;
			}
			case PARENT_CE:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			listaDecParams_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_6);
			} else {
			  throw ex;
			}
		}
		returnAST = listaDecParams_AST;
	}
	
	public final void cuerpo_sp() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cuerpo_sp_AST = null;
		
		try {      // for error handling
			{
			_loop10347:
			do {
				if ((_tokenSet_7.member(LA(1)))) {
					instruccion();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop10347;
				}
				
			} while (true);
			}
			if ( inputState.guessing==0 ) {
				cuerpo_sp_AST = (AST)currentAST.root;
				cuerpo_sp_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(LISTA_INSTRUCCIONES,"LISTA_INSTRUCCIONES")).add(cuerpo_sp_AST));
				currentAST.root = cuerpo_sp_AST;
				currentAST.child = cuerpo_sp_AST!=null &&cuerpo_sp_AST.getFirstChild()!=null ?
					cuerpo_sp_AST.getFirstChild() : cuerpo_sp_AST;
				currentAST.advanceChildToEnd();
			}
			cuerpo_sp_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_8);
			} else {
			  throw ex;
			}
		}
		returnAST = cuerpo_sp_AST;
	}
	
	public final void decCabMet() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST decCabMet_AST = null;
		
		try {      // for error handling
			{
			int _cnt10338=0;
			_loop10338:
			do {
				if ((_tokenSet_0.member(LA(1)))) {
					ttipo(false);
					astFactory.addASTChild(currentAST, returnAST);
					AST tmp37_AST = null;
					tmp37_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp37_AST);
					match(IDENT);
					{
					switch ( LA(1)) {
					case COMA:
					{
						{
						int _cnt10334=0;
						_loop10334:
						do {
							if ((LA(1)==COMA)) {
								match(COMA);
								AST tmp39_AST = null;
								tmp39_AST = astFactory.create(LT(1));
								astFactory.addASTChild(currentAST, tmp39_AST);
								match(IDENT);
							}
							else {
								if ( _cnt10334>=1 ) { break _loop10334; } else {throw new NoViableAltException(LT(1), getFilename());}
							}
							
							_cnt10334++;
						} while (true);
						}
						break;
					}
					case PARENT_AB:
					{
						{
						match(PARENT_AB);
						ttipo(false);
						astFactory.addASTChild(currentAST, returnAST);
						{
						_loop10337:
						do {
							if ((LA(1)==COMA)) {
								match(COMA);
								ttipo(false);
								astFactory.addASTChild(currentAST, returnAST);
							}
							else {
								break _loop10337;
							}
							
						} while (true);
						}
						match(PARENT_CE);
						}
						break;
					}
					case PUNTO_COMA:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					match(PUNTO_COMA);
				}
				else {
					if ( _cnt10338>=1 ) { break _loop10338; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt10338++;
			} while (true);
			}
			decCabMet_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_9);
			} else {
			  throw ex;
			}
		}
		returnAST = decCabMet_AST;
	}
	
	public final void instruccion() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST instruccion_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case IF:
			{
				instCond();
				astFactory.addASTChild(currentAST, returnAST);
				instruccion_AST = (AST)currentAST.root;
				break;
			}
			case PARENT_AB:
			{
				instCondSimple();
				astFactory.addASTChild(currentAST, returnAST);
				instruccion_AST = (AST)currentAST.root;
				break;
			}
			case COUT:
			{
				instCout();
				astFactory.addASTChild(currentAST, returnAST);
				instruccion_AST = (AST)currentAST.root;
				break;
			}
			case CIN:
			{
				instCin();
				astFactory.addASTChild(currentAST, returnAST);
				instruccion_AST = (AST)currentAST.root;
				break;
			}
			case PUNTO_COMA:
			{
				instNula();
				astFactory.addASTChild(currentAST, returnAST);
				instruccion_AST = (AST)currentAST.root;
				break;
			}
			case RETURN:
			{
				instReturn();
				astFactory.addASTChild(currentAST, returnAST);
				instruccion_AST = (AST)currentAST.root;
				break;
			}
			default:
				boolean synPredMatched10358 = false;
				if (((_tokenSet_0.member(LA(1))) && (LA(2)==IDENT||LA(2)==OP_PRODUCTO) && (_tokenSet_1.member(LA(3))))) {
					int _m10358 = mark();
					synPredMatched10358 = true;
					inputState.guessing++;
					try {
						{
						ttipo(true);
						match(IDENT);
						}
					}
					catch (RecognitionException pe) {
						synPredMatched10358 = false;
					}
					rewind(_m10358);
inputState.guessing--;
				}
				if ( synPredMatched10358 ) {
					instDecVar();
					astFactory.addASTChild(currentAST, returnAST);
					instruccion_AST = (AST)currentAST.root;
				}
				else if ((_tokenSet_10.member(LA(1))) && (_tokenSet_11.member(LA(2))) && (_tokenSet_12.member(LA(3)))) {
					instExpresion();
					astFactory.addASTChild(currentAST, returnAST);
					instruccion_AST = (AST)currentAST.root;
				}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = instruccion_AST;
	}
	
	public final void instReturn() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST instReturn_AST = null;
		
		try {      // for error handling
			match(RETURN);
			{
			switch ( LA(1)) {
			case CTE_LOGTRUE:
			case CTE_LOGFALSE:
			case LIT_ENTERO_OCTAL:
			case LIT_ENTERO_DECIMAL:
			case IDENT:
			case LIT_CADENA:
			case OP_MAS:
			case OP_MENOS:
			case OP_NOT:
			{
				instExpresion();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case PUNTO_COMA:
			{
				match(PUNTO_COMA);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			if ( inputState.guessing==0 ) {
				instReturn_AST = (AST)currentAST.root;
				instReturn_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(INST_RETURN,"INST_RETURN")).add(instReturn_AST));
				currentAST.root = instReturn_AST;
				currentAST.child = instReturn_AST!=null &&instReturn_AST.getFirstChild()!=null ?
					instReturn_AST.getFirstChild() : instReturn_AST;
				currentAST.advanceChildToEnd();
			}
			instReturn_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = instReturn_AST;
	}
	
	public final void instExpresion() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST instExpresion_AST = null;
		
		try {      // for error handling
			expresion();
			astFactory.addASTChild(currentAST, returnAST);
			match(PUNTO_COMA);
			if ( inputState.guessing==0 ) {
				instExpresion_AST = (AST)currentAST.root;
				instExpresion_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(INST_EXPRESION,"INST_EXPRESION")).add(instExpresion_AST));
				currentAST.root = instExpresion_AST;
				currentAST.child = instExpresion_AST!=null &&instExpresion_AST.getFirstChild()!=null ?
					instExpresion_AST.getFirstChild() : instExpresion_AST;
				currentAST.advanceChildToEnd();
			}
			instExpresion_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = instExpresion_AST;
	}
	
	public final void listaDeclaraciones(
		AST raiz, boolean inicializacion
	) throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST listaDeclaraciones_AST = null;
		AST t_AST = null;
		
		try {      // for error handling
			ttipo(true);
			t_AST = (AST)returnAST;
			declaracion(raiz, t_AST, inicializacion);
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop10353:
			do {
				if ((LA(1)==COMA)) {
					match(COMA);
					declaracion(raiz, t_AST, inicializacion);
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop10353;
				}
				
			} while (true);
			}
			listaDeclaraciones_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_14);
			} else {
			  throw ex;
			}
		}
		returnAST = listaDeclaraciones_AST;
	}
	
	public final void declaracion(
		AST r, AST t, boolean inicializacion
	) throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST declaracion_AST = null;
		Token  i1 = null;
		AST i1_AST = null;
		Token  i2 = null;
		AST i2_AST = null;
		AST arg_AST = null;
		Token  i6 = null;
		AST i6_AST = null;
		AST valor_AST = null;
		Token  i4 = null;
		AST i4_AST = null;
			
					AST raiz = astFactory.dupTree(r);	// copiamos el arbol
					raiz.addChild(astFactory.dupTree(t));	// copia del arbol
				
		
		try {      // for error handling
			if ((LA(1)==IDENT) && (LA(2)==PUNTO_COMA||LA(2)==COMA)) {
				i1 = LT(1);
				i1_AST = astFactory.create(i1);
				match(IDENT);
				if ( inputState.guessing==0 ) {
					declaracion_AST = (AST)currentAST.root;
					
									raiz.addChild(i1_AST);
									declaracion_AST = raiz;
								
					currentAST.root = declaracion_AST;
					currentAST.child = declaracion_AST!=null &&declaracion_AST.getFirstChild()!=null ?
						declaracion_AST.getFirstChild() : declaracion_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else if (((LA(1)==IDENT) && (LA(2)==OP_ASIG))&&( inicializacion )) {
				i2 = LT(1);
				i2_AST = astFactory.create(i2);
				match(IDENT);
				AST tmp48_AST = null;
				tmp48_AST = astFactory.create(LT(1));
				match(OP_ASIG);
				q_argumento();
				arg_AST = (AST)returnAST;
				if ( inputState.guessing==0 ) {
					declaracion_AST = (AST)currentAST.root;
					
									raiz.addChild(i2_AST);
									raiz.addChild(arg_AST);
									declaracion_AST = raiz;
							
					currentAST.root = declaracion_AST;
					currentAST.child = declaracion_AST!=null &&declaracion_AST.getFirstChild()!=null ?
						declaracion_AST.getFirstChild() : declaracion_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else if (((LA(1)==IDENT) && (LA(2)==PARENT_AB))&&( inicializacion )) {
				i6 = LT(1);
				i6_AST = astFactory.create(i6);
				match(IDENT);
				match(PARENT_AB);
				q_argumento();
				valor_AST = (AST)returnAST;
				match(PARENT_CE);
				if ( inputState.guessing==0 ) {
					declaracion_AST = (AST)currentAST.root;
					raiz.addChild(i6_AST);
							  	raiz.addChild(valor_AST);
							  	declaracion_AST = raiz;
							
					currentAST.root = declaracion_AST;
					currentAST.child = declaracion_AST!=null &&declaracion_AST.getFirstChild()!=null ?
						declaracion_AST.getFirstChild() : declaracion_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else if ((LA(1)==IDENT) && (LA(2)==CORCHETE_AB)) {
				i4 = LT(1);
				i4_AST = astFactory.create(i4);
				match(IDENT);
				AST tmp51_AST = null;
				tmp51_AST = astFactory.create(LT(1));
				match(CORCHETE_AB);
				{
				switch ( LA(1)) {
				case LIT_ENTERO_OCTAL:
				{
					AST tmp52_AST = null;
					tmp52_AST = astFactory.create(LT(1));
					match(LIT_ENTERO_OCTAL);
					break;
				}
				case LIT_ENTERO_DECIMAL:
				{
					AST tmp53_AST = null;
					tmp53_AST = astFactory.create(LT(1));
					match(LIT_ENTERO_DECIMAL);
					break;
				}
				case CORCHETE_CE:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				AST tmp54_AST = null;
				tmp54_AST = astFactory.create(LT(1));
				match(CORCHETE_CE);
				if ( inputState.guessing==0 ) {
					declaracion_AST = (AST)currentAST.root;
					raiz.addChild(i4_AST);
							  	//raiz.addChild(#li);
							  	declaracion_AST = raiz;
							
					currentAST.root = declaracion_AST;
					currentAST.child = declaracion_AST!=null &&declaracion_AST.getFirstChild()!=null ?
						declaracion_AST.getFirstChild() : declaracion_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_15);
			} else {
			  throw ex;
			}
		}
		returnAST = declaracion_AST;
	}
	
	public final void q_argumento() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST q_argumento_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case LIT_CADENA:
			{
				AST tmp55_AST = null;
				tmp55_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp55_AST);
				match(LIT_CADENA);
				q_argumento_AST = (AST)currentAST.root;
				break;
			}
			case LIT_ENTERO_OCTAL:
			{
				AST tmp56_AST = null;
				tmp56_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp56_AST);
				match(LIT_ENTERO_OCTAL);
				q_argumento_AST = (AST)currentAST.root;
				break;
			}
			case LIT_ENTERO_DECIMAL:
			{
				AST tmp57_AST = null;
				tmp57_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp57_AST);
				match(LIT_ENTERO_DECIMAL);
				q_argumento_AST = (AST)currentAST.root;
				break;
			}
			case CTE_LOGTRUE:
			{
				AST tmp58_AST = null;
				tmp58_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp58_AST);
				match(CTE_LOGTRUE);
				q_argumento_AST = (AST)currentAST.root;
				break;
			}
			case CTE_LOGFALSE:
			{
				AST tmp59_AST = null;
				tmp59_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp59_AST);
				match(CTE_LOGFALSE);
				q_argumento_AST = (AST)currentAST.root;
				break;
			}
			case PUNTO_COMA:
			case COMA:
			case PARENT_CE:
			{
				q_argumento_AST = (AST)currentAST.root;
				break;
			}
			default:
				if ((LA(1)==IDENT) && (LA(2)==PARENT_AB)) {
					AST tmp60_AST = null;
					tmp60_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp60_AST);
					match(IDENT);
					match(PARENT_AB);
					q_argumento();
					astFactory.addASTChild(currentAST, returnAST);
					match(PARENT_CE);
					q_argumento_AST = (AST)currentAST.root;
				}
				else if ((LA(1)==IDENT) && (LA(2)==PUNTO_COMA||LA(2)==COMA||LA(2)==PARENT_CE)) {
					AST tmp63_AST = null;
					tmp63_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp63_AST);
					match(IDENT);
					q_argumento_AST = (AST)currentAST.root;
				}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_16);
			} else {
			  throw ex;
			}
		}
		returnAST = q_argumento_AST;
	}
	
	public final void instCond() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST instCond_AST = null;
		
		try {      // for error handling
			AST tmp64_AST = null;
			tmp64_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp64_AST);
			match(IF);
			match(PARENT_AB);
			expresion();
			astFactory.addASTChild(currentAST, returnAST);
			match(PARENT_CE);
			{
			switch ( LA(1)) {
			case LLAVE_AB:
			{
				match(LLAVE_AB);
				cuerpo_sp();
				astFactory.addASTChild(currentAST, returnAST);
				match(LLAVE_CE);
				break;
			}
			case CTE_LOGTRUE:
			case CTE_LOGFALSE:
			case CHAR:
			case INT:
			case BOOL:
			case IF:
			case RETURN:
			case VOID:
			case CIN:
			case COUT:
			case LIT_ENTERO_OCTAL:
			case LIT_ENTERO_DECIMAL:
			case IDENT:
			case LIT_CADENA:
			case OP_MAS:
			case OP_MENOS:
			case OP_NOT:
			case PUNTO_COMA:
			case PARENT_AB:
			{
				instruccion();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			sino();
			astFactory.addASTChild(currentAST, returnAST);
			instCond_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = instCond_AST;
	}
	
	public final void instCondSimple() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST instCondSimple_AST = null;
		
		try {      // for error handling
			match(PARENT_AB);
			acceso();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case OP_IGUAL:
			{
				AST tmp70_AST = null;
				tmp70_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp70_AST);
				match(OP_IGUAL);
				break;
			}
			case OP_DISTINTO:
			{
				AST tmp71_AST = null;
				tmp71_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp71_AST);
				match(OP_DISTINTO);
				break;
			}
			case OP_MAYOR:
			{
				AST tmp72_AST = null;
				tmp72_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp72_AST);
				match(OP_MAYOR);
				AST tmp73_AST = null;
				tmp73_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp73_AST);
				match(OP_MENOR);
				break;
			}
			case OP_MENOR_IGUAL:
			{
				AST tmp74_AST = null;
				tmp74_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp74_AST);
				match(OP_MENOR_IGUAL);
				break;
			}
			case OP_MAYOR_IGUAL:
			{
				AST tmp75_AST = null;
				tmp75_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp75_AST);
				match(OP_MAYOR_IGUAL);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			acceso();
			astFactory.addASTChild(currentAST, returnAST);
			match(PARENT_CE);
			AST tmp77_AST = null;
			tmp77_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp77_AST);
			match(INTER);
			acceso();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp78_AST = null;
			tmp78_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp78_AST);
			match(DOSPUNTOS);
			acceso();
			astFactory.addASTChild(currentAST, returnAST);
			if ( inputState.guessing==0 ) {
				instCondSimple_AST = (AST)currentAST.root;
				instCondSimple_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(CONDSIMPLE,"CONDSIMPLE")).add(instCondSimple_AST));
				currentAST.root = instCondSimple_AST;
				currentAST.child = instCondSimple_AST!=null &&instCondSimple_AST.getFirstChild()!=null ?
					instCondSimple_AST.getFirstChild() : instCondSimple_AST;
				currentAST.advanceChildToEnd();
			}
			instCondSimple_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_17);
			} else {
			  throw ex;
			}
		}
		returnAST = instCondSimple_AST;
	}
	
	public final void instCout() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST instCout_AST = null;
		
		try {      // for error handling
			AST tmp79_AST = null;
			tmp79_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp79_AST);
			match(COUT);
			{
			int _cnt10361=0;
			_loop10361:
			do {
				if ((LA(1)==MENOR_MENOR)) {
					AST tmp80_AST = null;
					tmp80_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp80_AST);
					match(MENOR_MENOR);
					arg_io();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt10361>=1 ) { break _loop10361; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt10361++;
			} while (true);
			}
			match(PUNTO_COMA);
			instCout_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = instCout_AST;
	}
	
	public final void instCin() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST instCin_AST = null;
		
		try {      // for error handling
			AST tmp82_AST = null;
			tmp82_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp82_AST);
			match(CIN);
			AST tmp83_AST = null;
			tmp83_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp83_AST);
			match(MAYOR_MAYOR);
			arg_io();
			astFactory.addASTChild(currentAST, returnAST);
			match(PUNTO_COMA);
			instCin_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = instCin_AST;
	}
	
	public final void instNula() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST instNula_AST = null;
		
		try {      // for error handling
			match(PUNTO_COMA);
			instNula_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = instNula_AST;
	}
	
	public final void arg_io() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST arg_io_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case IDENT:
			{
				AST tmp86_AST = null;
				tmp86_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp86_AST);
				match(IDENT);
				arg_io_AST = (AST)currentAST.root;
				break;
			}
			case LIT_CADENA:
			{
				AST tmp87_AST = null;
				tmp87_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp87_AST);
				match(LIT_CADENA);
				arg_io_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_18);
			} else {
			  throw ex;
			}
		}
		returnAST = arg_io_AST;
	}
	
	public final void expresion() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expresion_AST = null;
		
		try {      // for error handling
			expAsignacion();
			astFactory.addASTChild(currentAST, returnAST);
			expresion_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_19);
			} else {
			  throw ex;
			}
		}
		returnAST = expresion_AST;
	}
	
	public final void expAsignacion() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expAsignacion_AST = null;
		
		try {      // for error handling
			expOLogico();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case OP_ASIG:
			{
				{
				AST tmp88_AST = null;
				tmp88_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp88_AST);
				match(OP_ASIG);
				{
				switch ( LA(1)) {
				case PARENT_AB:
				{
					instCondSimple();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				case CTE_LOGTRUE:
				case CTE_LOGFALSE:
				case LIT_ENTERO_OCTAL:
				case LIT_ENTERO_DECIMAL:
				case IDENT:
				case LIT_CADENA:
				case OP_MAS:
				case OP_MENOS:
				case OP_NOT:
				{
					expOLogico();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				}
				break;
			}
			case OP_ASIG_MAS:
			{
				{
				AST tmp89_AST = null;
				tmp89_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp89_AST);
				match(OP_ASIG_MAS);
				{
				switch ( LA(1)) {
				case PARENT_AB:
				{
					instCondSimple();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				case CTE_LOGTRUE:
				case CTE_LOGFALSE:
				case LIT_ENTERO_OCTAL:
				case LIT_ENTERO_DECIMAL:
				case IDENT:
				case LIT_CADENA:
				case OP_MAS:
				case OP_MENOS:
				case OP_NOT:
				{
					expOLogico();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				}
				break;
			}
			case PUNTO_COMA:
			case PARENT_CE:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			expAsignacion_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_19);
			} else {
			  throw ex;
			}
		}
		returnAST = expAsignacion_AST;
	}
	
	public final void expOLogico() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expOLogico_AST = null;
		
		try {      // for error handling
			expYLogico();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case OP_OR:
			{
				AST tmp90_AST = null;
				tmp90_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp90_AST);
				match(OP_OR);
				expYLogico();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case OP_ASIG:
			case OP_ASIG_MAS:
			case PUNTO_COMA:
			case PARENT_CE:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			expOLogico_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_20);
			} else {
			  throw ex;
			}
		}
		returnAST = expOLogico_AST;
	}
	
	public final void acceso() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST acceso_AST = null;
		AST r1_AST = null;
		AST sub1_AST = null;
		AST r3_AST = null;
		AST r4_AST = null;
		Token  r5 = null;
		AST r5_AST = null;
		
		try {      // for error handling
			if ((LA(1)==IDENT) && (LA(2)==PUNTO)) {
				raizAcceso();
				r1_AST = (AST)returnAST;
				astFactory.addASTChild(currentAST, returnAST);
				if ( inputState.guessing==0 ) {
					acceso_AST = (AST)currentAST.root;
					acceso_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(ACCESO,"ACCESO")).add(r1_AST));
					currentAST.root = acceso_AST;
					currentAST.child = acceso_AST!=null &&acceso_AST.getFirstChild()!=null ?
						acceso_AST.getFirstChild() : acceso_AST;
					currentAST.advanceChildToEnd();
				}
				{
				int _cnt10400=0;
				_loop10400:
				do {
					if ((LA(1)==PUNTO)) {
						match(PUNTO);
						subAcceso();
						sub1_AST = (AST)returnAST;
						if ( inputState.guessing==0 ) {
							acceso_AST = (AST)currentAST.root;
							acceso_AST.addChild(sub1_AST);
						}
					}
					else {
						if ( _cnt10400>=1 ) { break _loop10400; } else {throw new NoViableAltException(LT(1), getFilename());}
					}
					
					_cnt10400++;
				} while (true);
				}
				acceso_AST = (AST)currentAST.root;
			}
			else if ((_tokenSet_21.member(LA(1)))) {
				literal();
				r3_AST = (AST)returnAST;
				astFactory.addASTChild(currentAST, returnAST);
				if ( inputState.guessing==0 ) {
					acceso_AST = (AST)currentAST.root;
					acceso_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(ACCESO,"ACCESO")).add(r3_AST));
					currentAST.root = acceso_AST;
					currentAST.child = acceso_AST!=null &&acceso_AST.getFirstChild()!=null ?
						acceso_AST.getFirstChild() : acceso_AST;
					currentAST.advanceChildToEnd();
				}
				acceso_AST = (AST)currentAST.root;
			}
			else if ((LA(1)==IDENT) && (LA(2)==PARENT_AB) && (_tokenSet_22.member(LA(3)))) {
				llamada();
				r4_AST = (AST)returnAST;
				astFactory.addASTChild(currentAST, returnAST);
				if ( inputState.guessing==0 ) {
					acceso_AST = (AST)currentAST.root;
					acceso_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(ACCESO,"ACCESO")).add(r4_AST));
					currentAST.root = acceso_AST;
					currentAST.child = acceso_AST!=null &&acceso_AST.getFirstChild()!=null ?
						acceso_AST.getFirstChild() : acceso_AST;
					currentAST.advanceChildToEnd();
				}
				acceso_AST = (AST)currentAST.root;
			}
			else if ((LA(1)==IDENT) && (_tokenSet_23.member(LA(2))) && (_tokenSet_24.member(LA(3)))) {
				r5 = LT(1);
				r5_AST = astFactory.create(r5);
				astFactory.addASTChild(currentAST, r5_AST);
				match(IDENT);
				if ( inputState.guessing==0 ) {
					acceso_AST = (AST)currentAST.root;
					acceso_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(ACCESO,"ACCESO")).add(r5_AST));
					currentAST.root = acceso_AST;
					currentAST.child = acceso_AST!=null &&acceso_AST.getFirstChild()!=null ?
						acceso_AST.getFirstChild() : acceso_AST;
					currentAST.advanceChildToEnd();
				}
				acceso_AST = (AST)currentAST.root;
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_23);
			} else {
			  throw ex;
			}
		}
		returnAST = acceso_AST;
	}
	
	public final void expYLogico() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expYLogico_AST = null;
		
		try {      // for error handling
			expComparacion();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case OP_AND:
			{
				AST tmp92_AST = null;
				tmp92_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp92_AST);
				match(OP_AND);
				expComparacion();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case OP_OR:
			case OP_ASIG:
			case OP_ASIG_MAS:
			case PUNTO_COMA:
			case PARENT_CE:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			expYLogico_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_25);
			} else {
			  throw ex;
			}
		}
		returnAST = expYLogico_AST;
	}
	
	public final void expComparacion() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expComparacion_AST = null;
		
		try {      // for error handling
			expAritmetica();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop10381:
			do {
				if ((_tokenSet_26.member(LA(1)))) {
					{
					switch ( LA(1)) {
					case OP_IGUAL:
					{
						AST tmp93_AST = null;
						tmp93_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp93_AST);
						match(OP_IGUAL);
						break;
					}
					case OP_DISTINTO:
					{
						AST tmp94_AST = null;
						tmp94_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp94_AST);
						match(OP_DISTINTO);
						break;
					}
					case OP_MAYOR:
					{
						AST tmp95_AST = null;
						tmp95_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp95_AST);
						match(OP_MAYOR);
						AST tmp96_AST = null;
						tmp96_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp96_AST);
						match(OP_MENOR);
						break;
					}
					case OP_MENOR_IGUAL:
					{
						AST tmp97_AST = null;
						tmp97_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp97_AST);
						match(OP_MENOR_IGUAL);
						break;
					}
					case OP_MAYOR_IGUAL:
					{
						AST tmp98_AST = null;
						tmp98_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp98_AST);
						match(OP_MAYOR_IGUAL);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					expAritmetica();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop10381;
				}
				
			} while (true);
			}
			expComparacion_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_27);
			} else {
			  throw ex;
			}
		}
		returnAST = expComparacion_AST;
	}
	
	public final void expAritmetica() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expAritmetica_AST = null;
		
		try {      // for error handling
			expProducto();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop10385:
			do {
				if ((LA(1)==OP_MAS||LA(1)==OP_MENOS)) {
					{
					switch ( LA(1)) {
					case OP_MAS:
					{
						AST tmp99_AST = null;
						tmp99_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp99_AST);
						match(OP_MAS);
						break;
					}
					case OP_MENOS:
					{
						AST tmp100_AST = null;
						tmp100_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp100_AST);
						match(OP_MENOS);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					expProducto();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop10385;
				}
				
			} while (true);
			}
			expAritmetica_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_28);
			} else {
			  throw ex;
			}
		}
		returnAST = expAritmetica_AST;
	}
	
	public final void expProducto() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expProducto_AST = null;
		
		try {      // for error handling
			expCambioSigno();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop10389:
			do {
				if ((LA(1)==OP_PRODUCTO||LA(1)==OP_DIVISION)) {
					{
					switch ( LA(1)) {
					case OP_PRODUCTO:
					{
						AST tmp101_AST = null;
						tmp101_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp101_AST);
						match(OP_PRODUCTO);
						break;
					}
					case OP_DIVISION:
					{
						AST tmp102_AST = null;
						tmp102_AST = astFactory.create(LT(1));
						astFactory.makeASTRoot(currentAST, tmp102_AST);
						match(OP_DIVISION);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					expCambioSigno();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop10389;
				}
				
			} while (true);
			}
			expProducto_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_29);
			} else {
			  throw ex;
			}
		}
		returnAST = expProducto_AST;
	}
	
	public final void expCambioSigno() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expCambioSigno_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case OP_MENOS:
			{
				{
				match(OP_MENOS);
				expPostIncremento();
				astFactory.addASTChild(currentAST, returnAST);
				if ( inputState.guessing==0 ) {
					expCambioSigno_AST = (AST)currentAST.root;
					expCambioSigno_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(OP_MENOS_UNARIO,"OP_MENOS_UNARIO")).add(expCambioSigno_AST));
					currentAST.root = expCambioSigno_AST;
					currentAST.child = expCambioSigno_AST!=null &&expCambioSigno_AST.getFirstChild()!=null ?
						expCambioSigno_AST.getFirstChild() : expCambioSigno_AST;
					currentAST.advanceChildToEnd();
				}
				}
				expCambioSigno_AST = (AST)currentAST.root;
				break;
			}
			case CTE_LOGTRUE:
			case CTE_LOGFALSE:
			case LIT_ENTERO_OCTAL:
			case LIT_ENTERO_DECIMAL:
			case IDENT:
			case LIT_CADENA:
			case OP_MAS:
			case OP_NOT:
			{
				{
				switch ( LA(1)) {
				case OP_MAS:
				{
					match(OP_MAS);
					break;
				}
				case CTE_LOGTRUE:
				case CTE_LOGFALSE:
				case LIT_ENTERO_OCTAL:
				case LIT_ENTERO_DECIMAL:
				case IDENT:
				case LIT_CADENA:
				case OP_NOT:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				expPostIncremento();
				astFactory.addASTChild(currentAST, returnAST);
				expCambioSigno_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_30);
			} else {
			  throw ex;
			}
		}
		returnAST = expCambioSigno_AST;
	}
	
	public final void expPostIncremento() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expPostIncremento_AST = null;
		
		try {      // for error handling
			expNegacion();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case OP_MASMAS:
			{
				AST tmp105_AST = null;
				tmp105_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp105_AST);
				match(OP_MASMAS);
				break;
			}
			case OP_MENOSMENOS:
			{
				AST tmp106_AST = null;
				tmp106_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp106_AST);
				match(OP_MENOSMENOS);
				break;
			}
			case OP_MAS:
			case OP_MENOS:
			case OP_PRODUCTO:
			case OP_DIVISION:
			case OP_IGUAL:
			case OP_DISTINTO:
			case OP_MAYOR:
			case OP_MENOR_IGUAL:
			case OP_MAYOR_IGUAL:
			case OP_AND:
			case OP_OR:
			case OP_ASIG:
			case OP_ASIG_MAS:
			case PUNTO_COMA:
			case PARENT_CE:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			expPostIncremento_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_30);
			} else {
			  throw ex;
			}
		}
		returnAST = expPostIncremento_AST;
	}
	
	public final void expNegacion() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expNegacion_AST = null;
		
		try {      // for error handling
			{
			_loop10397:
			do {
				if ((LA(1)==OP_NOT)) {
					AST tmp107_AST = null;
					tmp107_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp107_AST);
					match(OP_NOT);
				}
				else {
					break _loop10397;
				}
				
			} while (true);
			}
			acceso();
			astFactory.addASTChild(currentAST, returnAST);
			expNegacion_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_31);
			} else {
			  throw ex;
			}
		}
		returnAST = expNegacion_AST;
	}
	
	public final void raizAcceso() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST raizAcceso_AST = null;
		
		try {      // for error handling
			AST tmp108_AST = null;
			tmp108_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp108_AST);
			match(IDENT);
			raizAcceso_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_32);
			} else {
			  throw ex;
			}
		}
		returnAST = raizAcceso_AST;
	}
	
	public final void subAcceso() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST subAcceso_AST = null;
		
		try {      // for error handling
			llamada();
			astFactory.addASTChild(currentAST, returnAST);
			subAcceso_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_33);
			} else {
			  throw ex;
			}
		}
		returnAST = subAcceso_AST;
	}
	
	public final void literal() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST literal_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case LIT_ENTERO_OCTAL:
			{
				AST tmp109_AST = null;
				tmp109_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp109_AST);
				match(LIT_ENTERO_OCTAL);
				if ( inputState.guessing==0 ) {
					literal_AST = (AST)currentAST.root;
					literal_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(LITERAL,"ent_OCTAL")).add(literal_AST));
					currentAST.root = literal_AST;
					currentAST.child = literal_AST!=null &&literal_AST.getFirstChild()!=null ?
						literal_AST.getFirstChild() : literal_AST;
					currentAST.advanceChildToEnd();
				}
				literal_AST = (AST)currentAST.root;
				break;
			}
			case LIT_ENTERO_DECIMAL:
			{
				AST tmp110_AST = null;
				tmp110_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp110_AST);
				match(LIT_ENTERO_DECIMAL);
				if ( inputState.guessing==0 ) {
					literal_AST = (AST)currentAST.root;
					literal_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(LITERAL,"ENT_DECIMAL")).add(literal_AST));
					currentAST.root = literal_AST;
					currentAST.child = literal_AST!=null &&literal_AST.getFirstChild()!=null ?
						literal_AST.getFirstChild() : literal_AST;
					currentAST.advanceChildToEnd();
				}
				literal_AST = (AST)currentAST.root;
				break;
			}
			case LIT_CADENA:
			{
				AST tmp111_AST = null;
				tmp111_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp111_AST);
				match(LIT_CADENA);
				if ( inputState.guessing==0 ) {
					literal_AST = (AST)currentAST.root;
					literal_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(LITERAL,"LIT_CADENA")).add(literal_AST));
					currentAST.root = literal_AST;
					currentAST.child = literal_AST!=null &&literal_AST.getFirstChild()!=null ?
						literal_AST.getFirstChild() : literal_AST;
					currentAST.advanceChildToEnd();
				}
				literal_AST = (AST)currentAST.root;
				break;
			}
			case CTE_LOGTRUE:
			{
				AST tmp112_AST = null;
				tmp112_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp112_AST);
				match(CTE_LOGTRUE);
				if ( inputState.guessing==0 ) {
					literal_AST = (AST)currentAST.root;
					literal_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(LITERAL,"LIT_TRUE")).add(literal_AST));
					currentAST.root = literal_AST;
					currentAST.child = literal_AST!=null &&literal_AST.getFirstChild()!=null ?
						literal_AST.getFirstChild() : literal_AST;
					currentAST.advanceChildToEnd();
				}
				literal_AST = (AST)currentAST.root;
				break;
			}
			case CTE_LOGFALSE:
			{
				AST tmp113_AST = null;
				tmp113_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp113_AST);
				match(CTE_LOGFALSE);
				if ( inputState.guessing==0 ) {
					literal_AST = (AST)currentAST.root;
					literal_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(LITERAL,"LIT_FALSE")).add(literal_AST));
					currentAST.root = literal_AST;
					currentAST.child = literal_AST!=null &&literal_AST.getFirstChild()!=null ?
						literal_AST.getFirstChild() : literal_AST;
					currentAST.advanceChildToEnd();
				}
				literal_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_34);
			} else {
			  throw ex;
			}
		}
		returnAST = literal_AST;
	}
	
	public final void llamada() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST llamada_AST = null;
		
		try {      // for error handling
			AST tmp114_AST = null;
			tmp114_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp114_AST);
			match(IDENT);
			match(PARENT_AB);
			listaExpresiones();
			astFactory.addASTChild(currentAST, returnAST);
			match(PARENT_CE);
			if ( inputState.guessing==0 ) {
				llamada_AST = (AST)currentAST.root;
				llamada_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(LLAMADA,"LLAMADA")).add(llamada_AST));
				currentAST.root = llamada_AST;
				currentAST.child = llamada_AST!=null &&llamada_AST.getFirstChild()!=null ?
					llamada_AST.getFirstChild() : llamada_AST;
				currentAST.advanceChildToEnd();
			}
			llamada_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_35);
			} else {
			  throw ex;
			}
		}
		returnAST = llamada_AST;
	}
	
	public final void raizAccesoConSubAccesos() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST raizAccesoConSubAccesos_AST = null;
		
		try {      // for error handling
			AST tmp117_AST = null;
			tmp117_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp117_AST);
			match(OP_MAS);
			raizAccesoConSubAccesos_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = raizAccesoConSubAccesos_AST;
	}
	
	public final void raizAccesoSinAccesos() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST raizAccesoSinAccesos_AST = null;
		
		try {      // for error handling
			llamada();
			astFactory.addASTChild(currentAST, returnAST);
			raizAccesoSinAccesos_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = raizAccesoSinAccesos_AST;
	}
	
	public final void listaExpresiones() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST listaExpresiones_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case CTE_LOGTRUE:
			case CTE_LOGFALSE:
			case LIT_ENTERO_OCTAL:
			case LIT_ENTERO_DECIMAL:
			case IDENT:
			case LIT_CADENA:
			{
				{
				switch ( LA(1)) {
				case IDENT:
				{
					AST tmp118_AST = null;
					tmp118_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp118_AST);
					match(IDENT);
					break;
				}
				case CTE_LOGTRUE:
				case CTE_LOGFALSE:
				case LIT_ENTERO_OCTAL:
				case LIT_ENTERO_DECIMAL:
				case LIT_CADENA:
				{
					literal();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				{
				_loop10411:
				do {
					if ((LA(1)==COMA)) {
						match(COMA);
						{
						switch ( LA(1)) {
						case IDENT:
						{
							AST tmp120_AST = null;
							tmp120_AST = astFactory.create(LT(1));
							astFactory.addASTChild(currentAST, tmp120_AST);
							match(IDENT);
							break;
						}
						case CTE_LOGTRUE:
						case CTE_LOGFALSE:
						case LIT_ENTERO_OCTAL:
						case LIT_ENTERO_DECIMAL:
						case LIT_CADENA:
						{
							literal();
							astFactory.addASTChild(currentAST, returnAST);
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
					}
					else {
						break _loop10411;
					}
					
				} while (true);
				}
				break;
			}
			case PARENT_CE:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			if ( inputState.guessing==0 ) {
				listaExpresiones_AST = (AST)currentAST.root;
				listaExpresiones_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(LISTA_EXPRESIONES,"LISTA_EXPRESIONES")).add(listaExpresiones_AST));
				currentAST.root = listaExpresiones_AST;
				currentAST.child = listaExpresiones_AST!=null &&listaExpresiones_AST.getFirstChild()!=null ?
					listaExpresiones_AST.getFirstChild() : listaExpresiones_AST;
				currentAST.advanceChildToEnd();
			}
			listaExpresiones_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_6);
			} else {
			  throw ex;
			}
		}
		returnAST = listaExpresiones_AST;
	}
	
	public final void instDecMet() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST instDecMet_AST = null;
		Token  d = null;
		AST d_AST = null;
		
		try {      // for error handling
			d = LT(1);
			d_AST = astFactory.create(d);
			astFactory.addASTChild(currentAST, d_AST);
			match(IDENT);
			match(PUNTO);
			AST tmp122_AST = null;
			tmp122_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp122_AST);
			match(IDENT);
			match(PARENT_AB);
			lista_valores();
			astFactory.addASTChild(currentAST, returnAST);
			match(PARENT_CE);
			match(PUNTO_COMA);
			if ( inputState.guessing==0 ) {
				instDecMet_AST = (AST)currentAST.root;
					instDecMet_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(CALL_METODO,"CALL_METODO")).add(instDecMet_AST));
				currentAST.root = instDecMet_AST;
				currentAST.child = instDecMet_AST!=null &&instDecMet_AST.getFirstChild()!=null ?
					instDecMet_AST.getFirstChild() : instDecMet_AST;
				currentAST.advanceChildToEnd();
			}
			instDecMet_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = instDecMet_AST;
	}
	
	public final void lista_valores() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST lista_valores_AST = null;
		
		try {      // for error handling
			q_argumento();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop10424:
			do {
				if ((LA(1)==COMA)) {
					match(COMA);
					q_argumento();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop10424;
				}
				
			} while (true);
			}
			if ( inputState.guessing==0 ) {
				lista_valores_AST = (AST)currentAST.root;
				lista_valores_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(ARGUMENTOS_ENTRADA,"ARGUMENTOS_ENTRADA")).add(lista_valores_AST));
				currentAST.root = lista_valores_AST;
				currentAST.child = lista_valores_AST!=null &&lista_valores_AST.getFirstChild()!=null ?
					lista_valores_AST.getFirstChild() : lista_valores_AST;
				currentAST.advanceChildToEnd();
			}
			lista_valores_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_6);
			} else {
			  throw ex;
			}
		}
		returnAST = lista_valores_AST;
	}
	
	public final void sino() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST sino_AST = null;
		
		try {      // for error handling
			if ((LA(1)==ELSE) && (LA(2)==IF) && (LA(3)==PARENT_AB)) {
				sinosi();
				astFactory.addASTChild(currentAST, returnAST);
				sino();
				astFactory.addASTChild(currentAST, returnAST);
				sino_AST = (AST)currentAST.root;
			}
			else if ((LA(1)==ELSE) && (_tokenSet_36.member(LA(2))) && (_tokenSet_37.member(LA(3)))) {
				sinofin();
				astFactory.addASTChild(currentAST, returnAST);
				sino_AST = (AST)currentAST.root;
			}
			else if ((_tokenSet_13.member(LA(1))) && (_tokenSet_38.member(LA(2))) && (_tokenSet_39.member(LA(3)))) {
				sino_AST = (AST)currentAST.root;
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = sino_AST;
	}
	
	public final void sinosi() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST sinosi_AST = null;
		
		try {      // for error handling
			AST tmp127_AST = null;
			tmp127_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp127_AST);
			match(ELSE);
			AST tmp128_AST = null;
			tmp128_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp128_AST);
			match(IF);
			match(PARENT_AB);
			expresion();
			astFactory.addASTChild(currentAST, returnAST);
			match(PARENT_CE);
			{
			switch ( LA(1)) {
			case LLAVE_AB:
			{
				match(LLAVE_AB);
				cuerpo_sp();
				astFactory.addASTChild(currentAST, returnAST);
				match(LLAVE_CE);
				break;
			}
			case CTE_LOGTRUE:
			case CTE_LOGFALSE:
			case CHAR:
			case INT:
			case BOOL:
			case IF:
			case RETURN:
			case VOID:
			case CIN:
			case COUT:
			case LIT_ENTERO_OCTAL:
			case LIT_ENTERO_DECIMAL:
			case IDENT:
			case LIT_CADENA:
			case OP_MAS:
			case OP_MENOS:
			case OP_NOT:
			case PUNTO_COMA:
			case PARENT_AB:
			{
				instruccion();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			sinosi_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = sinosi_AST;
	}
	
	public final void sinofin() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST sinofin_AST = null;
		
		try {      // for error handling
			AST tmp133_AST = null;
			tmp133_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp133_AST);
			match(ELSE);
			{
			switch ( LA(1)) {
			case LLAVE_AB:
			{
				match(LLAVE_AB);
				cuerpo_sp();
				astFactory.addASTChild(currentAST, returnAST);
				match(LLAVE_CE);
				break;
			}
			case CTE_LOGTRUE:
			case CTE_LOGFALSE:
			case CHAR:
			case INT:
			case BOOL:
			case IF:
			case RETURN:
			case VOID:
			case CIN:
			case COUT:
			case LIT_ENTERO_OCTAL:
			case LIT_ENTERO_DECIMAL:
			case IDENT:
			case LIT_CADENA:
			case OP_MAS:
			case OP_MENOS:
			case OP_NOT:
			case PUNTO_COMA:
			case PARENT_AB:
			{
				instruccion();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			sinofin_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = sinofin_AST;
	}
	
	public final void detIgual(
		AST raiz
	) throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST detIgual_AST = null;
		Token  t = null;
		AST t_AST = null;
		
		try {      // for error handling
			t = LT(1);
			t_AST = astFactory.create(t);
			astFactory.addASTChild(currentAST, t_AST);
			match(OP_ASIG);
			detIgual_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = detIgual_AST;
	}
	
	public final void e_vector() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST e_vector_AST = null;
		
		try {      // for error handling
			AST tmp136_AST = null;
			tmp136_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp136_AST);
			match(IDENT);
			match(CORCHETE_AB);
			AST tmp138_AST = null;
			tmp138_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp138_AST);
			match(LIT_ENTERO_DECIMAL);
			match(CORCHETE_CE);
			e_vector_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = e_vector_AST;
	}
	
	public final void cadena() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cadena_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case CORCHETE_AB:
			{
				vector();
				astFactory.addASTChild(currentAST, returnAST);
				cadena_AST = (AST)currentAST.root;
				break;
			}
			case EOF:
			{
				cadena_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = cadena_AST;
	}
	
	public final void vector() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST vector_AST = null;
		
		try {      // for error handling
			AST tmp140_AST = null;
			tmp140_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp140_AST);
			match(CORCHETE_AB);
			AST tmp141_AST = null;
			tmp141_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp141_AST);
			match(LIT_ENTERO_DECIMAL);
			AST tmp142_AST = null;
			tmp142_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp142_AST);
			match(CORCHETE_CE);
			vector_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = vector_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"main\"",
		"\"true\"",
		"\"false\"",
		"\"char\"",
		"\"int\"",
		"\"bool\"",
		"\"if\"",
		"\"else\"",
		"\"return\"",
		"\"do\"",
		"\"while\"",
		"\"for\"",
		"\"void\"",
		"\"class\"",
		"\"public\"",
		"\"private\"",
		"\"switch\"",
		"\"case\"",
		"\"break\"",
		"\"default\"",
		"\"cin\"",
		"\"cout\"",
		"\"nl\"",
		"\"tab\"",
		"\"com\"",
		"LIT_ENTERO_OCTAL",
		"LIT_ENTERO_DECIMAL",
		"BLANCO",
		"NL",
		"LETRA",
		"DIGITO",
		"DIGIT_O",
		"IDENT",
		"COMENTARIO1",
		"COMENTARIO2",
		"LIT_NUMERO",
		"LIT_CADENA",
		"OP_MAS",
		"OP_MENOS",
		"OP_PRODUCTO",
		"OP_DIVISION",
		"OP_MODULO",
		"OP_IGUAL",
		"OP_DISTINTO",
		"OP_MENOR",
		"OP_MAYOR",
		"OP_MENOR_IGUAL",
		"OP_MAYOR_IGUAL",
		"OP_AND",
		"OP_OR",
		"OP_NOT",
		"REFERENCIA",
		"OP_MASMAS",
		"OP_MENOSMENOS",
		"DOSPUNTOS",
		"INTER",
		"OP_ASIG",
		"OP_ASIG_MAS",
		"OP_ASIG_MENOS",
		"OP_ASIG_PRODUCTO",
		"OP_ASIG_DIVISION",
		"OP_ASIG_MODULO",
		"PUNTO_COMA",
		"COMA",
		"CORCHETE_AB",
		"CORCHETE_CE",
		"LLAVE_AB",
		"LLAVE_CE",
		"PUNTO",
		"PARENT_AB",
		"PARENT_CE",
		"BARRA_VERT",
		"MENOR_MENOR",
		"MAYOR_MAYOR",
		"DOSPUNTOS_DOS",
		"DEC_ENTERO",
		"RES_PARAMETRO",
		"INTS_DEC_VAR",
		"INST_EXPRESION",
		"EXPRESION",
		"OP_MENOS_UNARIO",
		"ACCESO",
		"LISTA_EXPRESIONES",
		"LLAMADA",
		"CLASE",
		"DEC_METODO",
		"CALL_METODO",
		"DEC_MAIN",
		"LISTA_INSTRUCCIONES",
		"ARGUMENTOS_ENTRADA",
		"SUBPROGRAMA",
		"PROGRAMA",
		"INST_RETURN",
		"CONDSIMPLE",
		"LITERAL",
		"VARSGLOBAL"
	};
	
	protected void buildTokenTypeASTClassMap() {
		tokenTypeToASTClassMap=null;
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 68719543168L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	private static final long[] mk_tokenSet_1() {
		long[] data = { 1152921573326323712L, 540L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
	private static final long[] mk_tokenSet_2() {
		long[] data = { 2L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
	private static final long[] mk_tokenSet_3() {
		long[] data = { 68719476752L, 1032L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
	private static final long[] mk_tokenSet_4() {
		long[] data = { 18022165471502304L, 644L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
	private static final long[] mk_tokenSet_5() {
		long[] data = { 68719674240L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
	private static final long[] mk_tokenSet_6() {
		long[] data = { 0L, 1024L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
	private static final long[] mk_tokenSet_7() {
		long[] data = { 18022165471369184L, 516L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
	private static final long[] mk_tokenSet_8() {
		long[] data = { 0L, 128L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
	private static final long[] mk_tokenSet_9() {
		long[] data = { 786432L, 128L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
	private static final long[] mk_tokenSet_10() {
		long[] data = { 18022165420965984L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
	private static final long[] mk_tokenSet_11() {
		long[] data = { 3710648404422951008L, 772L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
	private static final long[] mk_tokenSet_12() {
		long[] data = { 3710929879450066912L, 1924L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
	private static final long[] mk_tokenSet_13() {
		long[] data = { 18022165471371232L, 644L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
	private static final long[] mk_tokenSet_14() {
		long[] data = { 0L, 4L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
	private static final long[] mk_tokenSet_15() {
		long[] data = { 0L, 12L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
	private static final long[] mk_tokenSet_16() {
		long[] data = { 0L, 1036L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
	private static final long[] mk_tokenSet_17() {
		long[] data = { 18022165471371232L, 1668L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
	private static final long[] mk_tokenSet_18() {
		long[] data = { 0L, 4100L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
	private static final long[] mk_tokenSet_19() {
		long[] data = { 0L, 1028L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
	private static final long[] mk_tokenSet_20() {
		long[] data = { 3458764513820540928L, 1028L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
	private static final long[] mk_tokenSet_21() {
		long[] data = { 1101122240608L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
	private static final long[] mk_tokenSet_22() {
		long[] data = { 1169841717344L, 1024L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
	private static final long[] mk_tokenSet_23() {
		long[] data = { 3998878780625068000L, 1668L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_23 = new BitSet(mk_tokenSet_23());
	private static final long[] mk_tokenSet_24() {
		long[] data = { 4287390631753621474L, 14276L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_24 = new BitSet(mk_tokenSet_24());
	private static final long[] mk_tokenSet_25() {
		long[] data = { 3467771713075281920L, 1028L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_25 = new BitSet(mk_tokenSet_25());
	private static final long[] mk_tokenSet_26() {
		long[] data = { 4151755906482176L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_26 = new BitSet(mk_tokenSet_26());
	private static final long[] mk_tokenSet_27() {
		long[] data = { 3472275312702652416L, 1028L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_27 = new BitSet(mk_tokenSet_27());
	private static final long[] mk_tokenSet_28() {
		long[] data = { 3476427068609134592L, 1028L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_28 = new BitSet(mk_tokenSet_28());
	private static final long[] mk_tokenSet_29() {
		long[] data = { 3476433665678901248L, 1028L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_29 = new BitSet(mk_tokenSet_29());
	private static final long[] mk_tokenSet_30() {
		long[] data = { 3476460053957967872L, 1028L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_30 = new BitSet(mk_tokenSet_30());
	private static final long[] mk_tokenSet_31() {
		long[] data = { 3692632836071751680L, 1028L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_31 = new BitSet(mk_tokenSet_31());
	private static final long[] mk_tokenSet_32() {
		long[] data = { 0L, 256L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_32 = new BitSet(mk_tokenSet_32());
	private static final long[] mk_tokenSet_33() {
		long[] data = { 3998878780625068000L, 1924L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_33 = new BitSet(mk_tokenSet_33());
	private static final long[] mk_tokenSet_34() {
		long[] data = { 3998878780625068000L, 1676L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_34 = new BitSet(mk_tokenSet_34());
	private static final long[] mk_tokenSet_35() {
		long[] data = { 3998878780625068002L, 1924L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_35 = new BitSet(mk_tokenSet_35());
	private static final long[] mk_tokenSet_36() {
		long[] data = { 18022165471369184L, 580L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_36 = new BitSet(mk_tokenSet_36());
	private static final long[] mk_tokenSet_37() {
		long[] data = { 3710648404473356256L, 13188L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_37 = new BitSet(mk_tokenSet_37());
	private static final long[] mk_tokenSet_38() {
		long[] data = { 3710648404473487330L, 13252L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_38 = new BitSet(mk_tokenSet_38());
	private static final long[] mk_tokenSet_39() {
		long[] data = { 3710929879450198002L, 14300L, 0L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_39 = new BitSet(mk_tokenSet_39());
	
	}
