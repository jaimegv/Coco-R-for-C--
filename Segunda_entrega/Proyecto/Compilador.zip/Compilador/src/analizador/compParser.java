// $ANTLR : "CompParser.g" -> "compParser.java"$

	package analizador;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import java.util.Hashtable;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

public class compParser extends antlr.LLkParser       implements CompParserVocabTokenTypes
 {

protected compParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public compParser(TokenBuffer tokenBuf) {
  this(tokenBuf,2);
}

protected compParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public compParser(TokenStream lexer) {
  this(lexer,2);
}

public compParser(ParserSharedInputState state) {
  super(state,2);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

	public final void instNula() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST instNula_AST = null;
		
		try {      // for error handling
			match(PUNTO_COMA);
			instNula_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
		returnAST = instNula_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"main\"",
		"\"true\"",
		"\"false\"",
		"\"char\"",
		"\"int\"",
		"\"bool\"",
		"\"if\"",
		"\"else\"",
		"\"return\"",
		"\"do\"",
		"\"while\"",
		"\"for\"",
		"\"void\"",
		"\"class\"",
		"\"public\"",
		"\"private\"",
		"\"switch\"",
		"\"case\"",
		"\"break\"",
		"\"default\"",
		"\"cin\"",
		"\"cout\"",
		"\"nl\"",
		"\"tab\"",
		"\"com\"",
		"LIT_ENTERO_OCTAL",
		"LIT_ENTERO_DECIMAL",
		"BLANCO",
		"NL",
		"LETRA",
		"DIGITO",
		"DIGIT_O",
		"IDENT",
		"COMENTARIO1",
		"COMENTARIO2",
		"LIT_NUMERO",
		"LIT_CADENA",
		"OP_MAS",
		"OP_MENOS",
		"OP_PRODUCTO",
		"OP_DIVISION",
		"OP_MODULO",
		"OP_IGUAL",
		"OP_DISTINTO",
		"OP_MENOR",
		"OP_MAYOR",
		"OP_MENOR_IGUAL",
		"OP_MAYOR_IGUAL",
		"OP_AND",
		"OP_OR",
		"OP_NOT",
		"REFERENCIA",
		"OP_MASMAS",
		"OP_MENOSMENOS",
		"DOSPUNTOS",
		"INTER",
		"OP_ASIG",
		"OP_ASIG_MAS",
		"OP_ASIG_MENOS",
		"OP_ASIG_PRODUCTO",
		"OP_ASIG_DIVISION",
		"OP_ASIG_MODULO",
		"PUNTO_COMA",
		"COMA",
		"CORCHETE_AB",
		"CORCHETE_CE",
		"LLAVE_AB",
		"LLAVE_CE",
		"PUNTO",
		"PARENT_AB",
		"PARENT_CE",
		"BARRA_VERT",
		"MENOR_MENOR",
		"MAYOR_MAYOR",
		"DOSPUNTOS_DOS",
		"PROGRAMA",
		"LISTA_MIEMBROS",
		"LISTA_EXPRESIONES",
		"LISTA_INSTRUCCIONES",
		"OP_MENOS_UNARIO",
		"INST_EXPRESION",
		"INST_DEC_VAR",
		"LLAMADA",
		"ATRIBUTO",
		"TIPO_VACIO"
	};
	
	protected void buildTokenTypeASTClassMap() {
		tokenTypeToASTClassMap=null;
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 2L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	
	}
