// $ANTLR : "CompTreeParser.g" -> "CompTreeParser.java"$

	package analizador;

import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;


public class CompTreeParser extends antlr.TreeParser       implements CompTreeParserTokenTypes
 {
public CompTreeParser() {
	tokenNames = _tokenNames;
}

	public final void programa(AST _t) throws RecognitionException {
		
		AST programa_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		try {      // for error handling
			AST __t6456 = _t;
			AST tmp1_AST_in = (AST)_t;
			match(_t,PROGRAMA);
			_t = _t.getFirstChild();
			AST tmp2_AST_in = (AST)_t;
			match(_t,VARSGLOBAL);
			_t = _t.getNextSibling();
			{
			_loop6458:
			do {
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case SUBPROGRAMA:
				{
					AST tmp3_AST_in = (AST)_t;
					match(_t,SUBPROGRAMA);
					_t = _t.getNextSibling();
					break;
				}
				case CLASE:
				{
					AST tmp4_AST_in = (AST)_t;
					match(_t,CLASE);
					_t = _t.getNextSibling();
					break;
				}
				case DEC_METODO:
				{
					AST tmp5_AST_in = (AST)_t;
					match(_t,DEC_METODO);
					_t = _t.getNextSibling();
					break;
				}
				default:
				{
					break _loop6458;
				}
				}
			} while (true);
			}
			AST tmp6_AST_in = (AST)_t;
			match(_t,DEC_MAIN);
			_t = _t.getNextSibling();
			_t = __t6456;
			_t = _t.getNextSibling();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			if (_t!=null) {_t = _t.getNextSibling();}
		}
		_retTree = _t;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"main\"",
		"\"true\"",
		"\"false\"",
		"\"char\"",
		"\"int\"",
		"\"bool\"",
		"\"if\"",
		"\"else\"",
		"\"return\"",
		"\"do\"",
		"\"while\"",
		"\"for\"",
		"\"void\"",
		"\"class\"",
		"\"public\"",
		"\"private\"",
		"\"switch\"",
		"\"case\"",
		"\"break\"",
		"\"default\"",
		"\"cin\"",
		"\"cout\"",
		"\"nl\"",
		"\"tab\"",
		"\"com\"",
		"LIT_ENTERO_OCTAL",
		"LIT_ENTERO_DECIMAL",
		"BLANCO",
		"NL",
		"LETRA",
		"DIGITO",
		"DIGIT_O",
		"IDENT",
		"COMENTARIO1",
		"COMENTARIO2",
		"LIT_NUMERO",
		"LIT_CADENA",
		"OP_MAS",
		"OP_MENOS",
		"OP_PRODUCTO",
		"OP_DIVISION",
		"OP_MODULO",
		"OP_IGUAL",
		"OP_DISTINTO",
		"OP_MENOR",
		"OP_MAYOR",
		"OP_MENOR_IGUAL",
		"OP_MAYOR_IGUAL",
		"OP_AND",
		"OP_OR",
		"OP_NOT",
		"REFERENCIA",
		"OP_MASMAS",
		"OP_MENOSMENOS",
		"DOSPUNTOS",
		"INTER",
		"OP_ASIG",
		"OP_ASIG_MAS",
		"OP_ASIG_MENOS",
		"OP_ASIG_PRODUCTO",
		"OP_ASIG_DIVISION",
		"OP_ASIG_MODULO",
		"PUNTO_COMA",
		"COMA",
		"CORCHETE_AB",
		"CORCHETE_CE",
		"LLAVE_AB",
		"LLAVE_CE",
		"PUNTO",
		"PARENT_AB",
		"PARENT_CE",
		"BARRA_VERT",
		"MENOR_MENOR",
		"MAYOR_MAYOR",
		"DOSPUNTOS_DOS",
		"DEC_ENTERO",
		"RES_PARAMETRO",
		"INTS_DEC_VAR",
		"INST_EXPRESION",
		"EXPRESION",
		"OP_MENOS_UNARIO",
		"ACCESO",
		"LISTA_EXPRESIONES",
		"LLAMADA",
		"CLASE",
		"DEC_METODO",
		"CALL_METODO",
		"DEC_MAIN",
		"LISTA_INSTRUCCIONES",
		"ARGUMENTOS_ENTRADA",
		"SUBPROGRAMA",
		"PROGRAMA",
		"INST_RETURN",
		"CONDSIMPLE",
		"LITERAL",
		"VARSGLOBAL",
		"DOS_PUNTOS"
	};
	
	}
	
